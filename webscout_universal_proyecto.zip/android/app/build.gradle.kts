import java.io.FileInputStream
import java.util.Properties
import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("kotlin-android")
    // El plugin de Flutter debe aplicarse después de los plugins de Android y Kotlin.
    id("dev.flutter.flutter-gradle-plugin")
}

// ---------------------------------------------------------------------------
// Firma release FIJA.
// Orden de búsqueda de credenciales:
//   1) android/key.properties  (lo genera el workflow durante la compilación)
//   2) variables de entorno: KEYSTORE_PATH, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD
// Si no hay ninguna, el build release usa la firma debug (solo para pruebas locales;
// ese APK NO podrá actualizar encima de uno firmado con tu keystore real).
//
// Formato de android/key.properties:
//   storeFile=/ruta/absoluta/release.jks      (relativa => respecto a android/app)
//   storePassword=...
//   keyAlias=...
//   keyPassword=...
// ---------------------------------------------------------------------------
val keystoreProperties = Properties()
val keystorePropertiesFile = rootProject.file("key.properties")
if (keystorePropertiesFile.exists()) {
    FileInputStream(keystorePropertiesFile).use { keystoreProperties.load(it) }
}

fun signingValue(propKey: String, envKey: String): String? =
    keystoreProperties.getProperty(propKey)?.trim()?.takeIf { it.isNotEmpty() }
        ?: System.getenv(envKey)?.trim()?.takeIf { it.isNotEmpty() }

val releaseStoreFile: String? = signingValue("storeFile", "KEYSTORE_PATH")
val releaseStorePassword: String? = signingValue("storePassword", "KEYSTORE_PASSWORD")
val releaseKeyAlias: String? = signingValue("keyAlias", "KEY_ALIAS")
val releaseKeyPassword: String? = signingValue("keyPassword", "KEY_PASSWORD")
val hasReleaseSigning: Boolean =
    releaseStoreFile != null && releaseStorePassword != null &&
        releaseKeyAlias != null && releaseKeyPassword != null

android {
    // Namespace y applicationId constantes: NO cambiarlos nunca, o Android lo tratará como otra app.
    namespace = "com.webscout.universal"
    compileSdk = maxOf(36, flutter.compileSdkVersion)
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    defaultConfig {
        applicationId = "com.webscout.universal"
        minSdk = 29                                   // MediaStore.Downloads sin permisos legacy
        targetSdk = maxOf(36, flutter.targetSdkVersion) // Android 16
        // versionCode y versionName salen de pubspec.yaml -> version: 1.0.0+1
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    signingConfigs {
        if (hasReleaseSigning) {
            create("release") {
                storeFile = file(releaseStoreFile!!)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    buildTypes {
        release {
            signingConfig = if (hasReleaseSigning) {
                signingConfigs.getByName("release")
            } else {
                signingConfigs.getByName("debug")
            }
        }
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

flutter {
    source = "../.."
}
