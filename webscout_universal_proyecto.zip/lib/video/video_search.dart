// Búsqueda de videos estilo buscador tradicional.
//
// Google, Bing o DuckDuckGo NO reproducen archivos sueltos: indexan las PÁGINAS de video de plataformas
// (título, miniatura, duración) y reproducen con el reproductor de esa plataforma. Aquí se hace igual con
// fuentes de API pública y sin clave:
//   - Wikimedia Commons: archivo directo (se usa la copia transcodificada MP4/WebM que Android sí reproduce).
//   - Internet Archive: archivo MP4 directo o reproductor incrustado.
//   - Dailymotion: reproductor incrustado.
//   - PeerTube (vía SepiaSearch): archivo directo o lista HLS.
// Cada fuente falla por separado: si una no responde, las demás siguen funcionando.

import 'dart:async';

import '../parental/mini_http.dart';

enum VideoSource { commons, archive, dailymotion, peertube }

String videoSourceLabel(VideoSource s) {
  switch (s) {
    case VideoSource.commons:
      return 'Wikimedia Commons';
    case VideoSource.archive:
      return 'Internet Archive';
    case VideoSource.dailymotion:
      return 'Dailymotion';
    case VideoSource.peertube:
      return 'PeerTube';
  }
}

class VideoItem {
  final String id;
  final String title;
  final String? thumb;
  final int? seconds;
  final VideoSource source;
  final String pageUrl; // página pública del video
  final String? directUrl; // archivo reproducible (mp4/webm/m3u8) si ya se conoce
  final String? embedUrl; // reproductor incrustable (HTML5)
  final String? host; // PeerTube: instancia que lo aloja
  const VideoItem({
    required this.id,
    required this.title,
    required this.source,
    required this.pageUrl,
    this.thumb,
    this.seconds,
    this.directUrl,
    this.embedUrl,
    this.host,
  });

  String get sourceLabel => videoSourceLabel(source);

  String get durationLabel {
    final s = seconds;
    if (s == null || s <= 0) return '';
    final h = s ~/ 3600;
    final m = ((s % 3600) ~/ 60).toString().padLeft(2, '0');
    final sec = (s % 60).toString().padLeft(2, '0');
    return h > 0 ? '$h:$m:$sec' : '${s ~/ 60}:$sec';
  }
}

class VideoSearchResult {
  final List<VideoItem> items;
  final List<String> notes;
  const VideoSearchResult(this.items, this.notes);
}

class VideoSearch {
  static Future<VideoSearchResult> search(
    String q, {
    required Set<VideoSource> sources,
    required bool safe,
    int limit = 12,
  }) async {
    final notes = <String>[];
    final results = <VideoSource, List<VideoItem>>{};

    Future<void> run(VideoSource s, Future<List<VideoItem>> Function() f) async {
      try {
        final r = await f().timeout(const Duration(seconds: 15));
        results[s] = r;
        notes.add('${videoSourceLabel(s)}: ${r.length}');
      } catch (_) {
        notes.add('${videoSourceLabel(s)}: sin respuesta');
      }
    }

    await Future.wait([
      if (sources.contains(VideoSource.commons)) run(VideoSource.commons, () => _commons(q, limit)),
      if (sources.contains(VideoSource.archive)) run(VideoSource.archive, () => _archive(q, limit)),
      if (sources.contains(VideoSource.dailymotion)) run(VideoSource.dailymotion, () => _dailymotion(q, limit, safe)),
      if (sources.contains(VideoSource.peertube)) run(VideoSource.peertube, () => _peertube(q, limit)),
    ]);

    // Intercala las fuentes para dar variedad (como un carrusel de buscador).
    final order = [VideoSource.commons, VideoSource.archive, VideoSource.dailymotion, VideoSource.peertube].where(results.containsKey).toList();
    final out = <VideoItem>[];
    var i = 0;
    var added = true;
    while (out.length < limit && added) {
      added = false;
      for (final s in order) {
        final l = results[s]!;
        if (i < l.length && out.length < limit) {
          out.add(l[i]);
          added = true;
        }
      }
      i++;
    }
    return VideoSearchResult(out, notes);
  }

  // ------------------------------------------------------------ Wikimedia Commons

  static Future<List<VideoItem>> _commons(String q, int limit) async {
    final j = await MiniHttp.getJson(
      Uri.https('commons.wikimedia.org', '/w/api.php', {
        'action': 'query',
        'generator': 'search',
        'gsrnamespace': '6',
        'gsrsearch': '$q filetype:video',
        'gsrlimit': '${limit + 4}',
        'prop': 'imageinfo',
        'iiprop': 'url|mime|size',
        'iiurlwidth': '320',
        'format': 'json',
        'formatversion': '2',
      }),
      maxBytes: 800000,
    );
    final pages = ((j?['query'] as Map?)?['pages'] as List?) ?? [];
    final sorted = pages.cast<Map>().toList()
      ..sort((a, b) => ((a['index'] as num?) ?? 0).compareTo((b['index'] as num?) ?? 0));
    final raw = <Map>[];
    for (final p in sorted) {
      final ii = (p['imageinfo'] as List?)?.first as Map?;
      if (ii == null) continue;
      final mime = (ii['mime'] ?? '').toString();
      if (!mime.startsWith('video/') && mime != 'application/ogg') continue;
      raw.add({'title': p['title'].toString(), 'url': (ii['url'] ?? '').toString(), 'thumb': (ii['thumburl'] ?? '').toString()});
    }
    if (raw.isEmpty) return [];

    // Copias transcodificadas (MP4/H.264, VP9, VP8): los .ogv originales usan Theora y Android no los reproduce.
    final ders = <String, String>{};
    try {
      final titles = raw.map((e) => e['title']).take(limit + 4).join('|');
      final d = await MiniHttp.getJson(
        Uri.https('commons.wikimedia.org', '/w/api.php', {
          'action': 'query',
          'titles': titles,
          'prop': 'videoinfo',
          'viprop': 'derivatives',
          'format': 'json',
          'formatversion': '2',
        }),
        maxBytes: 1500000,
      );
      for (final p in ((d?['query'] as Map?)?['pages'] as List?) ?? const []) {
        if (p is! Map) continue;
        final b = _bestDerivative(p);
        if (b != null) ders[p['title'].toString()] = b;
      }
    } catch (_) {}

    final out = <VideoItem>[];
    for (final e in raw) {
      final title = e['title'] as String;
      final url = e['url'] as String;
      if (url.isEmpty) continue;
      final lower = url.toLowerCase();
      final playableOriginal = lower.endsWith('.mp4') || lower.endsWith('.webm') || lower.endsWith('.mkv') || lower.endsWith('.mov');
      final direct = ders[title] ?? (playableOriginal ? url : null);
      if (direct == null) continue; // sin copia reproducible en Android
      final th = e['thumb'] as String;
      out.add(VideoItem(
        id: title,
        title: title.replaceFirst('File:', '').replaceAll(RegExp(r'\.[A-Za-z0-9]{2,4}$'), ''),
        source: VideoSource.commons,
        pageUrl: 'https://commons.wikimedia.org/wiki/${Uri.encodeComponent(title.replaceAll(' ', '_'))}',
        thumb: th.isEmpty ? null : th,
        directUrl: direct,
      ));
      if (out.length >= limit) break;
    }
    return out;
  }

  /// MP4/H.264 > VP9 > VP8, lo más cercano a 480p.
  static String? _bestDerivative(Map page) {
    final vi = (page['videoinfo'] as List?)?.firstOrNull;
    final ders = (vi is Map ? vi['derivatives'] as List? : null) ?? const [];
    String? best;
    var bestScore = 1 << 30;
    for (final d in ders) {
      if (d is! Map) continue;
      final type = (d['type'] ?? '').toString().toLowerCase();
      final src = (d['src'] ?? '').toString();
      if (src.isEmpty) continue;
      int pref;
      if (type.contains('mp4') || type.contains('avc1') || type.contains('h264')) {
        pref = 0;
      } else if (type.contains('vp9')) {
        pref = 1;
      } else if (type.contains('vp8') || type.contains('webm')) {
        pref = 2;
      } else {
        continue;
      }
      final h = int.tryParse('${d['height'] ?? ''}') ?? 480;
      final score = pref * 10000 + (h - 480).abs();
      if (score < bestScore) {
        bestScore = score;
        best = src.startsWith('//') ? 'https:$src' : src;
      }
    }
    return (best != null && best.startsWith('https://')) ? best : null;
  }

  // ------------------------------------------------------------ Internet Archive

  static Future<List<VideoItem>> _archive(String q, int limit) async {
    final j = await MiniHttp.getJson(
      Uri.https('archive.org', '/advancedsearch.php', {
        'q': '($q) AND mediatype:(movies)',
        'fl[]': ['identifier', 'title', 'runtime'],
        'rows': '$limit',
        'page': '1',
        'output': 'json',
        'sort[]': 'downloads desc',
      }),
      maxBytes: 800000,
    );
    final docs = ((j?['response'] as Map?)?['docs'] as List?) ?? [];
    final out = <VideoItem>[];
    for (final d in docs) {
      if (d is! Map) continue;
      final id = (d['identifier'] ?? '').toString();
      if (id.isEmpty) continue;
      final t = d['title'];
      out.add(VideoItem(
        id: id,
        title: (t is List ? (t.isEmpty ? id : t.first.toString()) : (t ?? id).toString()),
        source: VideoSource.archive,
        pageUrl: 'https://archive.org/details/$id',
        thumb: 'https://archive.org/services/img/$id',
        seconds: _parseRuntime(d['runtime']),
        embedUrl: 'https://archive.org/embed/$id',
      ));
    }
    return out;
  }

  static int? _parseRuntime(Object? r) {
    final s = (r is List ? (r.isEmpty ? '' : r.first.toString()) : (r ?? '').toString()).trim();
    if (s.isEmpty) return null;
    if (RegExp(r'^\d+(\.\d+)?$').hasMatch(s)) return double.parse(s).round();
    final parts = s.split(':').map((e) => int.tryParse(e)).toList();
    if (parts.any((e) => e == null)) return null;
    var total = 0;
    for (final p in parts) {
      total = total * 60 + p!;
    }
    return total;
  }

  // ------------------------------------------------------------ Dailymotion

  static Future<List<VideoItem>> _dailymotion(String q, int limit, bool safe) async {
    final j = await MiniHttp.getJson(
      Uri.https('api.dailymotion.com', '/videos', {
        'search': q,
        'fields': 'id,title,thumbnail_240_url,duration,url',
        'limit': '$limit',
        'sort': 'relevance',
        'family_filter': safe ? 'true' : 'false',
      }),
      maxBytes: 800000,
    );
    final list = (j?['list'] as List?) ?? [];
    final out = <VideoItem>[];
    for (final d in list) {
      if (d is! Map) continue;
      final id = (d['id'] ?? '').toString();
      if (id.isEmpty) continue;
      final th = (d['thumbnail_240_url'] ?? '').toString();
      out.add(VideoItem(
        id: id,
        title: (d['title'] ?? id).toString(),
        source: VideoSource.dailymotion,
        pageUrl: (d['url'] ?? 'https://www.dailymotion.com/video/$id').toString(),
        thumb: th.startsWith('https://') ? th : null,
        seconds: (d['duration'] as num?)?.toInt(),
        embedUrl: 'https://www.dailymotion.com/embed/video/$id',
      ));
    }
    return out;
  }

  // ------------------------------------------------------------ PeerTube (SepiaSearch)

  static Future<List<VideoItem>> _peertube(String q, int limit) async {
    final j = await MiniHttp.getJson(
      Uri.https('sepiasearch.org', '/api/v1/search/videos', {
        'search': q,
        'count': '$limit',
        'nsfw': 'false',
        'sort': '-match',
      }),
      maxBytes: 1200000,
    );
    final data = (j?['data'] as List?) ?? [];
    final out = <VideoItem>[];
    for (final d in data) {
      if (d is! Map) continue;
      if (d['isLive'] == true) continue;
      final uuid = (d['uuid'] ?? '').toString();
      final url = (d['url'] ?? '').toString();
      final host = Uri.tryParse(url)?.host ?? '';
      if (uuid.isEmpty || host.isEmpty) continue;
      final th = (d['thumbnailUrl'] ?? '').toString();
      final emb = (d['embedUrl'] ?? '').toString();
      out.add(VideoItem(
        id: uuid,
        title: (d['name'] ?? uuid).toString(),
        source: VideoSource.peertube,
        pageUrl: url,
        thumb: th.startsWith('https://') ? th : null,
        seconds: (d['duration'] as num?)?.toInt(),
        embedUrl: emb.startsWith('https://') ? emb : null,
        host: host,
      ));
    }
    return out;
  }

  // ------------------------------------------------------------ archivo directo (al reproducir)

  /// Resuelve el archivo directo reproducible por Android. null = usar el reproductor incrustado.
  static Future<String?> resolveDirect(VideoItem v) async {
    switch (v.source) {
      case VideoSource.commons:
        return v.directUrl;
      case VideoSource.dailymotion:
        return null;
      case VideoSource.archive:
        return _resolveArchive(v.id);
      case VideoSource.peertube:
        return _resolvePeertube(v);
    }
  }

  static Future<String?> _resolveArchive(String id) async {
    final j = await MiniHttp.getJson(Uri.https('archive.org', '/metadata/$id'), maxBytes: 4 * 1024 * 1024);
    final files = (j?['files'] as List?) ?? [];
    String? best;
    var bestScore = 1 << 60;
    for (final f in files) {
      if (f is! Map) continue;
      final name = (f['name'] ?? '').toString();
      final lower = name.toLowerCase();
      if (!(lower.endsWith('.mp4') || lower.endsWith('.webm'))) continue;
      final size = int.tryParse('${f['size'] ?? ''}') ?? 0;
      if (size < 300 * 1024) continue; // descarta miniaturas animadas
      final fmt = (f['format'] ?? '').toString().toLowerCase();
      final pref = (fmt.contains('h.264') || fmt.contains('mpeg4')) ? 0 : 1;
      final score = pref * (1 << 40) + size; // el más liviano de la mejor familia
      if (score < bestScore) {
        bestScore = score;
        best = name;
      }
    }
    if (best == null) return null;
    final path = best.split('/').map(Uri.encodeComponent).join('/');
    return 'https://archive.org/download/$id/$path';
  }

  static Future<String?> _resolvePeertube(VideoItem v) async {
    final host = v.host;
    if (host == null || host.isEmpty) return null;
    final j = await MiniHttp.getJson(Uri.https(host, '/api/v1/videos/${v.id}'), maxBytes: 1500000);
    if (j == null) return null;
    String? best;
    var bestScore = 1 << 30;
    for (final f in (j['files'] as List?) ?? const []) {
      if (f is! Map) continue;
      final url = (f['fileUrl'] ?? '').toString();
      if (!url.startsWith('https://')) continue;
      final res = int.tryParse('${(f['resolution'] as Map?)?['id'] ?? ''}') ?? 480;
      final score = (res - 480).abs();
      if (score < bestScore) {
        bestScore = score;
        best = url;
      }
    }
    if (best != null) return best;
    for (final pl in (j['streamingPlaylists'] as List?) ?? const []) {
      final url = (pl is Map ? (pl['playlistUrl'] ?? '') : '').toString();
      if (url.startsWith('https://')) return url; // HLS: ExoPlayer lo reproduce
    }
    return null;
  }
}
