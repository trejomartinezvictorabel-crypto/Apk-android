// Filtros del modo menor: temas peligrosos, listas de dominios, SafeSearch y puertas (gates).
// Solo se aplican a perfiles 6–17. El perfil Adulto nunca se filtra por temática.

import 'age_profile.dart';
import 'mini_http.dart';
import 'parental_controller.dart';

enum GateKind { ok, timeLock, topic, domain, format, download }

class GateResult {
  final bool allowed;
  final GateKind kind;
  final String title;
  final String message;
  final List<String> alternatives;
  final bool parentCanOverride;

  const GateResult.ok()
      : allowed = true,
        kind = GateKind.ok,
        title = '',
        message = '',
        alternatives = const [],
        parentCanOverride = false;

  const GateResult.block(
    this.kind,
    this.title,
    this.message, {
    this.alternatives = const [],
    this.parentCanOverride = false,
  }) : allowed = false;
}

class _TopicRule {
  final String key;
  final RegExp re;
  final String title;
  final String message;
  final List<String> alternatives;
  const _TopicRule(this.key, this.re, this.title, this.message, this.alternatives);
}

class SafeFilter {
  // ------------------------------------------------------------ normalización

  static String _plain(String s) {
    var t = s.toLowerCase();
    const m = {
      'á': 'a', 'é': 'e', 'í': 'i', 'ó': 'o', 'ú': 'u', 'ü': 'u', 'ñ': 'n',
      'à': 'a', 'è': 'e', 'ì': 'i', 'ò': 'o', 'ù': 'u', 'ä': 'a', 'ë': 'e', 'ï': 'i', 'ö': 'o',
    };
    m.forEach((k, v) => t = t.replaceAll(k, v));
    return t;
  }

  static String _clean(String s) => ' ${_plain(s).replaceAll(RegExp(r'[^a-z0-9]+'), ' ').trim()} ';

  /// Variante "leet": 0->o, 1->i, 3->e, 4->a, 5->s, @->a, $->s (evita evasiones triviales).
  static String _leet(String s) {
    var t = _plain(s);
    t = t
        .replaceAll('0', 'o')
        .replaceAll('1', 'i')
        .replaceAll('3', 'e')
        .replaceAll('4', 'a')
        .replaceAll('5', 's')
        .replaceAll('@', 'a')
        .replaceAll(r'$', 's');
    return ' ${t.replaceAll(RegExp(r'[^a-z]+'), ' ').trim()} ';
  }

  // ------------------------------------------------------------ temas peligrosos

  static const List<String> _safeIdeas = [
    'retos seguros de ciencia en casa',
    'historia de los castillos y fortalezas',
    'cómo funciona un cohete (física básica)',
    'ciberseguridad para principiantes: proteger mis cuentas',
  ];

  static final List<_TopicRule> _topics = [
    _TopicRule(
      'weapons',
      RegExp(r'\b(armas?( de fuego| caseras?)?|pistolas?|rifles?|fusiles?|escopetas?|municion|balas?|bombas?|explosivos?|granadas?|silenciador|ak ?47|weapons?|guns?|firearms?|explosives?|bombs?|grenades?|ammo|ammunition|silencer|molotov|detonador)\b'),
      'Tema no disponible en tu perfil',
      'Las armas y los explosivos son un tema de riesgo físico, por eso no se muestran en el modo estudio.',
      ['historia de las armas en los museos', 'seguridad y prevención de accidentes', 'cómo funciona un cohete (física básica)'],
    ),
    _TopicRule(
      'pyro',
      RegExp(r'\b(pirotecnia|petardos?|cohetes? caseros?|polvora|napalm|termita|thermite|fireworks?|gunpowder|cherry bomb|fuegos artificiales caseros)\b'),
      'Tema no disponible en tu perfil',
      'La pirotecnia y el fuego artificial casero pueden causar quemaduras graves.',
      ['cómo se produce el fuego: la química de la combustión', 'seguridad contra incendios en casa', 'experimentos de ciencia seguros'],
    ),
    _TopicRule(
      'chemicals',
      RegExp(r'\b(sustancias? peligrosas?|gas(es)? toxicos?|cianuro|veneno|venenos|envenenar|mezclar (quimicos|productos de limpieza|lejia)|acido fluorhidrico|acido sulfurico|sintetizar|sintesis de (drogas?|metanfetamina)|metanfetamina|cocaina|heroina|fentanilo|extasis|mdma|lsd|toxic gas|poisons?|cyanide|chloroform|cloroformo|ricina|ricin|nitroglicerina|nitroglycerin)\b'),
      'Tema no disponible en tu perfil',
      'Las sustancias peligrosas pueden hacerte daño. Si es una tarea escolar, pide ayuda a un docente.',
      ['qué es la química en la vida diaria', 'mezclas y reacciones seguras para experimentar', 'cómo cuidar mi salud'],
    ),
    _TopicRule(
      'drugs',
      RegExp(r'\b(comprar|conseguir|vender|fabricar|hacer|cultivar|consumir|dosis de)\b.{0,40}\b(drogas?|marihuana|cannabis|cocaina|heroina|metanfetamina|extasis|lsd|mdma|pastillas?)\b'),
      'Tema no disponible en tu perfil',
      'No se permiten consultas sobre conseguir o usar drogas.',
      ['cómo funciona el cuerpo humano', 'hábitos saludables para estudiar mejor', 'cómo cuidar mi salud'],
    ),
    _TopicRule(
      'hacking',
      RegExp(r'\b(hackear|hackeo|hacking|exploits?|ddos|keylogger|ransomware|botnet|robar contrasenas?|crackear|inyeccion sql|sql injection|crack wifi|hack wifi|doxing|doxear|brute ?force|(crear|hacer|programar|escribir)( un)? (malware|virus|ransomware|keylogger|troyano))\b'),
      'Tema no disponible en tu perfil',
      'El hacking malicioso no está permitido. Puedes aprender seguridad de forma positiva.',
      ['ciberseguridad para principiantes: proteger mis cuentas', 'cómo crear contraseñas seguras', 'cómo aprender a programar desde cero'],
    ),
    _TopicRule(
      'challenges',
      RegExp(r'\b(blackout challenge|reto del apagon|tide pods?|reto de la ballena azul|blue whale challenge|choking game|juego de la asfixia|skullbreaker|(reto|retos|challenge|challenges)\b.{0,30}\b(peligrosos?|extremos?|apagon|asfixia|desmayo|fuego))\b'),
      'Tema no disponible en tu perfil',
      'Los retos peligrosos pueden causar lesiones graves. Mejor elige retos seguros.',
      ['retos seguros de ciencia en casa', 'retos de lógica y matemáticas', 'retos de dibujo y creatividad'],
    ),
    _TopicRule(
      'gambling',
      RegExp(r'\b(apuestas?|apostar|casino|casinos|tragamonedas|poker|blackjack|ruleta|betting|sportsbook|slots?|jackpot|bet365|1xbet)\b'),
      'Tema no disponible en tu perfil',
      'Los juegos de apuestas no están permitidos para tu edad.',
      ['probabilidad y estadística explicadas fácil', 'cómo cuidar mi dinero: ahorro para jóvenes', 'juegos de lógica'],
    ),
    _TopicRule(
      'selfmed',
      RegExp(r'\b(automedicacion|automedicarse|dosis letal|sobredosis|mezclar (medicamentos|pastillas|alcohol)|cuanto (paracetamol|ibuprofeno|aspirina)|antibioticos sin receta|pastillas para (dormir|adelgazar)|medicamentos? sin receta|overdose|lethal dose)\b'),
      'Consulta con un adulto de confianza',
      'Los medicamentos solo deben usarse con indicación de un médico o de un adulto responsable.',
      ['cuándo ir al médico', 'cómo funciona el sistema inmunológico', 'hábitos para dormir mejor'],
    ),
    _TopicRule(
      'legal',
      RegExp(r'\b(falsificar|falsificacion|documentos? falsos?|identificacion falsa|fake id|como robar|robar (tiendas?|coches?|autos?|bancos?)|lavado de dinero|evadir (a la )?policia|ocultar pruebas|piratear|pirateria|estafar|extorsionar|cometer un delito|forjar)\b'),
      'Tema no disponible en tu perfil',
      'Esta consulta puede implicar riesgos legales. Si tienes dudas, pregunta a un adulto o a un docente.',
      ['derechos y responsabilidades de los jóvenes', 'cómo funcionan las leyes en tu país', 'ética y ciudadanía digital'],
    ),
    _TopicRule(
      'adult',
      RegExp(r'\b(porno\w*|porn|xxx|sexo explicito|erotic\w*|nsfw|hentai|desnud\w*|onlyfans|sexting|nudes?)\b'),
      'Contenido no apto',
      'Este contenido no está permitido en tu perfil.',
      ['educación sexual: preguntas frecuentes (con un adulto)', 'cómo funciona el cuerpo humano', 'cómo cuidar mi salud'],
    ),
    _TopicRule(
      'violence',
      RegExp(r'\b(gore|decapitaci\w*|tortura real|snuff|asesinato real|videos? de muertes?|peleas? callejeras?|real death)\b'),
      'Contenido no apto',
      'La violencia explícita no está permitida en tu perfil.',
      ['historia de la paz y la resolución de conflictos', 'deportes y artes marciales seguras', 'primeros auxilios básicos'],
    ),
    _TopicRule(
      'selfharm',
      RegExp(r'\b(suicid\w*|suicidarme|matarme|quitarme la vida|hacerme dano|autolesion\w*|cortarme|self harm|kill myself|want to die|quiero morir)\b'),
      'No tienes que pasar por esto solo/a',
      'Si algo te preocupa o te sientes muy mal, habla ahora con un adulto de confianza: familia, docente u orientador/a. Pedir ayuda es un acto de valentía.',
      ['técnicas de respiración para calmarme', 'cómo hablar con un adulto cuando me siento mal'],
    ),
  ];

  /// Devuelve un bloqueo si la consulta cae en un tema de riesgo; null si es segura.
  static GateResult? checkTopic(String raw) {
    final a = _clean(raw);
    final b = _leet(raw);
    for (final t in _topics) {
      if (t.re.hasMatch(a) || t.re.hasMatch(b)) {
        return GateResult.block(
          GateKind.topic,
          t.title,
          t.message,
          alternatives: t.key == 'selfharm' ? t.alternatives : [...t.alternatives, _safeIdeas.first].toSet().take(4).toList(),
          parentCanOverride: t.key != 'selfharm',
        );
      }
    }
    return null;
  }

  /// Riesgo en un texto largo (título/snippet/página): adulto, apuestas, violencia, gore.
  static String? textRisk(String raw) {
    final a = _clean(raw);
    for (final t in _topics) {
      if (t.key == 'adult' || t.key == 'gambling' || t.key == 'violence' || t.key == 'hacking') {
        if (t.re.hasMatch(a)) return t.key;
      }
    }
    return null;
  }

  // ------------------------------------------------------------ dominios

  /// Lista blanca educativa del perfil Infantil.
  static const Set<String> eduAllow = {
    'wikipedia.org', 'wikimedia.org', 'wiktionary.org', 'wikibooks.org', 'wikiversity.org', 'wikisource.org',
    'britannica.com', 'nationalgeographic.com', 'nationalgeographic.org', 'natgeokids.com',
    'nasa.gov', 'esa.int', 'noaa.gov', 'si.edu', 'loc.gov', 'amnh.org',
    'khanacademy.org', 'ck12.org', 'ducksters.com', 'kiddle.co', 'easyscienceforkids.com',
    'mathsisfun.com', 'pbskids.org', 'scholastic.com', 'worldwildlife.org', 'unesco.org',
    'rae.es', 'cervantesvirtual.com',
  };

  static const Map<String, Set<String>> _blocked = {
    'distractor': {
      'tiktok.com', 'instagram.com', 'facebook.com', 'fb.com', 'reddit.com', 'discord.com', 'discord.gg',
      'twitter.com', 'x.com', 'snapchat.com', 'twitch.tv', 'kick.com', 'tumblr.com', '9gag.com',
      'netflix.com', 'primevideo.com', 'disneyplus.com', 'hbomax.com', 'max.com', 'youtube.com', 'youtu.be',
      'roblox.com', 'fortnite.com', 'epicgames.com', 'steampowered.com', 'miniclip.com', 'poki.com',
      'friv.com', 'crazygames.com', 'y8.com', 'telegram.org', 't.me',
    },
    'anon': {
      'omegle.com', 'chatroulette.com', 'ome.tv', 'chatrandom.com', 'camsurf.com', '4chan.org', '8kun.top',
    },
    'gambling': {
      'bet365.com', 'betway.com', '1xbet.com', 'pokerstars.com', 'draftkings.com', 'fanduel.com', 'stake.com',
      'bovada.lv', '888casino.com', 'caliente.mx', 'codere.com', 'codere.mx',
    },
    'adult': {
      'pornhub.com', 'xvideos.com', 'xnxx.com', 'xhamster.com', 'redtube.com', 'youporn.com', 'onlyfans.com',
      'chaturbate.com', 'stripchat.com', 'spankbang.com', 'e621.net',
    },
    'violence': {'bestgore.com', 'kaotic.com', 'liveleak.com'},
    'malware': {
      'thepiratebay.org', '1337x.to', 'rarbg.to', 'fitgirl-repacks.site', 'exploit-db.com', 'hackforums.net',
      'nulled.to', 'cracked.io',
    },
  };

  static const Map<String, String> _blockedMsg = {
    'distractor': 'Esta plataforma distrae del estudio (redes sociales, juegos o streaming).',
    'anon': 'Los chats anónimos no son seguros para tu edad.',
    'gambling': 'Los sitios de apuestas no están permitidos para tu edad.',
    'adult': 'Este sitio tiene contenido para adultos.',
    'violence': 'Este sitio muestra violencia explícita.',
    'malware': 'Este sitio es de riesgo (piratería, malware o hacking).',
  };

  static bool hostIn(String host, Iterable<String> domains) {
    final h = host.toLowerCase();
    for (final d in domains) {
      if (h == d || h.endsWith('.$d')) return true;
    }
    return false;
  }

  /// Categoría bloqueada del host o null.
  static String? blockedCategory(String host) {
    for (final e in _blocked.entries) {
      if (hostIn(host, e.value)) return e.key;
    }
    return null;
  }

  static String blockedMessage(String category) => _blockedMsg[category] ?? 'Sitio no permitido.';

  static const Set<String> _shorteners = {
    'bit.ly', 't.co', 'tinyurl.com', 'goo.gl', 'ow.ly', 'is.gd', 'buff.ly', 'rebrand.ly', 'cutt.ly',
    'shorturl.at', 'tiny.cc', 't.ly', 'rb.gy', 'lnkd.in', 's.id',
  };

  static bool isShortener(String host) => hostIn(host, _shorteners);

  /// Operador de búsqueda para restringir DuckDuckGo a la lista blanca infantil.
  static String childSiteOperator(List<String> extra) {
    final sites = <String>[
      'wikipedia.org', 'britannica.com', 'nationalgeographic.com', 'nasa.gov', 'khanacademy.org', 'kiddle.co',
      ...extra.take(2),
    ];
    return '(${sites.map((s) => 'site:$s').join(' OR ')})';
  }

  /// DNS familiar de Cloudflare vs DNS normal: bloquea adulto/malware sin API key.
  static Future<bool> familyBlocked(String host) async {
    final plain = await MiniHttp.getJson(
      Uri.https('cloudflare-dns.com', '/dns-query', {'name': host, 'type': 'A'}),
      headers: {'Accept': 'application/dns-json'},
      maxBytes: 65536,
    );
    final fam = await MiniHttp.getJson(
      Uri.https('family.cloudflare-dns.com', '/dns-query', {'name': host, 'type': 'A'}),
      headers: {'Accept': 'application/dns-json'},
      maxBytes: 65536,
    );
    if (plain == null || fam == null) return false;
    final plainOk = plain['Status'] == 0 && ((plain['Answer'] as List?)?.isNotEmpty ?? false);
    final ans = (fam['Answer'] as List?) ?? [];
    final blocked = fam['Status'] == 3 || ans.any((a) => a is Map && a['data']?.toString() == '0.0.0.0');
    return plainOk && blocked;
  }
}

/// Puertas de acceso según el perfil activo.
extension ParentalGate on ParentalController {
  GateResult _timeLockResult() {
    final r = rules;
    if (lock == LockKind.schedule) {
      return GateResult.block(
        GateKind.timeLock,
        'Fuera del horario permitido',
        'La navegación web está disponible de ${StudyRules.fmt(r.startMinute)} a ${StudyRules.fmt(r.endMinute)}. '
            'Mientras tanto puedes leer tus guías guardadas.',
      );
    }
    final rest = restRemainingMinutes;
    return GateResult.block(
      GateKind.timeLock,
      'Hora de una pausa',
      'Terminaste tu bloque de ${r.sessionMinutes} minutos. Descansa${rest > 0 ? ' unos $rest min' : ''}, estira el cuerpo y '
          'toma agua. Puedes leer tus guías guardadas.',
    );
  }

  /// Búsquedas y creación de guías.
  Future<GateResult> gateQuery(String q, {bool parentApproved = false}) async {
    if (lock != LockKind.none) return _timeLockResult();
    if (!isMinor) return const GateResult.ok();
    if (!parentApproved) {
      final v = SafeFilter.checkTopic(q);
      if (v != null) return v;
    }
    return const GateResult.ok();
  }

  /// Formatos de descarga permitidos: null = todos (Adulto), vacío = ninguno (Infantil).
  Set<String>? get allowedDownloadExts {
    switch (effective) {
      case AgeProfile.adult:
        return null;
      case AgeProfile.teen:
        return const {'pdf', 'txt', 'md'};
      case AgeProfile.child:
        return const <String>{};
    }
  }

  GateResult gateDownloadExt(String? ext) {
    final allowed = allowedDownloadExts;
    if (allowed == null) return const GateResult.ok();
    if (effective == AgeProfile.child) {
      return const GateResult.block(
        GateKind.download,
        'Descargas bloqueadas',
        'En el perfil Infantil no se pueden descargar ni subir archivos. Un adulto puede cambiarlo con el PIN.',
      );
    }
    if (ext != null && !allowed.contains(ext)) {
      return GateResult.block(
        GateKind.format,
        'Formato no permitido',
        'En tu perfil solo puedes descargar archivos .pdf, .txt y .md. Este es .$ext.',
      );
    }
    return const GateResult.ok();
  }

  /// URL escrita a mano, enlaces de Rayos X y descargas.
  Future<GateResult> gateUrl(Uri u, {String? ext, bool forDownload = false}) async {
    if (lock != LockKind.none) return _timeLockResult();
    if (!isMinor) return const GateResult.ok();
    if (forDownload) {
      final d = gateDownloadExt(ext);
      if (!d.allowed) return d;
    }
    final host = u.host.toLowerCase();
    if (u.scheme != 'http' && u.scheme != 'https') {
      return const GateResult.block(GateKind.domain, 'Enlace no permitido', 'Solo se permiten enlaces web.');
    }
    if (effective == AgeProfile.child) {
      final ok = SafeFilter.hostIn(host, SafeFilter.eduAllow) || SafeFilter.hostIn(host, extraAllowed);
      if (!ok) {
        return const GateResult.block(
          GateKind.domain,
          'Solo sitios educativos aprobados',
          'En el perfil Infantil solo puedes entrar a sitios educativos aprobados (enciclopedias, ciencia, matemáticas). '
              'Prueba escribiendo lo que quieres aprender en el buscador.',
          alternatives: ['wikipedia.org', 'nasa.gov', 'khanacademy.org', 'kiddle.co'],
        );
      }
      return const GateResult.ok();
    }
    // Estudiantes 12–17
    if (SafeFilter.isShortener(host) || InternetAddressLike.isIp(host) || host.contains('xn--')) {
      return const GateResult.block(
        GateKind.domain,
        'Enlace no verificable',
        'Los acortadores, direcciones IP y dominios disfrazados no se permiten en el modo estudio.',
      );
    }
    final cat = SafeFilter.blockedCategory(host);
    if (cat != null) {
      return GateResult.block(GateKind.domain, 'Sitio bloqueado', SafeFilter.blockedMessage(cat));
    }
    if (SafeFilter.textRisk('$host ${u.path}') != null) {
      return const GateResult.block(GateKind.domain, 'Sitio bloqueado', 'El enlace parece de contenido no apto para tu edad.');
    }
    try {
      if (await SafeFilter.familyBlocked(host)) {
        return const GateResult.block(
          GateKind.domain,
          'Sitio bloqueado por el filtro de red',
          'Este dominio figura como contenido para adultos o peligroso (malware/phishing).',
        );
      }
    } catch (_) {}
    return const GateResult.ok();
  }

  /// Filtro de resultados de búsqueda. Adulto: siempre true.
  bool allowResult(String url, String title, String snippet) {
    if (!isMinor) return true;
    Uri? u;
    try {
      u = Uri.parse(url);
    } catch (_) {
      return false;
    }
    final host = u.host.toLowerCase();
    if (host.isEmpty) return false;
    if (effective == AgeProfile.child) {
      if (!(SafeFilter.hostIn(host, SafeFilter.eduAllow) || SafeFilter.hostIn(host, extraAllowed))) return false;
    } else {
      if (SafeFilter.blockedCategory(host) != null) return false;
      if (SafeFilter.isShortener(host)) return false;
    }
    if (SafeFilter.textRisk('$title $snippet $host ${u.path}') != null) return false;
    return true;
  }

  /// Filtro de texto suelto (títulos de imágenes, etc.).
  bool allowText(String s) => !isMinor || SafeFilter.textRisk(s) == null;

  /// Parámetro kp de DuckDuckGo: 1 = SafeSearch estricto, -2 = desactivado (Adulto).
  String get safeSearchKp => isMinor ? '1' : '-2';
}

/// Evita depender de dart:io en este archivo.
class InternetAddressLike {
  static bool isIp(String host) {
    if (RegExp(r'^\d{1,3}(\.\d{1,3}){3}$').hasMatch(host)) return true;
    return host.contains(':'); // IPv6
  }
}
