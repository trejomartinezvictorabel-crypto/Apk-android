// Interfaz del Modo Estudio / Restricción de Edad. Alto contraste: #000000 y #FFFFFF.

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';

import 'age_profile.dart';
import 'parental_controller.dart';
import 'safe_filter.dart';
import 'study_builder.dart';

const Color _black = Color(0xFF000000);
const Color _white = Color(0xFFFFFFFF);
const Color _dim = Color(0xB3FFFFFF);
const Color _panel = Color(0xFF0D0D0D);
const Color _line = Color(0x3DFFFFFF);
const Color _bad = Color(0xFFF87171);
const Color _warn = Color(0xFFFBBF24);
const Color _ok = Color(0xFF4ADE80);

Widget _box(Widget child, {Color border = _line, double bw = 1}) => Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: _panel, border: Border.all(color: border, width: bw), borderRadius: BorderRadius.circular(14)),
      child: child,
    );

Widget _btn(String label, IconData icon, VoidCallback? onTap, {bool outlined = false}) {
  final child = Row(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [Icon(icon, size: 20), const SizedBox(width: 8), Flexible(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w700), textAlign: TextAlign.center))],
  );
  return SizedBox(
    width: double.infinity,
    height: 50,
    child: outlined
        ? OutlinedButton(style: OutlinedButton.styleFrom(foregroundColor: _white, side: const BorderSide(color: _white)), onPressed: onTap, child: child)
        : FilledButton(style: FilledButton.styleFrom(backgroundColor: _white, foregroundColor: _black), onPressed: onTap, child: child),
  );
}

String _mmss(int s) {
  if (s < 0) return '';
  final m = s ~/ 60;
  final r = s % 60;
  return '${m.toString().padLeft(2, '0')}:${r.toString().padLeft(2, '0')}';
}

// ============================================================================
// Franja visible en la barra superior: "Modo Estudio / Restricción de Edad"
// ============================================================================

class ParentalStrip extends StatelessWidget implements PreferredSizeWidget {
  final ParentalController controller;
  final VoidCallback onPanel;
  final VoidCallback onGuides;
  const ParentalStrip({super.key, required this.controller, required this.onPanel, required this.onGuides});

  @override
  Size get preferredSize => const Size.fromHeight(50);

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) {
        final minor = controller.isMinor;
        return Container(
          height: 50,
          padding: const EdgeInsets.fromLTRB(12, 0, 4, 6),
          child: Row(
            children: [
              Expanded(
                child: InkWell(
                  borderRadius: BorderRadius.circular(20),
                  onTap: onPanel,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: minor ? _white : _black,
                      border: Border.all(color: _white),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      children: [
                        Icon(minor ? Icons.lock : Icons.school_outlined, size: 17, color: minor ? _black : _white),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Modo Estudio / Restricción de Edad',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: minor ? _black : _white),
                          ),
                        ),
                        ValueListenableBuilder<int>(
                          valueListenable: controller.secondsLeft,
                          builder: (_, s, __) => Text(
                            minor ? '${controller.effective.shortLabel} ${_mmss(s)}' : controller.effective.shortLabel,
                            style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: minor ? _black : _dim),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              IconButton(tooltip: 'Mis guías de estudio', icon: const Icon(Icons.menu_book_outlined), onPressed: onGuides),
            ],
          ),
        );
      },
    );
  }
}

// ============================================================================
// PIN
// ============================================================================

Future<bool> askPin(BuildContext context, ParentalController c, {String title = 'PIN parental', String? subtitle}) async {
  final r = await showDialog<bool>(
    context: context,
    barrierDismissible: false,
    builder: (_) => _PinDialog(controller: c, title: title, subtitle: subtitle),
  );
  return r == true;
}

class _PinDialog extends StatefulWidget {
  final ParentalController controller;
  final String title;
  final String? subtitle;
  const _PinDialog({required this.controller, required this.title, this.subtitle});

  @override
  State<_PinDialog> createState() => _PinDialogState();
}

class _PinDialogState extends State<_PinDialog> {
  final TextEditingController _t = TextEditingController();
  String? _msg;
  Duration _lock = Duration.zero;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _syncLock();
  }

  void _syncLock() {
    _lock = widget.controller.pinLockRemaining;
    _timer?.cancel();
    if (_lock > Duration.zero) {
      _timer = Timer.periodic(const Duration(seconds: 1), (_) {
        final r = widget.controller.pinLockRemaining;
        if (!mounted) return;
        setState(() {
          _lock = r;
          if (r == Duration.zero) {
            _msg = null;
            _timer?.cancel();
          }
        });
      });
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _t.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final pin = _t.text.trim();
    if (!ParentalController.validPin(pin)) {
      setState(() => _msg = 'El PIN tiene de 4 a 6 dígitos.');
      return;
    }
    final r = await widget.controller.verifyPin(pin);
    if (!mounted) return;
    _t.clear();
    if (r.ok) {
      Navigator.pop(context, true);
    } else if (r.locked) {
      setState(() => _msg = 'Demasiados intentos. Bloqueado temporalmente.');
      _syncLock();
    } else {
      setState(() => _msg = r.attemptsLeft > 0 ? 'PIN incorrecto. Intentos restantes: ${r.attemptsLeft}.' : 'PIN no disponible.');
    }
  }

  @override
  Widget build(BuildContext context) {
    final locked = _lock > Duration.zero;
    return AlertDialog(
      title: Text(widget.title),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (widget.subtitle != null) Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(widget.subtitle!, style: const TextStyle(color: _dim, fontSize: 13))),
          if (locked)
            Text('Bloqueado por intentos fallidos.\nVuelve a intentar en ${_mmss(_lock.inSeconds)}.', style: const TextStyle(color: _bad, fontWeight: FontWeight.w700))
          else
            TextField(
              controller: _t,
              autofocus: true,
              obscureText: true,
              keyboardType: TextInputType.number,
              maxLength: 6,
              onSubmitted: (_) => _submit(),
              decoration: const InputDecoration(border: OutlineInputBorder(), counterText: '', hintText: 'PIN de 4 a 6 dígitos'),
            ),
          if (_msg != null && !locked) Padding(padding: const EdgeInsets.only(top: 8), child: Text(_msg!, style: const TextStyle(color: _bad, fontSize: 13))),
        ],
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: _white, foregroundColor: _black),
          onPressed: locked ? null : _submit,
          child: const Text('Aceptar'),
        ),
      ],
    );
  }
}

/// Abre el panel. Si hay perfil menor activo exige el PIN primero.
Future<void> openParentalPanel(BuildContext context, ParentalController c) async {
  if (c.isMinor) {
    final ok = await askPin(context, c, title: 'PIN parental', subtitle: 'Solo un adulto puede cambiar el perfil o las reglas.');
    if (!ok || !context.mounted) return;
  }
  await Navigator.of(context).push(MaterialPageRoute<bool>(builder: (_) => ParentalSettingsPage(controller: c)));
}

// ============================================================================
// Selección de perfil + reglas
// ============================================================================

class ParentalSettingsPage extends StatefulWidget {
  final ParentalController controller;
  final bool firstRun;
  const ParentalSettingsPage({super.key, required this.controller, this.firstRun = false});

  @override
  State<ParentalSettingsPage> createState() => _ParentalSettingsPageState();
}

class _ParentalSettingsPageState extends State<ParentalSettingsPage> {
  AgeProfile? _sel;
  late int _session;
  late int _start;
  late int _end;
  final TextEditingController _pin1 = TextEditingController();
  final TextEditingController _pin2 = TextEditingController();
  final TextEditingController _domains = TextEditingController();
  String? _err;
  bool _saving = false;

  ParentalController get c => widget.controller;

  @override
  void initState() {
    super.initState();
    _sel = c.profile;
    _session = c.rules.sessionMinutes;
    _start = c.rules.startMinute;
    _end = c.rules.endMinute;
    _domains.text = c.extraAllowed.join(', ');
  }

  @override
  void dispose() {
    _pin1.dispose();
    _pin2.dispose();
    _domains.dispose();
    super.dispose();
  }

  List<String> _parseDomains() {
    final out = <String>[];
    for (final raw in _domains.text.split(RegExp(r'[,\s]+'))) {
      var d = raw.trim().toLowerCase();
      if (d.isEmpty) continue;
      d = d.replaceFirst(RegExp(r'^https?://'), '').split('/').first;
      if (RegExp(r'^[a-z0-9.-]+\.[a-z]{2,}$').hasMatch(d) && !out.contains(d)) out.add(d);
    }
    return out.take(10).toList();
  }

  Future<void> _pickTime(bool start) async {
    final cur = start ? _start : _end;
    final t = await showTimePicker(context: context, initialTime: TimeOfDay(hour: cur ~/ 60, minute: cur % 60));
    if (t == null) return;
    setState(() {
      if (start) {
        _start = t.hour * 60 + t.minute;
      } else {
        _end = t.hour * 60 + t.minute;
      }
    });
  }

  Future<void> _save() async {
    final sel = _sel;
    if (sel == null) return;
    setState(() => _err = null);
    if (sel == AgeProfile.adult) {
      setState(() => _saving = true);
      await c.activate(AgeProfile.adult);
      if (mounted) Navigator.pop(context, true);
      return;
    }
    final needNew = !(c.profile?.isMinor ?? false) || !c.hasPin;
    final p1 = _pin1.text.trim();
    final p2 = _pin2.text.trim();
    if (needNew || p1.isNotEmpty) {
      if (!ParentalController.validPin(p1)) {
        setState(() => _err = 'Crea un PIN numérico de 4 a 6 dígitos.');
        return;
      }
      if (p1 != p2) {
        setState(() => _err = 'Los PIN no coinciden.');
        return;
      }
    }
    if (_start == _end) {
      setState(() => _err = 'La hora de inicio y fin no pueden ser iguales.');
      return;
    }
    setState(() => _saving = true);
    await c.activate(
      sel,
      newPin: (needNew || p1.isNotEmpty) ? p1 : null,
      rules: StudyRules(sessionMinutes: _session, startMinute: _start, endMinute: _end),
      extraAllowed: _parseDomains(),
    );
    if (mounted) Navigator.pop(context, true);
  }

  Widget _profileCard(AgeProfile p, IconData icon, List<String> lines) {
    final sel = _sel == p;
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: () => setState(() => _sel = p),
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: sel ? _white : _panel,
          border: Border.all(color: _white, width: sel ? 2 : 1),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Icon(icon, color: sel ? _black : _white),
              const SizedBox(width: 8),
              Expanded(child: Text(p.title, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: sel ? _black : _white))),
              if (sel) const Icon(Icons.check_circle, color: _black),
            ]),
            const SizedBox(height: 6),
            for (final l in lines) Padding(padding: const EdgeInsets.only(top: 2), child: Text('• $l', style: TextStyle(fontSize: 12.5, height: 1.3, color: sel ? _black : _dim))),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final minor = _sel?.isMinor ?? false;
    final needNew = !(c.profile?.isMinor ?? false) || !c.hasPin;
    return PopScope(
      canPop: !widget.firstRun,
      child: Scaffold(
        backgroundColor: _black,
        appBar: AppBar(
          title: Text(widget.firstRun ? 'Elige el perfil de uso' : 'Modo Estudio / Restricción de Edad'),
          automaticallyImplyLeading: !widget.firstRun,
        ),
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 24),
            children: [
              const Padding(
                padding: EdgeInsets.only(bottom: 10),
                child: Text('¿Quién usará la app? El perfil de menor queda guardado y solo un adulto con PIN puede cambiarlo.', style: TextStyle(color: _dim, height: 1.4)),
              ),
              _profileCard(AgeProfile.child, Icons.child_care, const [
                'Lista blanca educativa estricta y SafeSearch máximo',
                'No se pueden escribir URLs fuera de sitios aprobados',
                'Explicaciones en máximo 3 pasos con lectura en voz alta',
                'Sin descargas ni subida de archivos',
                'Temas de riesgo bloqueados · temporizador y horario',
              ]),
              _profileCard(AgeProfile.teen, Icons.school, const [
                'SafeSearch estricto; bloquea adultos, apuestas, violencia, drogas, chats anónimos y malware',
                'Bloquea redes sociales, juegos en línea y streaming no educativo',
                'Guías, resúmenes, tutoriales por niveles y cuestionarios de autoevaluación',
                'Descargas solo .pdf, .txt y .md verificadas por Magic Bytes; sin subida de archivos',
                'Temas de riesgo bloqueados · temporizador y horario',
              ]),
              _profileCard(AgeProfile.adult, Icons.person, const [
                'Sin restricciones de búsqueda, temática ni listas',
                'Filtro Medio siempre activo: URL/reputación, malware, Magic Bytes y SHA-256',
              ]),
              if (minor) ...[
                const SizedBox(height: 4),
                _box(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Tiempo de estudio', style: TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 8),
                  Wrap(spacing: 8, children: [
                    for (final m in const [30, 45])
                      ChoiceChip(
                        label: Text('Bloques de $m min'),
                        selected: _session == m,
                        selectedColor: _white,
                        labelStyle: TextStyle(color: _session == m ? _black : _white, fontWeight: FontWeight.w700),
                        backgroundColor: _black,
                        side: const BorderSide(color: _white),
                        showCheckmark: false,
                        onSelected: (_) => setState(() => _session = m),
                      ),
                  ]),
                  const SizedBox(height: 12),
                  const Text('Franja horaria permitida', style: TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 8),
                  Row(children: [
                    Expanded(child: OutlinedButton(style: OutlinedButton.styleFrom(foregroundColor: _white, side: const BorderSide(color: _white)), onPressed: () => _pickTime(true), child: Text('Desde ${StudyRules.fmt(_start)}'))),
                    const SizedBox(width: 8),
                    Expanded(child: OutlinedButton(style: OutlinedButton.styleFrom(foregroundColor: _white, side: const BorderSide(color: _white)), onPressed: () => _pickTime(false), child: Text('Hasta ${StudyRules.fmt(_end)}'))),
                  ]),
                  const SizedBox(height: 6),
                  const Text('Fuera del horario o al terminar el bloque se bloquea la web; solo quedan las guías guardadas, salvo con el PIN. El horario depende del reloj del equipo.', style: TextStyle(color: _dim, fontSize: 12)),
                  if (_sel == AgeProfile.child) ...[
                    const SizedBox(height: 14),
                    const Text('Sitios extra permitidos (Infantil)', style: TextStyle(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 6),
                    TextField(
                      controller: _domains,
                      autocorrect: false,
                      decoration: const InputDecoration(border: OutlineInputBorder(), hintText: 'escuela.edu.mx, museo.org', isDense: true),
                    ),
                  ],
                ])),
                _box(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(needNew ? 'Crea el PIN parental' : 'Cambiar PIN (opcional)', style: const TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  const Text('4 a 6 dígitos. Se guarda solo en este equipo con hash SHA-256 salado. 3 intentos fallidos bloquean 5 minutos.', style: TextStyle(color: _dim, fontSize: 12)),
                  const SizedBox(height: 8),
                  TextField(controller: _pin1, obscureText: true, keyboardType: TextInputType.number, maxLength: 6, decoration: const InputDecoration(border: OutlineInputBorder(), counterText: '', hintText: 'PIN', isDense: true)),
                  const SizedBox(height: 8),
                  TextField(controller: _pin2, obscureText: true, keyboardType: TextInputType.number, maxLength: 6, decoration: const InputDecoration(border: OutlineInputBorder(), counterText: '', hintText: 'Repite el PIN', isDense: true)),
                ])),
              ],
              if (_err != null) _box(Text(_err!, style: const TextStyle(color: _bad, fontWeight: FontWeight.w600)), border: _bad),
              _btn(_sel == AgeProfile.adult ? 'Guardar perfil Adulto' : 'Guardar y activar', Icons.check, (_sel == null || _saving) ? null : _save),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================================
// Tarjetas para la pantalla principal
// ============================================================================

class LockCard extends StatelessWidget {
  final ParentalController controller;
  final VoidCallback onGuides;
  const LockCard({super.key, required this.controller, required this.onGuides});

  @override
  Widget build(BuildContext context) {
    final r = controller.rules;
    final isSchedule = controller.lock == LockKind.schedule;
    return _box(
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(isSchedule ? Icons.nightlight_round : Icons.self_improvement, color: _warn),
          const SizedBox(width: 8),
          Expanded(child: Text(isSchedule ? 'Fuera del horario permitido' : 'Hora de una pausa', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17))),
        ]),
        const SizedBox(height: 8),
        Text(
          isSchedule
              ? 'La navegación web está disponible de ${StudyRules.fmt(r.startMinute)} a ${StudyRules.fmt(r.endMinute)}.'
              : 'Terminaste tu bloque de ${r.sessionMinutes} minutos. Descansa ${controller.restRemainingMinutes > 0 ? 'unos ${controller.restRemainingMinutes} min' : 'un momento'}: estira el cuerpo, toma agua y mira lejos de la pantalla.',
          style: const TextStyle(height: 1.4),
        ),
        const SizedBox(height: 4),
        const Text('Mientras tanto puedes leer tus guías de estudio guardadas.', style: TextStyle(color: _dim, fontSize: 13)),
        const SizedBox(height: 12),
        _btn('Mis guías (lectura local)', Icons.menu_book, onGuides),
        const SizedBox(height: 8),
        _btn('Ingresar PIN parental', Icons.key, () async {
          final ok = await askPin(context, controller, title: 'PIN parental', subtitle: 'Un adulto puede abrir un nuevo bloque de ${r.sessionMinutes} minutos.');
          if (ok) await controller.grantBlock();
        }, outlined: true),
      ]),
      border: _warn,
      bw: 2,
    );
  }
}

class GateCard extends StatelessWidget {
  final GateResult result;
  final void Function(String) onAlternative;
  final VoidCallback? onParentApprove;
  final VoidCallback? onGuides;
  const GateCard({super.key, required this.result, required this.onAlternative, this.onParentApprove, this.onGuides});

  @override
  Widget build(BuildContext context) {
    final isSupport = result.title.startsWith('No tienes que pasar');
    return _box(
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(isSupport ? Icons.favorite_border : Icons.shield_outlined, color: isSupport ? _ok : _warn),
          const SizedBox(width: 8),
          Expanded(child: Text(result.title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
        ]),
        const SizedBox(height: 8),
        Text(result.message, style: const TextStyle(height: 1.4)),
        if (result.alternatives.isNotEmpty) ...[
          const SizedBox(height: 10),
          const Text('Prueba mejor con:', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
          const SizedBox(height: 6),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final a in result.alternatives)
              ActionChip(
                label: Text(a, style: const TextStyle(color: _white, fontSize: 12.5)),
                backgroundColor: _black,
                side: const BorderSide(color: _white),
                onPressed: () => onAlternative(a),
              ),
          ]),
        ],
        if (onParentApprove != null) ...[
          const SizedBox(height: 10),
          TextButton.icon(onPressed: onParentApprove, icon: const Icon(Icons.key, size: 18), label: const Text('Permiso de un adulto (PIN)')),
        ],
        if (onGuides != null) ...[
          const SizedBox(height: 6),
          TextButton.icon(onPressed: onGuides, icon: const Icon(Icons.menu_book, size: 18), label: const Text('Ver mis guías')),
        ],
      ]),
      border: result.kind == GateKind.timeLock ? _warn : _white,
    );
  }
}

class ChildExplainCard extends StatefulWidget {
  final ChildExplain explain;
  final VoidCallback onSave;
  const ChildExplainCard({super.key, required this.explain, required this.onSave});

  @override
  State<ChildExplainCard> createState() => _ChildExplainCardState();
}

class _ChildExplainCardState extends State<ChildExplainCard> {
  final FlutterTts _tts = FlutterTts();
  bool _speaking = false;

  @override
  void initState() {
    super.initState();
    _tts.setCompletionHandler(() {
      if (mounted) setState(() => _speaking = false);
    });
    _tts.setCancelHandler(() {
      if (mounted) setState(() => _speaking = false);
    });
  }

  @override
  void dispose() {
    _tts.stop();
    super.dispose();
  }

  Future<void> _toggle() async {
    if (_speaking) {
      await _tts.stop();
      if (mounted) setState(() => _speaking = false);
      return;
    }
    setState(() => _speaking = true);
    await _tts.speak(widget.explain.spokenText);
  }

  @override
  Widget build(BuildContext context) {
    final e = widget.explain;
    return _box(
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.lightbulb_outline),
          const SizedBox(width: 8),
          Expanded(child: Text('${e.topic} en ${e.steps.length} pasos', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17))),
        ]),
        const SizedBox(height: 10),
        for (var i = 0; i < e.steps.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Container(
                width: 30,
                height: 30,
                alignment: Alignment.center,
                decoration: const BoxDecoration(color: _white, shape: BoxShape.circle),
                child: Text('${i + 1}', style: const TextStyle(color: _black, fontWeight: FontWeight.w900)),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(e.steps[i].text, style: const TextStyle(fontSize: 16, height: 1.4)),
                  const SizedBox(height: 4),
                  Text(e.steps[i].example, style: const TextStyle(color: _dim, fontSize: 14, height: 1.35)),
                ]),
              ),
            ]),
          ),
        Row(children: [
          Expanded(child: _btn(_speaking ? 'Detener' : 'Leer en voz alta', _speaking ? Icons.stop : Icons.volume_up, _toggle)),
          const SizedBox(width: 8),
          IconButton(tooltip: 'Guardar en Mis guías', icon: const Icon(Icons.bookmark_add_outlined), onPressed: widget.onSave),
        ]),
      ]),
    );
  }
}

// ============================================================================
// Guías de estudio (lectura local siempre disponible)
// ============================================================================

class GuidesPage extends StatefulWidget {
  final ParentalController controller;
  const GuidesPage({super.key, required this.controller});

  @override
  State<GuidesPage> createState() => _GuidesPageState();
}

class _GuidesPageState extends State<GuidesPage> {
  List<StudyGuide> _guides = [];
  bool _busy = false;
  String? _msg;

  ParentalController get c => widget.controller;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final g = await GuideStore.load();
    if (mounted) setState(() => _guides = g);
  }

  Future<void> _showGate(GateResult g) async {
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(g.title),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(g.message),
          if (g.alternatives.isNotEmpty) ...[
            const SizedBox(height: 10),
            const Text('Ideas seguras:', style: TextStyle(fontWeight: FontWeight.w700)),
            for (final a in g.alternatives) Text('• $a', style: const TextStyle(color: _dim)),
          ],
        ]),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Entendido'))],
      ),
    );
  }

  Future<void> _create() async {
    final t = TextEditingController();
    final topic = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Nueva guía de estudio'),
        content: TextField(controller: t, autofocus: true, decoration: const InputDecoration(border: OutlineInputBorder(), hintText: 'Tema: fotosíntesis, Revolución Francesa…')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
          FilledButton(style: FilledButton.styleFrom(backgroundColor: _white, foregroundColor: _black), onPressed: () => Navigator.pop(ctx, t.text.trim()), child: const Text('Crear')),
        ],
      ),
    );
    t.dispose();
    if (topic == null || topic.isEmpty) return;
    final gate = await c.gateQuery(topic);
    if (!gate.allowed) {
      if (mounted) await _showGate(gate);
      return;
    }
    setState(() {
      _busy = true;
      _msg = 'Buscando información fiable sobre "$topic"…';
    });
    try {
      final w = await StudyBuilder.fetch(topic);
      if (w == null) {
        setState(() => _msg = 'No encontré información suficiente sobre ese tema. Prueba con otras palabras.');
        return;
      }
      if (c.isMinor) {
        final blocked = SafeFilter.checkTopic(w.title) ?? (SafeFilter.textRisk('${w.title} ${w.lead}') != null
            ? const GateResult.block(GateKind.topic, 'Tema no disponible en tu perfil', 'El contenido encontrado no es apto para tu edad.')
            : null);
        if (blocked != null) {
          if (mounted) await _showGate(blocked);
          setState(() => _msg = null);
          return;
        }
      }
      StudyGuide g;
      if (c.effective == AgeProfile.child) {
        final ce = StudyBuilder.buildChild(w);
        if (ce == null) {
          setState(() => _msg = 'No pude armar una explicación corta de ese tema.');
          return;
        }
        g = ce.toGuide();
      } else {
        g = StudyBuilder.buildLevels(w);
      }
      await GuideStore.save(g);
      await _reload();
      setState(() => _msg = null);
      if (mounted) await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => GuideViewPage(guide: g)));
    } catch (e) {
      setState(() => _msg = 'No se pudo crear la guía. Revisa tu conexión.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _black,
      appBar: AppBar(title: const Text('Mis guías de estudio')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(12, 4, 12, 24),
          children: [
            _btn(c.lock != LockKind.none ? 'Crear guía (bloqueado ahora)' : 'Crear guía nueva', Icons.add, (_busy || c.lock != LockKind.none) ? null : _create),
            const SizedBox(height: 10),
            if (_busy) const Padding(padding: EdgeInsets.only(bottom: 10), child: LinearProgressIndicator(color: _white, backgroundColor: Color(0xFF222222))),
            if (_msg != null) _box(Text(_msg!, style: const TextStyle(color: _dim))),
            if (_guides.isEmpty && !_busy)
              const Padding(padding: EdgeInsets.only(top: 24), child: Text('Aún no hay guías guardadas. Se guardan solo en este equipo y puedes leerlas sin conexión y aunque la web esté bloqueada.', style: TextStyle(color: _dim, height: 1.4))),
            for (final g in _guides)
              _box(
                InkWell(
                  onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => GuideViewPage(guide: g))),
                  child: Row(children: [
                    const Icon(Icons.menu_book_outlined),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(g.topic, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                        Text('${g.levels.length} nivel(es) · ${g.levels.fold<int>(0, (a, l) => a + l.quiz.length)} preguntas', style: const TextStyle(color: _dim, fontSize: 12.5)),
                      ]),
                    ),
                    IconButton(
                      tooltip: 'Borrar',
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () async {
                        await GuideStore.delete(g.id);
                        await _reload();
                      },
                    ),
                  ]),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class GuideViewPage extends StatefulWidget {
  final StudyGuide guide;
  const GuideViewPage({super.key, required this.guide});

  @override
  State<GuideViewPage> createState() => _GuideViewPageState();
}

class _GuideViewPageState extends State<GuideViewPage> {
  final FlutterTts _tts = FlutterTts();
  int _speakingLevel = -1;

  @override
  void initState() {
    super.initState();
    _tts.setCompletionHandler(() {
      if (mounted) setState(() => _speakingLevel = -1);
    });
    _tts.setCancelHandler(() {
      if (mounted) setState(() => _speakingLevel = -1);
    });
  }

  @override
  void dispose() {
    _tts.stop();
    super.dispose();
  }

  Future<void> _speak(int i) async {
    if (_speakingLevel == i) {
      await _tts.stop();
      if (mounted) setState(() => _speakingLevel = -1);
      return;
    }
    await _tts.stop();
    setState(() => _speakingLevel = i);
    await _tts.speak(widget.guide.levels[i].spokenText);
  }

  @override
  Widget build(BuildContext context) {
    final g = widget.guide;
    return Scaffold(
      backgroundColor: _black,
      appBar: AppBar(title: Text(g.topic, overflow: TextOverflow.ellipsis)),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(12, 4, 12, 24),
          children: [
            for (var i = 0; i < g.levels.length; i++) _level(i, g.levels[i]),
            if (g.source.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: SelectableText('Fuente: ${g.source}', style: const TextStyle(color: _dim, fontSize: 12))),
          ],
        ),
      ),
    );
  }

  Widget _level(int i, StudyLevel l) {
    return _box(
      Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          initiallyExpanded: i == 0,
          tilePadding: EdgeInsets.zero,
          childrenPadding: EdgeInsets.zero,
          iconColor: _white,
          collapsedIconColor: _white,
          title: Text(l.title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          trailing: IconButton(
            tooltip: 'Leer en voz alta',
            icon: Icon(_speakingLevel == i ? Icons.stop : Icons.volume_up),
            onPressed: () => _speak(i),
          ),
          children: [
            if (l.intro.isNotEmpty) Align(alignment: Alignment.centerLeft, child: Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(l.intro, style: const TextStyle(height: 1.45, fontSize: 15)))),
            for (final s in l.sections)
              Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(s.heading, style: const TextStyle(fontWeight: FontWeight.w800, decoration: TextDecoration.underline)),
                    const SizedBox(height: 4),
                    for (final b in s.bullets) Padding(padding: const EdgeInsets.only(top: 3), child: Text('• $b', style: const TextStyle(height: 1.4, fontSize: 14.5))),
                  ]),
                ),
              ),
            if (l.quiz.isNotEmpty) ...[
              const Divider(color: _line),
              Align(alignment: Alignment.centerLeft, child: Text('Autoevaluación · ${l.title}', style: const TextStyle(fontWeight: FontWeight.w800))),
              const SizedBox(height: 6),
              QuizBlock(questions: l.quiz),
            ],
          ],
        ),
      ),
    );
  }
}

class QuizBlock extends StatefulWidget {
  final List<QuizQ> questions;
  const QuizBlock({super.key, required this.questions});

  @override
  State<QuizBlock> createState() => _QuizBlockState();
}

class _QuizBlockState extends State<QuizBlock> {
  late final List<int?> _picked = List<int?>.filled(widget.questions.length, null);

  @override
  Widget build(BuildContext context) {
    final answered = _picked.where((x) => x != null).length;
    final score = [for (var i = 0; i < _picked.length; i++) if (_picked[i] == widget.questions[i].answer) 1].length;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      for (var qi = 0; qi < widget.questions.length; qi++) _question(qi),
      if (answered == widget.questions.length)
        Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Text(
            'Resultado: $score de ${widget.questions.length} · ${score == widget.questions.length ? '¡Excelente! Puedes pasar al siguiente nivel.' : 'Repasa el nivel y vuelve a intentarlo.'}',
            style: const TextStyle(fontWeight: FontWeight.w800),
          ),
        ),
    ]);
  }

  Widget _question(int qi) {
    final q = widget.questions[qi];
    final picked = _picked[qi];
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('${qi + 1}. ${q.question}', style: const TextStyle(height: 1.4, fontSize: 14.5)),
        const SizedBox(height: 6),
        for (var oi = 0; oi < q.options.length; oi++)
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                style: OutlinedButton.styleFrom(
                  alignment: Alignment.centerLeft,
                  foregroundColor: _white,
                  side: BorderSide(color: picked == null ? _white : (oi == q.answer ? _ok : (oi == picked ? _bad : _line)), width: picked != null && (oi == q.answer || oi == picked) ? 2 : 1),
                ),
                onPressed: picked == null ? () => setState(() => _picked[qi] = oi) : null,
                child: Text(q.options[oi], style: TextStyle(color: picked != null && oi != q.answer && oi != picked ? _dim : _white)),
              ),
            ),
          ),
        if (picked != null)
          Text(
            picked == q.answer ? '✔ Correcto. ${q.explanation}' : '✘ Revisa: ${q.explanation}',
            style: TextStyle(color: picked == q.answer ? _ok : _warn, fontSize: 13, height: 1.35),
          ),
      ]),
    );
  }
}
