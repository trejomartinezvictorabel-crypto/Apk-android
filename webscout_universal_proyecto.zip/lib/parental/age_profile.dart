// Perfiles de edad y reglas de uso saludable.

enum AgeProfile { child, teen, adult }

extension AgeProfileX on AgeProfile {
  String get id => name;
  bool get isMinor => this != AgeProfile.adult;

  String get title {
    switch (this) {
      case AgeProfile.child:
        return 'Infantil (6–11 años)';
      case AgeProfile.teen:
        return 'Jóvenes / Estudiantes (12–17 años)';
      case AgeProfile.adult:
        return 'Adulto (18+)';
    }
  }

  String get shortLabel {
    switch (this) {
      case AgeProfile.child:
        return 'Infantil';
      case AgeProfile.teen:
        return 'Estudio';
      case AgeProfile.adult:
        return 'Adulto';
    }
  }

  static AgeProfile? parse(String? s) {
    for (final p in AgeProfile.values) {
      if (p.name == s) return p;
    }
    return null;
  }
}

/// Reglas de tiempo (solo perfiles menores).
class StudyRules {
  final int sessionMinutes; // 30 o 45
  final int startMinute; // minutos desde medianoche (8:00 = 480)
  final int endMinute; // 20:00 = 1200
  static const int restMinutes = 15; // descanso tras agotar el bloque

  const StudyRules({this.sessionMinutes = 30, this.startMinute = 480, this.endMinute = 1200});

  StudyRules copyWith({int? sessionMinutes, int? startMinute, int? endMinute}) => StudyRules(
        sessionMinutes: sessionMinutes ?? this.sessionMinutes,
        startMinute: startMinute ?? this.startMinute,
        endMinute: endMinute ?? this.endMinute,
      );

  bool withinSchedule(DateTime now) {
    final m = now.hour * 60 + now.minute;
    if (startMinute <= endMinute) return m >= startMinute && m < endMinute;
    return m >= startMinute || m < endMinute; // franja que cruza medianoche
  }

  static String fmt(int minutes) =>
      '${(minutes ~/ 60).toString().padLeft(2, '0')}:${(minutes % 60).toString().padLeft(2, '0')}';
}
