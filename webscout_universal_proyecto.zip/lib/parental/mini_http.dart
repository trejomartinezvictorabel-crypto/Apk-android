// HTTP mínimo y neutro para el módulo parental (sin cookies, sin Accept-Language).
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

const String kParentalUA =
    'Mozilla/5.0 (Linux; Android 16; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36';

class MiniHttp {
  static Future<String?> getText(Uri uri, {Map<String, String>? headers, int maxBytes = 1500000}) async {
    final c = HttpClient();
    c.userAgent = kParentalUA;
    c.connectionTimeout = const Duration(seconds: 12);
    try {
      final req = await c.getUrl(uri);
      headers?.forEach((k, v) => req.headers.set(k, v));
      final res = await req.close().timeout(const Duration(seconds: 20));
      if (res.statusCode != 200) {
        await res.drain<void>();
        return null;
      }
      final b = BytesBuilder(copy: false);
      await for (final chunk in res) {
        b.add(chunk);
        if (b.length >= maxBytes) break;
      }
      return utf8.decode(b.takeBytes(), allowMalformed: true);
    } catch (_) {
      return null;
    } finally {
      c.close(force: true);
    }
  }

  static Future<Map<String, dynamic>?> getJson(Uri uri, {Map<String, String>? headers, int maxBytes = 1500000}) async {
    final t = await getText(uri, headers: headers, maxBytes: maxBytes);
    if (t == null) return null;
    try {
      final j = jsonDecode(t);
      return j is Map<String, dynamic> ? j : null;
    } catch (_) {
      return null;
    }
  }
}
