// Generador de guías de estudio a partir de Wikipedia (sin IA): niveles, cuestionarios tipo
// "completa la idea" y explicación infantil en 3 pasos. Guarda las guías solo en el equipo.

import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:shared_preferences/shared_preferences.dart';

import 'mini_http.dart';

class QuizQ {
  final String question;
  final List<String> options;
  final int answer;
  final String explanation;
  const QuizQ(this.question, this.options, this.answer, this.explanation);

  Map<String, dynamic> toJson() => {'q': question, 'o': options, 'a': answer, 'e': explanation};
  factory QuizQ.fromJson(Map<String, dynamic> j) => QuizQ(
        j['q'] as String,
        (j['o'] as List).cast<String>(),
        (j['a'] as num).toInt(),
        (j['e'] as String?) ?? '',
      );
}

class StudySection {
  final String heading;
  final List<String> bullets;
  const StudySection(this.heading, this.bullets);

  Map<String, dynamic> toJson() => {'h': heading, 'b': bullets};
  factory StudySection.fromJson(Map<String, dynamic> j) =>
      StudySection(j['h'] as String, (j['b'] as List).cast<String>());
}

class StudyLevel {
  final String title;
  final String intro;
  final List<StudySection> sections;
  final List<QuizQ> quiz;
  const StudyLevel(this.title, this.intro, this.sections, this.quiz);

  Map<String, dynamic> toJson() => {
        't': title,
        'i': intro,
        's': sections.map((e) => e.toJson()).toList(),
        'z': quiz.map((e) => e.toJson()).toList(),
      };
  factory StudyLevel.fromJson(Map<String, dynamic> j) => StudyLevel(
        j['t'] as String,
        (j['i'] as String?) ?? '',
        (j['s'] as List).map((e) => StudySection.fromJson(Map<String, dynamic>.from(e as Map))).toList(),
        (j['z'] as List).map((e) => QuizQ.fromJson(Map<String, dynamic>.from(e as Map))).toList(),
      );

  /// Texto plano del nivel para lectura en voz alta.
  String get spokenText {
    final b = StringBuffer('$title. $intro ');
    for (final s in sections) {
      b.write('${s.heading}. ');
      for (final x in s.bullets) {
        b.write('$x ');
      }
    }
    return b.toString();
  }
}

class StudyGuide {
  final String id;
  final String topic;
  final int createdMs;
  final String source;
  final List<StudyLevel> levels;
  const StudyGuide(this.id, this.topic, this.createdMs, this.source, this.levels);

  Map<String, dynamic> toJson() => {
        'id': id,
        'topic': topic,
        'ms': createdMs,
        'src': source,
        'lv': levels.map((e) => e.toJson()).toList(),
      };
  factory StudyGuide.fromJson(Map<String, dynamic> j) => StudyGuide(
        j['id'] as String,
        j['topic'] as String,
        (j['ms'] as num).toInt(),
        (j['src'] as String?) ?? '',
        (j['lv'] as List).map((e) => StudyLevel.fromJson(Map<String, dynamic>.from(e as Map))).toList(),
      );
}

class ChildStep {
  final String text;
  final String example;
  const ChildStep(this.text, this.example);
}

class ChildExplain {
  final String topic;
  final List<ChildStep> steps;
  final String source;
  const ChildExplain(this.topic, this.steps, this.source);

  String get spokenText {
    final b = StringBuffer('$topic en 3 pasos. ');
    for (var i = 0; i < steps.length; i++) {
      b.write('Paso ${i + 1}. ${steps[i].text} ${steps[i].example} ');
    }
    return b.toString();
  }

  StudyGuide toGuide() {
    final secs = <StudySection>[
      for (var i = 0; i < steps.length; i++) StudySection('Paso ${i + 1}', [steps[i].text, steps[i].example]),
    ];
    return StudyGuide(
      DateTime.now().millisecondsSinceEpoch.toString(),
      topic,
      DateTime.now().millisecondsSinceEpoch,
      source,
      [StudyLevel('En 3 pasos', 'Explicación corta para entender $topic.', secs, const [])],
    );
  }
}

class WikiText {
  final String title;
  final String lang;
  final String lead;
  final List<MapEntry<String, String>> sections;
  final String url;
  const WikiText(this.title, this.lang, this.lead, this.sections, this.url);
}

class StudyBuilder {
  static const Set<String> _skipSections = {
    'referencias', 'notas', 'vease tambien', 'véase también', 'enlaces externos', 'bibliografia', 'bibliografía',
    'references', 'notes', 'see also', 'external links', 'further reading', 'sources', 'fuentes', 'literatura',
    'citas', 'galeria', 'galería',
  };

  static const Set<String> _stop = {
    'the', 'and', 'for', 'that', 'with', 'this', 'are', 'was', 'were', 'from', 'have', 'has', 'not', 'but',
    'which', 'when', 'what', 'their', 'there', 'about', 'also', 'into', 'than', 'then', 'been', 'being',
    'los', 'las', 'del', 'que', 'con', 'para', 'por', 'una', 'uno', 'unos', 'unas', 'como', 'mas', 'más', 'pero',
    'sus', 'este', 'esta', 'estos', 'estas', 'ese', 'esa', 'son', 'fue', 'ser', 'hay', 'muy', 'tambien', 'también',
    'entre', 'sobre', 'sin', 'desde', 'hasta', 'cuando', 'donde', 'porque', 'cada', 'otros', 'otras', 'mismo',
    'puede', 'pueden', 'tiene', 'tienen', 'forma', 'parte', 'durante', 'según', 'segun', 'después', 'despues',
  };

  static String _lang() {
    final l = Platform.localeName.split(RegExp(r'[_-]')).first.toLowerCase();
    return RegExp(r'^[a-z]{2,3}$').hasMatch(l) ? l : 'es';
  }

  // ------------------------------------------------------------ descarga

  static Future<WikiText?> fetch(String topic) async {
    final langs = <String>{_lang(), 'en'};
    for (final lang in langs) {
      final j = await MiniHttp.getJson(
        Uri.https('$lang.wikipedia.org', '/w/api.php', {
          'action': 'query',
          'generator': 'search',
          'gsrsearch': topic,
          'gsrlimit': '1',
          'prop': 'extracts',
          'explaintext': '1',
          'exlimit': '1',
          'format': 'json',
          'formatversion': '2',
        }),
        maxBytes: 1200000,
      );
      final pages = ((j?['query'] as Map?)?['pages'] as List?) ?? [];
      if (pages.isEmpty) continue;
      final p = pages.first as Map;
      final extract = (p['extract'] ?? '').toString();
      final title = (p['title'] ?? topic).toString();
      if (extract.trim().length < 200) continue;
      return _parse(title, lang, extract);
    }
    return null;
  }

  static WikiText _parse(String title, String lang, String extract) {
    final headRe = RegExp(r'^(={2,})\s*(.+?)\s*\1\s*$');
    final lead = StringBuffer();
    final sections = <MapEntry<String, String>>[];
    String? current;
    final buf = StringBuffer();
    void flush() {
      if (current != null && buf.toString().trim().isNotEmpty) {
        sections.add(MapEntry(current!, buf.toString().trim()));
      }
      buf.clear();
    }

    for (final line in const LineSplitter().convert(extract)) {
      final m = headRe.firstMatch(line.trim());
      if (m != null) {
        final level = m.group(1)!.length;
        final name = m.group(2)!;
        if (level == 2) {
          flush();
          current = _skipSections.contains(name.toLowerCase()) ? null : name;
        }
        continue;
      }
      if (current == null && sections.isEmpty && buf.isEmpty) {
        lead.writeln(line);
      } else if (current != null) {
        buf.writeln(line);
      }
    }
    flush();
    return WikiText(title, lang, lead.toString().trim(), sections, 'https://$lang.wikipedia.org/wiki/${Uri.encodeComponent(title.replaceAll(' ', '_'))}');
  }

  // ------------------------------------------------------------ utilidades de texto

  static List<String> splitSentences(String text) {
    final cleaned = text
        .replaceAll(RegExp(r'\[\d+\]'), '')
        .replaceAll(RegExp(r'\s*\([^)]{0,120}\)'), '')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
    return cleaned
        .split(RegExp(r'(?<=[.!?])\s+(?=[A-ZÁÉÍÓÚÑ¿¡0-9])'))
        .map((s) => s.trim())
        .where((s) => s.length >= 45 && s.length <= 260 && !s.contains('=='))
        .toList();
  }

  static final RegExp _wordRe = RegExp(r'\p{L}{4,}', unicode: true);

  static Map<String, int> _freq(Iterable<String> texts) {
    final f = <String, int>{};
    for (final t in texts) {
      for (final m in _wordRe.allMatches(t.toLowerCase())) {
        final w = m.group(0)!;
        if (_stop.contains(w)) continue;
        f[w] = (f[w] ?? 0) + 1;
      }
    }
    return f;
  }

  static List<String> _best(List<String> sents, Map<String, int> freq, int n) {
    if (sents.length <= n) return List<String>.from(sents);
    final scored = <MapEntry<int, double>>[];
    for (var i = 0; i < sents.length; i++) {
      final words = _wordRe.allMatches(sents[i].toLowerCase()).map((m) => m.group(0)!).where((w) => !_stop.contains(w)).toList();
      if (words.isEmpty) continue;
      var sc = 0.0;
      for (final w in words) {
        sc += freq[w] ?? 0;
      }
      scored.add(MapEntry(i, sc / math.pow(words.length, 0.7)));
    }
    scored.sort((a, b) => b.value.compareTo(a.value));
    final idx = scored.take(n).map((e) => e.key).toList()..sort();
    return idx.map((i) => sents[i]).toList();
  }

  static List<String> _terms(Map<String, int> freq, int n) {
    final e = freq.entries.where((x) => x.key.length >= 5).toList()..sort((a, b) => b.value.compareTo(a.value));
    return e.take(n).map((x) => x.key).toList();
  }

  // ------------------------------------------------------------ cuestionarios

  static List<QuizQ> _quiz(List<String> sentences, List<String> pool, math.Random rnd, int count) {
    final out = <QuizQ>[];
    final used = <String>{};
    for (final s in sentences) {
      if (out.length >= count) break;
      final lower = s.toLowerCase();
      String? answer;
      var best = 0;
      for (final t in pool) {
        if (used.contains(t)) continue;
        final idx = lower.indexOf(t);
        if (idx > 8 && t.length > best) {
          best = t.length;
          answer = t;
        }
      }
      if (answer == null) continue;
      final String ans = answer;
      final distract = pool.where((t) => t != ans && (t.length - ans.length).abs() <= 4).toList()..shuffle(rnd);
      if (distract.length < 3) continue;
      final re = RegExp('(?<![\\p{L}])${RegExp.escape(ans)}(?![\\p{L}])', caseSensitive: false, unicode: true);
      if (!re.hasMatch(s)) continue;
      final q = s.replaceFirst(re, '_____');
      final opts = <String>[ans, ...distract.take(3)]..shuffle(rnd);
      out.add(QuizQ('Completa la idea: $q', opts, opts.indexOf(ans), s));
      used.add(ans);
    }
    return out;
  }

  // ------------------------------------------------------------ guía por niveles (12–17 y adultos)

  static StudyGuide buildLevels(WikiText w) {
    final rnd = math.Random(w.title.hashCode);
    final leadS = splitSentences(w.lead);
    final secS = <MapEntry<String, List<String>>>[];
    for (final s in w.sections) {
      final ss = splitSentences(s.value);
      if (ss.length >= 2) secS.add(MapEntry(s.key, ss));
    }
    final all = <String>[...leadS, ...secS.expand((e) => e.value)];
    final freq = _freq(all);
    final terms = _terms(freq, 40);

    // Nivel 1
    final l1src = leadS.isNotEmpty ? leadS : all.take(8).toList();
    final l1 = _best(l1src, freq, 4);
    final level1 = StudyLevel(
      'Nivel 1 · Fundamentos',
      l1.take(2).join(' '),
      [
        StudySection('Ideas clave', l1),
        StudySection('Términos clave', terms.take(6).map((t) => t[0].toUpperCase() + t.substring(1)).toList()),
      ],
      _quiz(_best(l1src, freq, 6), terms, rnd, 3),
    );

    // Nivel 2
    final s2 = secS.take(3).toList();
    final used2 = <String>[];
    final secs2 = <StudySection>[];
    for (final e in s2) {
      final b = _best(e.value, freq, 2);
      used2.addAll(b);
      secs2.add(StudySection(e.key, b));
    }
    if (secs2.isEmpty) {
      final rest = all.where((x) => !l1.contains(x)).take(6).toList();
      secs2.add(StudySection('Desarrollo', _best(rest, freq, 4)));
      used2.addAll(secs2.first.bullets);
    }
    final level2 = StudyLevel(
      'Nivel 2 · Desarrollo',
      'Profundizamos en los puntos principales de ${w.title}.',
      secs2,
      _quiz(used2, terms, rnd, 3),
    );

    // Nivel 3
    final s3 = secS.skip(3).take(3).toList();
    final used3 = <String>[];
    final secs3 = <StudySection>[];
    for (final e in s3) {
      final b = _best(e.value, freq, 3);
      used3.addAll(b);
      secs3.add(StudySection(e.key, b));
    }
    if (secs3.isEmpty) {
      final taken = <String>{...l1, ...used2};
      final rest = all.where((x) => !taken.contains(x)).toList();
      if (rest.isNotEmpty) {
        final b = _best(rest, freq, 5);
        used3.addAll(b);
        secs3.add(StudySection('Más detalles', b));
      }
    }
    secs3.add(StudySection('Para seguir aprendiendo', ['Busca más sobre: ${terms.skip(6).take(5).join(', ')}.']));
    final level3 = StudyLevel(
      'Nivel 3 · Profundización',
      'Detalles avanzados y conceptos relacionados con ${w.title}.',
      secs3,
      _quiz(used3, terms, rnd, 4),
    );

    return StudyGuide(
      DateTime.now().millisecondsSinceEpoch.toString(),
      w.title,
      DateTime.now().millisecondsSinceEpoch,
      w.url,
      [level1, level2, level3],
    );
  }

  // ------------------------------------------------------------ explicación infantil (3 pasos)

  static ChildExplain? buildChild(WikiText w) {
    final lead = splitSentences(w.lead).where((s) => s.length <= 170).toList();
    final pick = lead.length >= 3 ? lead.take(3).toList() : splitSentences(w.lead).take(3).toList();
    if (pick.length < 2) return null;
    // Un ejemplo real del texto, si existe; si no, preguntas para pensar (no se inventan ejemplos).
    final markers = RegExp(r'(por ejemplo|como el |como la |como los |como las |such as|for example|for instance)', caseSensitive: false);
    final all = splitSentences('${w.lead} ${w.sections.map((e) => e.value).take(4).join(' ')}');
    final ex = all.where((s) => markers.hasMatch(s) && s.length <= 180 && !pick.contains(s)).toList()
      ..sort((a, b) => a.length.compareTo(b.length));
    final prompts = [
      ex.isNotEmpty ? 'Ejemplo: ${ex.first}' : 'Piensa en tu casa: ¿dónde ves algo relacionado con ${w.title}?',
      'Piensa en la escuela o en la calle: ¿qué te recuerda esto?',
      'Cuéntaselo con tus palabras a alguien de tu familia.',
    ];
    final steps = <ChildStep>[for (var i = 0; i < pick.length; i++) ChildStep(pick[i], prompts[i])];
    return ChildExplain(w.title, steps, w.url);
  }

  static Future<ChildExplain?> explainForChild(String topic) async {
    try {
      final w = await fetch(topic);
      if (w == null) return null;
      return buildChild(w);
    } catch (_) {
      return null;
    }
  }
}

class GuideStore {
  static const String _k = 'study_guides';
  static const int maxGuides = 12;

  static Future<List<StudyGuide>> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getStringList(_k) ?? [];
    final out = <StudyGuide>[];
    for (final r in raw) {
      try {
        out.add(StudyGuide.fromJson(Map<String, dynamic>.from(jsonDecode(r) as Map)));
      } catch (_) {}
    }
    return out;
  }

  static Future<void> save(StudyGuide g) async {
    final p = await SharedPreferences.getInstance();
    final list = await load();
    list.removeWhere((x) => x.topic.toLowerCase() == g.topic.toLowerCase());
    list.insert(0, g);
    final trimmed = list.take(maxGuides).map((e) => jsonEncode(e.toJson())).toList();
    await p.setStringList(_k, trimmed);
  }

  static Future<void> delete(String id) async {
    final p = await SharedPreferences.getInstance();
    final list = await load();
    list.removeWhere((x) => x.id == id);
    await p.setStringList(_k, list.map((e) => jsonEncode(e.toJson())).toList());
  }
}
