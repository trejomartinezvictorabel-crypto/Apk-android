// Estado parental persistente: perfil, PIN (SHA-256 salado), bloqueo por intentos,
// temporizador de sesión de estudio y franja horaria. Todo local, sin internet.

import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'age_profile.dart';

enum LockKind { none, schedule, session }

class PinResult {
  final bool ok;
  final bool locked;
  final int attemptsLeft;
  final Duration lockRemaining;
  const PinResult(this.ok, this.locked, this.attemptsLeft, this.lockRemaining);
}

class ParentalController extends ChangeNotifier {
  static const int maxFails = 3;
  static const Duration pinLockDuration = Duration(minutes: 5);

  SharedPreferences? _p;
  AgeProfile? _profile; // null = primera ejecución, aún sin elegir
  StudyRules _rules = const StudyRules();
  String? _pinHash;
  String? _pinSalt;
  int _fails = 0;
  int _pinLockUntilMs = 0;
  int _usedMs = 0;
  int _lastActiveMs = 0;
  DateTime? _scheduleOverrideUntil;
  bool _foreground = true;
  bool _loaded = false;
  Timer? _timer;
  DateTime _lastTick = DateTime.now();
  int _sinceSaveMs = 0;
  LockKind _lock = LockKind.none;
  List<String> _extraAllowed = [];

  /// Segundos restantes del bloque (o -1 si no aplica). Solo la franja de estado lo escucha.
  final ValueNotifier<int> secondsLeft = ValueNotifier<int>(-1);

  AgeProfile? get profile => _profile;
  AgeProfile get effective => _profile ?? AgeProfile.adult;
  bool get isMinor => effective.isMinor;
  bool get loaded => _loaded;
  bool get hasPin => _pinHash != null && _pinSalt != null;
  StudyRules get rules => _rules;
  LockKind get lock => _lock;
  List<String> get extraAllowed => List.unmodifiable(_extraAllowed);

  Duration get pinLockRemaining {
    final left = _pinLockUntilMs - DateTime.now().millisecondsSinceEpoch;
    return left > 0 ? Duration(milliseconds: left) : Duration.zero;
  }

  /// Minutos que faltan de descanso tras agotar el bloque.
  int get restRemainingMinutes {
    final elapsed = DateTime.now().millisecondsSinceEpoch - _lastActiveMs;
    final left = StudyRules.restMinutes * 60000 - elapsed;
    return left <= 0 ? 0 : (left / 60000).ceil();
  }

  // ------------------------------------------------------------------ carga

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    _p = p;
    _profile = AgeProfileX.parse(p.getString('par_profile'));
    _pinHash = p.getString('par_pin_hash');
    _pinSalt = p.getString('par_pin_salt');
    _fails = p.getInt('par_fail') ?? 0;
    _pinLockUntilMs = p.getInt('par_pin_lock_until') ?? 0;
    _rules = StudyRules(
      sessionMinutes: p.getInt('par_session_min') ?? 30,
      startMinute: p.getInt('par_start_min') ?? 480,
      endMinute: p.getInt('par_end_min') ?? 1200,
    );
    _usedMs = p.getInt('par_used_ms') ?? 0;
    _lastActiveMs = p.getInt('par_last_active') ?? 0;
    _extraAllowed = p.getStringList('par_extra_allowed') ?? [];
    final now = DateTime.now().millisecondsSinceEpoch;
    // Reiniciar la app NO reinicia el tiempo usado; solo un descanso real lo hace.
    if (_lastActiveMs > 0 && now - _lastActiveMs >= StudyRules.restMinutes * 60000) {
      _usedMs = 0;
      await p.setInt('par_used_ms', 0);
    }
    _loaded = true;
    _evaluate();
    _updateSeconds();
    notifyListeners();
  }

  void startTicking() {
    _timer?.cancel();
    _lastTick = DateTime.now();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
  }

  void stopTicking() {
    _timer?.cancel();
    _timer = null;
  }

  void setForeground(bool v) {
    _foreground = v;
    _lastTick = DateTime.now();
  }

  @override
  void dispose() {
    stopTicking();
    secondsLeft.dispose();
    super.dispose();
  }

  // ------------------------------------------------------------------ tiempo

  void _tick() {
    final now = DateTime.now();
    final delta = now.difference(_lastTick).inMilliseconds;
    _lastTick = now;
    if (isMinor && _foreground && _lock == LockKind.none && delta > 0 && delta < 5000) {
      _usedMs += delta;
      _lastActiveMs = now.millisecondsSinceEpoch;
      _sinceSaveMs += delta;
      if (_sinceSaveMs >= 15000) {
        _sinceSaveMs = 0;
        _persistCounter();
      }
    }
    final changed = _evaluate();
    _updateSeconds();
    if (changed) {
      _persistCounter();
      notifyListeners();
    }
  }

  void _persistCounter() {
    _p?.setInt('par_used_ms', _usedMs);
    _p?.setInt('par_last_active', _lastActiveMs);
  }

  bool _evaluate() {
    var k = LockKind.none;
    if (isMinor) {
      final now = DateTime.now();
      final overridden = _scheduleOverrideUntil != null && now.isBefore(_scheduleOverrideUntil!);
      if (!overridden && !_rules.withinSchedule(now)) {
        k = LockKind.schedule;
      } else if (_usedMs >= _rules.sessionMinutes * 60000) {
        k = LockKind.session;
        // Descanso cumplido aunque la app siga abierta: nuevo bloque.
        if (_lastActiveMs > 0 &&
            now.millisecondsSinceEpoch - _lastActiveMs >= StudyRules.restMinutes * 60000) {
          _usedMs = 0;
          k = LockKind.none;
        }
      }
    }
    final changed = k != _lock;
    _lock = k;
    return changed;
  }

  void _updateSeconds() {
    int v;
    if (!isMinor) {
      v = -1;
    } else if (_lock != LockKind.none) {
      v = 0;
    } else {
      final now = DateTime.now();
      var left = _rules.sessionMinutes * 60 - _usedMs ~/ 1000;
      final overridden = _scheduleOverrideUntil != null && now.isBefore(_scheduleOverrideUntil!);
      if (!overridden) {
        final mNow = now.hour * 60 + now.minute;
        var toEnd = (_rules.endMinute - mNow) * 60 - now.second;
        if (_rules.startMinute > _rules.endMinute && mNow >= _rules.startMinute) toEnd += 1440 * 60;
        if (toEnd < left) left = toEnd;
      }
      v = left < 0 ? 0 : left;
    }
    if (secondsLeft.value != v) secondsLeft.value = v;
  }

  /// Tras verificar el PIN: abre un bloque nuevo aunque sea fuera de horario.
  Future<void> grantBlock() async {
    _usedMs = 0;
    _lastActiveMs = DateTime.now().millisecondsSinceEpoch;
    _scheduleOverrideUntil = DateTime.now().add(Duration(minutes: _rules.sessionMinutes));
    _persistCounter();
    _evaluate();
    _updateSeconds();
    notifyListeners();
  }

  // ------------------------------------------------------------------ PIN

  static String _randomSalt() {
    final r = math.Random.secure();
    return base64Url.encode(List<int>.generate(16, (_) => r.nextInt(256)));
  }

  static String _hash(String pin, String salt) {
    var d = sha256.convert(utf8.encode('$salt:$pin'));
    for (var i = 0; i < 5000; i++) {
      d = sha256.convert([...d.bytes, ...utf8.encode(salt)]);
    }
    return d.toString();
  }

  static bool _constEq(String a, String b) {
    if (a.length != b.length) return false;
    var r = 0;
    for (var i = 0; i < a.length; i++) {
      r |= a.codeUnitAt(i) ^ b.codeUnitAt(i);
    }
    return r == 0;
  }

  static bool validPin(String pin) => RegExp(r'^\d{4,6}$').hasMatch(pin);

  Future<void> setPin(String pin) async {
    final salt = _randomSalt();
    _pinSalt = salt;
    _pinHash = _hash(pin, salt);
    _fails = 0;
    _pinLockUntilMs = 0;
    final p = _p ?? await SharedPreferences.getInstance();
    await p.setString('par_pin_salt', salt);
    await p.setString('par_pin_hash', _pinHash!);
    await p.setInt('par_fail', 0);
    await p.setInt('par_pin_lock_until', 0);
  }

  /// Verifica el PIN. Tras 3 fallos bloquea 5 minutos (persistente: reiniciar la app no ayuda).
  Future<PinResult> verifyPin(String pin) async {
    final p = _p ?? await SharedPreferences.getInstance();
    final now = DateTime.now().millisecondsSinceEpoch;
    if (now < _pinLockUntilMs) {
      return PinResult(false, true, 0, Duration(milliseconds: _pinLockUntilMs - now));
    }
    if (!hasPin) return const PinResult(false, false, 0, Duration.zero);
    final ok = _constEq(_hash(pin, _pinSalt!), _pinHash!);
    if (ok) {
      _fails = 0;
      await p.setInt('par_fail', 0);
      return const PinResult(true, false, maxFails, Duration.zero);
    }
    _fails++;
    if (_fails >= maxFails) {
      _fails = 0;
      _pinLockUntilMs = now + pinLockDuration.inMilliseconds;
      await p.setInt('par_fail', 0);
      await p.setInt('par_pin_lock_until', _pinLockUntilMs);
      return PinResult(false, true, 0, pinLockDuration);
    }
    await p.setInt('par_fail', _fails);
    return PinResult(false, false, maxFails - _fails, Duration.zero);
  }

  // ------------------------------------------------------------------ perfil

  /// El llamador ya verificó el PIN cuando corresponde (cambios desde un perfil menor).
  Future<void> activate(
    AgeProfile profile, {
    String? newPin,
    StudyRules? rules,
    List<String>? extraAllowed,
  }) async {
    final p = _p ?? await SharedPreferences.getInstance();
    if (newPin != null) await setPin(newPin);
    if (rules != null) {
      _rules = rules;
      await p.setInt('par_session_min', rules.sessionMinutes);
      await p.setInt('par_start_min', rules.startMinute);
      await p.setInt('par_end_min', rules.endMinute);
    }
    if (extraAllowed != null) {
      _extraAllowed = extraAllowed;
      await p.setStringList('par_extra_allowed', extraAllowed);
    }
    _profile = profile;
    await p.setString('par_profile', profile.id);
    if (!profile.isMinor) {
      _usedMs = 0;
      _scheduleOverrideUntil = null;
      _persistCounter();
    }
    _evaluate();
    _updateSeconds();
    notifyListeners();
  }
}
