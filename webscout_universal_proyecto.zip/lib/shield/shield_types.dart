/// Resultado del motor Shield. level: 0 info, 1 ok, 2 precaución, 3 alerta.
class ShieldFinding {
  final int level;
  final String title;
  final String detail;
  const ShieldFinding(this.level, this.title, [this.detail = '']);
}
