// Filtro Bloom compacto en disco: 16 Mi bits = 2 MiB, 7 funciones hash.
// Con 1 millón de entradas la tasa de falsos positivos es ~0,05 %. Nunca da falsos negativos.

import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';

class BloomFilter {
  static const int defaultBits = 1 << 24;
  static const int hashes = 7;
  static const int _magic = 0x57534231; // "WSB1"

  final int bits;
  final Uint8List data;
  int count;

  BloomFilter._(this.bits, this.data, this.count);

  factory BloomFilter.empty({int bits = defaultBits}) => BloomFilter._(bits, Uint8List(bits >> 3), 0);

  static final RegExp _hex64 = RegExp(r'^[a-f0-9]{64}$');

  /// Clave de 64 hex: el propio SHA-256 si ya lo es; si no, SHA-256 del texto en minúsculas.
  static String keyOf(String s) {
    final t = s.trim().toLowerCase();
    return _hex64.hasMatch(t) ? t : sha256.convert(utf8.encode(t)).toString();
  }

  Iterable<int> _indexes(String key) sync* {
    final h1 = int.parse(key.substring(0, 8), radix: 16);
    final h2 = int.parse(key.substring(8, 16), radix: 16) | 1;
    for (var i = 0; i < hashes; i++) {
      yield (h1 + i * h2) % bits;
    }
  }

  void add(String raw) {
    for (final i in _indexes(keyOf(raw))) {
      data[i >> 3] |= 1 << (i & 7);
    }
    count++;
  }

  bool mightContain(String raw) {
    for (final i in _indexes(keyOf(raw))) {
      if ((data[i >> 3] & (1 << (i & 7))) == 0) return false;
    }
    return true;
  }

  Future<void> saveTo(File f) async {
    await f.parent.create(recursive: true);
    final tmp = File('${f.path}.tmp');
    final raf = await tmp.open(mode: FileMode.write);
    try {
      final h = ByteData(16)
        ..setUint32(0, _magic)
        ..setUint32(4, bits)
        ..setUint32(8, count)
        ..setUint32(12, hashes);
      await raf.writeFrom(h.buffer.asUint8List());
      await raf.writeFrom(data);
    } finally {
      await raf.close();
    }
    if (await f.exists()) await f.delete();
    await tmp.rename(f.path);
  }

  static Future<BloomFilter?> load(File f) async {
    if (!await f.exists()) return null;
    final raf = await f.open();
    try {
      final h = await raf.read(16);
      if (h.length < 16) return null;
      final bd = ByteData.sublistView(h);
      if (bd.getUint32(0) != _magic || bd.getUint32(12) != hashes) return null;
      final bits = bd.getUint32(4);
      final count = bd.getUint32(8);
      if (bits <= 0 || (bits & 7) != 0 || bits > (1 << 27)) return null;
      final data = await raf.read(bits >> 3);
      if (data.length != bits >> 3) return null;
      return BloomFilter._(bits, data, count);
    } finally {
      await raf.close();
    }
  }
}
