// Listas locales (hashes y dominios maliciosos) guardadas como filtros Bloom de 2 MiB.
// La actualización es MANUAL y en streaming: línea a línea, sin cargar la lista completa en RAM.

import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'bloom_filter.dart';
import 'shield_types.dart';

class ListStatus {
  final int count;
  final DateTime? updated;
  final int bytes;
  const ListStatus(this.count, this.updated, this.bytes);
  bool get exists => count > 0;
}

class ShieldLists {
  static const MethodChannel _ch = MethodChannel('webscout/native');
  static const int maxItems = 1500000;
  static const String _ua =
      'Mozilla/5.0 (Linux; Android 16; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36';

  static String _kind(bool domains) => domains ? 'dom' : 'hash';

  static Future<File> _file(bool domains) async {
    final base = await _ch.invokeMethod<String>('filesDir');
    final d = Directory('$base/shield');
    if (!await d.exists()) await d.create(recursive: true);
    return File('${d.path}/${domains ? 'domains' : 'hashes'}.bloom');
  }

  static Future<String> savedUrl(bool domains) async {
    final p = await SharedPreferences.getInstance();
    return p.getString('shield_${_kind(domains)}_url') ?? '';
  }

  static Future<String> savedAuth() async {
    final p = await SharedPreferences.getInstance();
    return p.getString('shield_auth') ?? '';
  }

  static Future<ListStatus> status(bool domains) async {
    final p = await SharedPreferences.getInstance();
    final n = p.getInt('shield_${_kind(domains)}_n') ?? 0;
    final ms = p.getInt('shield_${_kind(domains)}_ms');
    var bytes = 0;
    try {
      final f = await _file(domains);
      if (await f.exists()) bytes = await f.length();
    } catch (_) {}
    return ListStatus(bytes > 0 ? n : 0, ms == null ? null : DateTime.fromMillisecondsSinceEpoch(ms), bytes);
  }

  /// Descarga la lista (https) y construye el filtro Bloom. Devuelve cuántas entradas se cargaron.
  static Future<int> update({
    required bool domains,
    required String url,
    String authKey = '',
    void Function(String)? onProgress,
  }) async {
    final uri = Uri.parse(url.trim());
    if (uri.scheme != 'https' || uri.host.isEmpty) throw 'La URL debe empezar con https://';
    final p = await SharedPreferences.getInstance();
    await p.setString('shield_${_kind(domains)}_url', url.trim());
    await p.setString('shield_auth', authKey.trim());

    final c = HttpClient();
    c.userAgent = _ua;
    c.connectionTimeout = const Duration(seconds: 15);
    try {
      final req = await c.getUrl(uri);
      if (authKey.trim().isNotEmpty) req.headers.set('Auth-Key', authKey.trim());
      final res = await req.close().timeout(const Duration(seconds: 40));
      if (res.statusCode != 200) {
        await res.drain<void>();
        throw 'El servidor respondió HTTP ${res.statusCode}';
      }
      final bf = BloomFilter.empty();
      final hex = RegExp(r'[a-fA-F0-9]{64}');
      final dom = RegExp(r'^[a-z0-9.-]+\.[a-z]{2,}$', caseSensitive: false);
      var n = 0;
      await for (final line in res.transform(utf8.decoder).transform(const LineSplitter())) {
        var t = line.trim();
        if (t.isEmpty || t.startsWith('#')) continue;
        if (domains) {
          t = t.split(RegExp(r'\s+')).last;
          if (!dom.hasMatch(t)) continue;
        } else {
          final m = hex.firstMatch(t);
          if (m == null) continue;
          t = m.group(0)!;
        }
        bf.add(t);
        n++;
        if (n >= maxItems) break;
        if (n % 50000 == 0) {
          onProgress?.call('$n entradas…');
          await Future<void>.delayed(Duration.zero);
        }
      }
      if (n == 0) throw 'La lista no contiene entradas válidas';
      await bf.saveTo(await _file(domains));
      await p.setInt('shield_${_kind(domains)}_n', n);
      await p.setInt('shield_${_kind(domains)}_ms', DateTime.now().millisecondsSinceEpoch);
      return n;
    } finally {
      c.close(force: true);
    }
  }

  static Future<String> _stale(bool domains) async {
    final s = await status(domains);
    if (s.updated == null) return '';
    final days = DateTime.now().difference(s.updated!).inDays;
    return days > 30 ? ' (lista de hace $days días: conviene actualizarla)' : '';
  }

  /// null = sin coincidencia. Carga el filtro (2 MiB) solo durante la consulta y lo suelta.
  static Future<ShieldFinding?> hashCheck(String sha) async {
    try {
      final bf = await BloomFilter.load(await _file(false));
      if (bf == null) {
        return const ShieldFinding(0, 'Lista local de hashes: no configurada', 'Puedes activarla en Ajustes (opcional).');
      }
      if (!bf.mightContain(sha)) return null;
      return ShieldFinding(
        3,
        'Hash en tu lista local de malware',
        'Coincidencia probable en el filtro Bloom (puede haber ~0,1 % de falsos positivos). Se elimina por seguridad.${await _stale(false)}',
      );
    } catch (_) {
      return null;
    }
  }

  static Future<ShieldFinding?> domainCheck(String host) async {
    try {
      final bf = await BloomFilter.load(await _file(true));
      if (bf == null) return null;
      final labels = host.toLowerCase().split('.');
      for (var i = 0; i <= labels.length - 2; i++) {
        final cand = labels.sublist(i).join('.');
        if (bf.mightContain(cand)) {
          return ShieldFinding(3, 'Dominio en tu lista local de amenazas', '$cand coincide con el filtro Bloom de dominios.${await _stale(true)}');
        }
      }
    } catch (_) {}
    return null;
  }
}
