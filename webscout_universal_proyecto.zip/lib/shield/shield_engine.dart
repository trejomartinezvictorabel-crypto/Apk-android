// Motor Shield: reglas por bloques + inspección profunda de ZIP/APK en streaming.
// Memoria acotada: bloques de 256 KB (archivo) y 64 KB (entradas), más presupuestos de lectura.

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'shield_lists.dart';
import 'shield_rules.dart';
import 'shield_types.dart';

class _Stop implements Exception {}

class _ScanSink implements Sink<List<int>> {
  final void Function(List<int>) onData;
  _ScanSink(this.onData);
  @override
  void add(List<int> data) => onData(data);
  @override
  void close() {}
}

class _Entry {
  final String name;
  final String ext;
  final int method;
  final int comp;
  final int uncomp;
  final int off;
  const _Entry(this.name, this.ext, this.method, this.comp, this.uncomp, this.off);
}

class Shield {
  static const int rawBudget = 48 * 1024 * 1024; // 24 MiB al inicio + 24 MiB al final
  static const int inflateBudget = 32 * 1024 * 1024;
  static const Set<String> _textLike = {'txt', 'md', 'csv', 'geojson', 'json', 'kml', 'gpx'};

  static Future<ShieldFinding?> checkHash(String sha) => ShieldLists.hashCheck(sha);
  static Future<ShieldFinding?> checkDomain(String host) => ShieldLists.domainCheck(host);

  static ShieldFinding _fromRule(String id) {
    final r = kShieldRules.firstWhere((x) => x.id == id);
    return ShieldFinding(r.level, r.title, r.detail);
  }

  static Future<List<ShieldFinding>> scanFile(
    File f,
    String ext,
    String name, {
    void Function(String)? onStep,
  }) async {
    final out = <ShieldFinding>[];
    try {
      out.addAll(_nameChecks(name));
      final len = await f.length();
      final raf = await f.open();
      try {
        if (_textLike.contains(ext) && len > 4096) {
          final e = await _sampleEntropy(raf, len);
          if (e > 7.0) {
            out.add(ShieldFinding(2, 'Entropía muy alta en un archivo de texto', 'Entropía ${e.toStringAsFixed(2)}/8: el contenido parece cifrado o empaquetado.'));
          }
        }
        onStep?.call('Reglas anti-malware por bloques…');
        final hits = await _scanRaw(raf, len, ext);
        for (final id in hits) {
          out.add(_fromRule(id));
        }
        if (kPackageExts.contains(ext)) {
          onStep?.call('Revisando el contenido del paquete…');
          out.addAll(await _zipDeep(raf, len));
        }
      } finally {
        await raf.close();
      }
      if (!out.any((x) => x.level >= 2)) {
        out.add(ShieldFinding(1, 'Reglas anti-malware: sin coincidencias', '${kShieldRules.length} reglas aplicadas en streaming. No garantiza seguridad total.'));
      }
    } catch (e) {
      out.add(ShieldFinding(2, 'No se completó el escaneo por reglas', e.toString().length > 120 ? e.toString().substring(0, 120) : e.toString()));
    }
    return out;
  }

  static List<ShieldFinding> _nameChecks(String name) {
    final o = <ShieldFinding>[];
    if (name.contains('\u202e') || name.contains('\u202d')) {
      o.add(const ShieldFinding(3, 'Nombre con carácter de inversión (RLO)', 'Técnica para disfrazar la extensión real del archivo.'));
    }
    if (RegExp(r'[ .]$').hasMatch(name) || RegExp(r' {6,}').hasMatch(name)) {
      o.add(const ShieldFinding(2, 'Nombre con espacios o puntos engañosos'));
    }
    return o;
  }

  static Future<double> _sampleEntropy(RandomAccessFile raf, int len) async {
    final counts = List<int>.filled(256, 0);
    var total = 0;
    Future<void> sample(int pos) async {
      await raf.setPosition(pos);
      final b = await raf.read(65536);
      for (final x in b) {
        counts[x]++;
      }
      total += b.length;
    }

    await sample(0);
    if (len > 131072) await sample(len - 65536);
    if (total == 0) return 0;
    var e = 0.0;
    for (final c in counts) {
      if (c == 0) continue;
      final p = c / total;
      e -= p * (math.log(p) / math.ln2);
    }
    return e;
  }

  static Future<Set<String>> _scanRaw(RandomAccessFile raf, int len, String ext) async {
    final rules = kShieldRules.where((r) => r.appliesTo(ext)).toList();
    final hits = <String>{};
    if (rules.isEmpty) return hits;

    Future<void> region(int start, int end) async {
      var pos = start;
      var carry = '';
      await raf.setPosition(start);
      while (pos < end && hits.length < rules.length) {
        final b = await raf.read(math.min(256 * 1024, end - pos));
        if (b.isEmpty) break;
        pos += b.length;
        final s = carry + latin1.decode(b, allowInvalid: true).toLowerCase();
        for (final r in rules) {
          if (!hits.contains(r.id) && r.matches(s)) hits.add(r.id);
        }
        carry = s.length > 80 ? s.substring(s.length - 80) : s;
        await Future<void>.delayed(Duration.zero);
      }
    }

    if (len <= rawBudget) {
      await region(0, len);
    } else {
      await region(0, rawBudget ~/ 2);
      await region(len - rawBudget ~/ 2, len);
    }
    return hits;
  }

  static Future<List<ShieldFinding>> _zipDeep(RandomAccessFile raf, int len) async {
    final out = <ShieldFinding>[];
    final tailLen = math.min(len, 65557);
    await raf.setPosition(len - tailLen);
    final tail = await raf.read(tailLen);
    var eocd = -1;
    for (var i = tail.length - 22; i >= 0; i--) {
      if (tail[i] == 0x50 && tail[i + 1] == 0x4B && tail[i + 2] == 0x05 && tail[i + 3] == 0x06) {
        eocd = i;
        break;
      }
    }
    if (eocd < 0) return out; // el Inspector ya lo reporta
    final bd = ByteData.sublistView(tail);
    final commentLen = bd.getUint16(eocd + 20, Endian.little);
    final extra = tail.length - (eocd + 22 + commentLen);
    if (extra > 0) {
      out.add(ShieldFinding(2, 'Datos añadidos después del final del ZIP', '$extra bytes extra: posible archivo políglota o carga oculta.'));
    }
    final cdSize = bd.getUint32(eocd + 12, Endian.little);
    final cdOff = bd.getUint32(eocd + 16, Endian.little);
    if (cdSize == 0xFFFFFFFF || cdOff == 0xFFFFFFFF || cdSize > 8 * 1024 * 1024) return out;
    await raf.setPosition(cdOff);
    final cd = await raf.read(cdSize);
    final cdv = ByteData.sublistView(cd);

    final entries = <_Entry>[];
    var pos = 0;
    while (pos + 46 <= cd.length && cdv.getUint32(pos, Endian.little) == 0x02014b50) {
      final method = cdv.getUint16(pos + 10, Endian.little);
      final comp = cdv.getUint32(pos + 20, Endian.little);
      final uncomp = cdv.getUint32(pos + 24, Endian.little);
      final nl = cdv.getUint16(pos + 28, Endian.little);
      final xl = cdv.getUint16(pos + 30, Endian.little);
      final cl = cdv.getUint16(pos + 32, Endian.little);
      final off = cdv.getUint32(pos + 42, Endian.little);
      if (pos + 46 + nl > cd.length) break;
      final name = utf8.decode(cd.sublist(pos + 46, pos + 46 + nl), allowMalformed: true);
      final dot = name.lastIndexOf('.');
      final e = dot >= 0 ? name.substring(dot + 1).toLowerCase() : '';
      entries.add(_Entry(name, e, method, comp, uncomp, off));
      pos += 46 + nl + xl + cl;
      if (entries.length > 20000) break;
    }

    // Prioridad: classes*.dex, luego scripts. El resto ya lo cubren el Inspector y el escaneo crudo.
    int prio(_Entry e) => e.ext == 'dex' ? 0 : (kScriptExts.contains(e.ext) ? 1 : 2);
    final sel = entries.where((e) => prio(e) < 2).toList()..sort((a, b) => prio(a).compareTo(prio(b)));
    final hits = <String>{};
    var budget = inflateBudget;

    for (final e in sel.take(40)) {
      if (budget <= 0) break;
      if (e.method != 0 && e.method != 8) continue;
      if (e.uncomp > 64 * 1024 * 1024) continue;
      final rules = kShieldRules.where((r) => r.appliesTo(e.ext)).toList();
      if (rules.isEmpty) continue;
      await raf.setPosition(e.off);
      final lh = await raf.read(30);
      if (lh.length < 30) continue;
      final lhv = ByteData.sublistView(lh);
      if (lhv.getUint32(0, Endian.little) != 0x04034b50) continue;
      final dataOff = e.off + 30 + lhv.getUint16(26, Endian.little) + lhv.getUint16(28, Endian.little);

      var carry = '';
      void feed(List<int> chunk) {
        budget -= chunk.length;
        if (budget < 0) throw _Stop();
        final s = carry + latin1.decode(chunk, allowInvalid: true).toLowerCase();
        for (final r in rules) {
          if (!hits.contains(r.id) && r.matches(s)) hits.add(r.id);
        }
        carry = s.length > 80 ? s.substring(s.length - 80) : s;
      }

      try {
        await raf.setPosition(dataOff);
        var left = e.comp;
        if (e.method == 0) {
          while (left > 0) {
            final b = await raf.read(math.min(65536, left));
            if (b.isEmpty) break;
            left -= b.length;
            feed(b);
            await Future<void>.delayed(Duration.zero);
          }
        } else {
          final conv = ZLibDecoder(raw: true).startChunkedConversion(_ScanSink(feed));
          while (left > 0) {
            final b = await raf.read(math.min(65536, left));
            if (b.isEmpty) break;
            left -= b.length;
            conv.add(b);
            await Future<void>.delayed(Duration.zero);
          }
          conv.close();
        }
      } on _Stop {
        break;
      } catch (_) {
        // entrada corrupta: se ignora; el Inspector ya valida la estructura
      }
    }

    for (final id in hits) {
      out.add(_fromRule(id));
    }
    final android = hits.where((h) => h.startsWith('and_')).length;
    if (android >= 3) {
      out.add(ShieldFinding(3, 'Combinación típica de malware Android', '$android comportamientos sensibles juntos en el código (carga dinámica, SMS, root, accesibilidad…).'));
    }
    return out;
  }
}
