// Panel de Ajustes para las listas locales (filtro Bloom). Actualización manual.

import 'package:flutter/material.dart';

import 'shield_lists.dart';

const Color _dim = Color(0xB3FFFFFF);
const Color _white = Color(0xFFFFFFFF);
const Color _black = Color(0xFF000000);

class ShieldListsPanel extends StatefulWidget {
  const ShieldListsPanel({super.key});

  @override
  State<ShieldListsPanel> createState() => _ShieldListsPanelState();
}

class _ShieldListsPanelState extends State<ShieldListsPanel> {
  final TextEditingController _hashUrl = TextEditingController();
  final TextEditingController _domUrl = TextEditingController();
  final TextEditingController _auth = TextEditingController();
  String _hashStatus = '…';
  String _domStatus = '…';
  String? _msg;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _hashUrl.dispose();
    _domUrl.dispose();
    _auth.dispose();
    super.dispose();
  }

  String _fmt(ListStatus s) {
    if (!s.exists) return 'sin cargar';
    final d = s.updated;
    final when = d == null ? '' : ' · ${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
    return '${s.count} entradas · ${(s.bytes / 1024).round()} KB$when';
  }

  Future<void> _load() async {
    final hu = await ShieldLists.savedUrl(false);
    final du = await ShieldLists.savedUrl(true);
    final au = await ShieldLists.savedAuth();
    final hs = await ShieldLists.status(false);
    final ds = await ShieldLists.status(true);
    if (!mounted) return;
    setState(() {
      _hashUrl.text = hu;
      _domUrl.text = du;
      _auth.text = au;
      _hashStatus = _fmt(hs);
      _domStatus = _fmt(ds);
    });
  }

  Future<void> _update(bool domains) async {
    final url = (domains ? _domUrl : _hashUrl).text.trim();
    if (url.isEmpty) {
      setState(() => _msg = 'Escribe la URL https de la lista.');
      return;
    }
    setState(() {
      _busy = true;
      _msg = 'Descargando en streaming…';
    });
    try {
      final n = await ShieldLists.update(
        domains: domains,
        url: url,
        authKey: _auth.text,
        onProgress: (m) {
          if (mounted) setState(() => _msg = m);
        },
      );
      await _load();
      if (mounted) setState(() => _msg = 'Lista actualizada: $n entradas.');
    } catch (e) {
      if (mounted) setState(() => _msg = 'No se pudo actualizar: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    const label = TextStyle(fontWeight: FontWeight.w800);
    InputDecoration dec(String hint) => InputDecoration(border: const OutlineInputBorder(), isDense: true, hintText: hint);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Divider(),
        const Text('Listas locales anti-malware (filtro Bloom)', style: label),
        const SizedBox(height: 4),
        const Text(
          'Opcional. Cada lista ocupa ~2 MB en disco y se consulta sin cargarla en RAM. Pon la URL https de una lista de '
          'hashes SHA-256 (uno por línea) o de dominios. Algunas fuentes piden una clave gratuita (campo "Auth-Key").',
          style: TextStyle(color: _dim, fontSize: 12),
        ),
        const SizedBox(height: 8),
        TextField(controller: _hashUrl, keyboardType: TextInputType.url, decoration: dec('URL lista de hashes SHA-256')),
        const SizedBox(height: 4),
        Text('Hashes: $_hashStatus', style: const TextStyle(color: _dim, fontSize: 12)),
        const SizedBox(height: 4),
        SizedBox(width: double.infinity, child: OutlinedButton(style: OutlinedButton.styleFrom(foregroundColor: _white, side: const BorderSide(color: _white)), onPressed: _busy ? null : () => _update(false), child: const Text('Actualizar hashes'))),
        const SizedBox(height: 10),
        TextField(controller: _domUrl, keyboardType: TextInputType.url, decoration: dec('URL lista de dominios')),
        const SizedBox(height: 4),
        Text('Dominios: $_domStatus', style: const TextStyle(color: _dim, fontSize: 12)),
        const SizedBox(height: 4),
        SizedBox(width: double.infinity, child: OutlinedButton(style: OutlinedButton.styleFrom(foregroundColor: _white, side: const BorderSide(color: _white)), onPressed: _busy ? null : () => _update(true), child: const Text('Actualizar dominios'))),
        const SizedBox(height: 10),
        TextField(controller: _auth, obscureText: true, decoration: dec('Auth-Key (opcional)')),
        if (_msg != null)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(_msg!, style: TextStyle(color: _busy ? _dim : _white, fontSize: 12.5)),
          ),
        const Divider(),
      ],
    );
  }
}
