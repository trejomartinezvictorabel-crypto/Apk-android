// Reglas tipo YARA (literales en minúsculas) para escaneo por bloques.
// level: 2 precaución, 3 alerta. onlyExts: extensión del archivo o de la entrada interna (dex, js, sh...).

class ShieldRule {
  final String id;
  final int level;
  final String title;
  final String detail;
  final List<String> needles;
  final Set<String>? onlyExts;
  const ShieldRule(this.id, this.level, this.title, this.detail, this.needles, [this.onlyExts]);

  bool matches(String lower) {
    for (final n in needles) {
      if (lower.contains(n)) return true;
    }
    return false;
  }

  bool appliesTo(String ext) => onlyExts == null || onlyExts!.contains(ext);
}

const Set<String> kDataExts = {
  'pdf', 'csv', 'txt', 'md', 'geojson', 'json', 'kml', 'gpx', 'mp3', 'mp4', 'mkv', 'webm',
  'mbtiles', 'osm.pbf', 'pbf',
};
const Set<String> kPackageExts = {'zip', 'epub', 'docx', 'xlsx', 'pptx', 'jar', 'apk', 'apks', 'xapk', 'tar.gz', 'tgz'};
const Set<String> kScriptExts = {'js', 'sh', 'bat', 'cmd', 'ps1', 'vbs', 'hta', 'html'};
const Set<String> kTextDocExts = {'pdf', 'csv', 'txt', 'md', 'geojson', 'json', 'kml', 'gpx', 'html', 'js', 'sh', 'bat', 'cmd', 'ps1', 'vbs', 'hta'};

const List<ShieldRule> kShieldRules = [
  ShieldRule(
    'eicar', 3, 'Archivo de prueba EICAR',
    'Es el archivo estándar (inofensivo) para probar antivirus: confirma que este escáner funciona.',
    ['eicar-standard-antivirus-test-file'],
  ),
  ShieldRule(
    'dos_stub_data', 3, 'Ejecutable de Windows incrustado',
    'Contiene la cabecera de un programa .exe dentro de un archivo que no debería tenerla.',
    ['this program cannot be run in dos mode'], kDataExts,
  ),
  ShieldRule(
    'dos_stub_pkg', 2, 'Ejecutable de Windows sin comprimir dentro del paquete',
    'El paquete lleva un programa .exe almacenado tal cual.',
    ['this program cannot be run in dos mode'], kPackageExts,
  ),
  ShieldRule(
    'ps_dropper', 2, 'Comandos de descarga/ejecución encubiertos',
    'Aparecen instrucciones típicas de droppers (PowerShell codificado, descargas, mshta, certutil).',
    [
      'powershell -enc', 'powershell.exe -enc', '-encodedcommand', 'frombase64string(', 'invoke-expression',
      'downloadstring(', 'invoke-webrequest', 'wscript.shell', 'mshta ', 'regsvr32 /s', 'certutil -urlcache',
      'bitsadmin /transfer',
    ],
    kTextDocExts,
  ),
  ShieldRule(
    'js_obfuscated', 2, 'JavaScript ofuscado',
    'Usa técnicas de ofuscación frecuentes en código malicioso (eval + decodificación, packer).',
    ['eval(atob(', 'eval(unescape(', 'document.write(unescape(', 'eval(function(p,a,c,k,e'],
    kTextDocExts,
  ),
  ShieldRule(
    'script_in_data', 2, 'Etiquetas <script> dentro de datos',
    'Un archivo de datos no debería contener scripts web.',
    ['<script'],
    {'csv', 'geojson', 'json', 'kml', 'gpx'},
  ),
  ShieldRule(
    'pdf_active', 2, 'PDF con acciones activas',
    'Contiene envío de formularios, enlaces a otros PDF o JavaScript en URI.',
    ['/submitform', '/gotor', '/uri (javascript:', '/xfa'],
    {'pdf'},
  ),
  // ---- APK: se aplican al contenido descomprimido de classes*.dex ----
  ShieldRule(
    'and_dexloader', 2, 'Carga dinámica de código (DexClassLoader)',
    'Puede descargar y ejecutar código nuevo después de instalarse.',
    ['dalvik/system/dexclassloader'], {'dex'},
  ),
  ShieldRule(
    'and_sms', 2, 'Envío o lectura de SMS',
    'Usa SmsManager o intercepta mensajes (típico de troyanos bancarios).',
    ['android/telephony/smsmanager', 'android.provider.telephony.sms_received'], {'dex'},
  ),
  ShieldRule(
    'and_root', 2, 'Búsqueda de acceso root (su)',
    'Referencias a binarios su del sistema.',
    ['/system/xbin/su', '/system/bin/su', '/sbin/su'], {'dex'},
  ),
  ShieldRule(
    'and_installer', 2, 'Instalador de APKs externos',
    'Puede instalar otros paquetes en el equipo.',
    ['application/vnd.android.package-archive'], {'dex'},
  ),
  ShieldRule(
    'and_access', 2, 'Servicio de accesibilidad',
    'Puede leer la pantalla y pulsar botones por ti (muy abusado por malware).',
    ['android/accessibilityservice/accessibilityservice'], {'dex'},
  ),
  ShieldRule(
    'and_admin', 2, 'Administrador de dispositivo',
    'Puede bloquear el equipo o impedir su desinstalación.',
    ['android/app/admin/devicepolicymanager'], {'dex'},
  ),
];
