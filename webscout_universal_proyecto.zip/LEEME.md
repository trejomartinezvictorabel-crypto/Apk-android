# WebScout Universal — cómo subirlo (3 pasos)

## 1) Crea UN archivo a mano en GitHub
En tu repositorio: **Add file → Create new file**, escribe el nombre
`.github/workflows/build.yml` (al escribir las `/` GitHub crea las carpetas solo)
y pega el contenido de `build.yml` (viene dentro de este ZIP y también suelto).
Haz **Commit**.

> GitHub no ejecuta workflows que estén dentro de un ZIP sin extraer; por eso este es el único
> archivo que debe existir ya descomprimido.

## 2) Sube este ZIP a la RAÍZ del repositorio
**Add file → Upload files** → selecciona `webscout_universal_proyecto.zip` → **Commit**.
No lo descomprimas: el workflow lo hace solo, valida el proyecto, repara lo que falte
(dependencias, permisos, firma, íconos) y compila.

## 3) Firma fija (una sola vez)
1. **Actions → WebScout Universal - Compilar APK → Run workflow → accion = generar_keystore**.
2. Descarga el artifact `keystore-temporal` y crea 4 secrets en
   *Settings → Secrets and variables → Actions*:
   `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
3. Guarda `webscout-release.jks` en un lugar seguro y borra el artifact.
   (Usa esto solo en un repositorio PRIVADO.)
4. **Run workflow → accion = compilar** (o cualquier push). El APK queda en *Artifacts*.

## Para actualizar encima de la app instalada
En `pubspec.yaml` sube el número después del `+`:  `1.0.0+1` → `1.0.1+2` → `1.1.0+3`…
Usa siempre el mismo keystore y el mismo `applicationId` (`com.webscout.universal`).

## Qué hace el validador (`tools/validate_project.py`)
Corre dentro del workflow antes de compilar. Comprueba archivos, pubspec, manifiesto, paquete,
firma, íconos y sintaxis básica de Dart, y **repara**: inyecta dependencias que el código importa
y faltan en `pubspec.yaml`, permisos y `<queries>` del manifiesto, la firma release, los recursos
del ícono y el paquete de `MainActivity`. Si `pub get` falla relaja versiones y reintenta; si la
compilación falla aplica un respaldo de Gradle y reintenta una vez. Deja el informe en el resumen
del job y en el artifact `WebScout-validation-report`.
