#!/usr/bin/env python3
"""
Validador / reparador del proyecto WebScout Universal (se ejecuta en GitHub Actions antes de compilar).

Uso:
  python3 tools/validate_project.py --fix [--report ARCHIVO.md]   # valida y repara lo reparable
  python3 tools/validate_project.py --relax                       # relaja versiones en pubspec (si pub get falla)
  python3 tools/validate_project.py --post                        # tras pub get: verifica paquetes resueltos
  python3 tools/validate_project.py --gradle-fallback             # quita bloque Kotlin riesgoso (reintento de build)

Qué comprueba:
  - Archivos obligatorios (Dart, Kotlin, Gradle, recursos de ícono). Restaura desde tools/templates lo que pueda.
  - pubspec.yaml: version x.y.z+n, environment, flutter SDK y TODAS las dependencias importadas por el código
    (si falta alguna la INYECTA con una versión conocida).
  - AndroidManifest.xml: permisos y <queries> necesarios (los INYECTA si faltan).
  - Coherencia namespace == applicationId == paquete de MainActivity (la corrige y la mueve de carpeta).
  - build.gradle.kts con firma release fija (si falta o es el genérico, restaura la plantilla).
  - Dart: imports relativos existentes, main(), balance de llaves/paréntesis.
Código de salida: 0 si todo OK/reparado, 1 si quedan errores no reparables.
"""
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

# Versiones conocidas (se usan solo para INYECTAR una dependencia faltante).
KNOWN = {
    'crypto': '^3.0.6',
    'flutter_tts': '^4.2.5',
    'html': '^0.15.4',
    'permission_handler': '^11.3.1',
    'shared_preferences': '^2.3.3',
    'speech_to_text': '^7.0.0',
    'video_player': '^2.9.2',
    'webview_flutter': '^4.10.0',
    'http': '^1.2.2',
    'path_provider': '^2.1.5',
    'url_launcher': '^6.3.1',
    'file_picker': '^8.1.6',
}
SDK_PKGS = {'flutter', 'flutter_test', 'flutter_localizations', 'flutter_web_plugins', 'integration_test'}

REQUIRED_SOURCES = [
    'lib/main.dart',
    'lib/parental/parental.dart', 'lib/parental/age_profile.dart', 'lib/parental/mini_http.dart',
    'lib/parental/parental_controller.dart', 'lib/parental/safe_filter.dart',
    'lib/parental/study_builder.dart', 'lib/parental/parental_ui.dart',
    'lib/shield/shield.dart', 'lib/shield/bloom_filter.dart', 'lib/shield/shield_engine.dart',
    'lib/shield/shield_lists.dart', 'lib/shield/shield_rules.dart', 'lib/shield/shield_types.dart',
    'lib/shield/shield_ui.dart',
    'lib/video/video_search.dart',
]

RESTORABLE = [
    'android/app/build.gradle.kts',
    'android/app/src/main/res/drawable/ic_launcher_foreground.xml',
    'android/app/src/main/res/drawable/launch_background.xml',
    'android/app/src/main/res/drawable-v21/launch_background.xml',
    'android/app/src/main/res/values/ic_launcher_background.xml',
    'android/app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml',
    'android/app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml',
]

PERMISSIONS = ['INTERNET', 'ACCESS_NETWORK_STATE', 'POST_NOTIFICATIONS', 'RECORD_AUDIO']
QUERIES = {
    'android.speech.RecognitionService': '        <intent>\n            <action android:name="android.speech.RecognitionService" />\n        </intent>\n',
    'android.intent.action.TTS_SERVICE': '        <intent>\n            <action android:name="android.intent.action.TTS_SERVICE" />\n        </intent>\n',
}
APP_ID = 'com.webscout.universal'


class Report:
    def __init__(self):
        self.rows = []

    def add(self, status, title, detail=''):
        self.rows.append((status, title, detail))
        icon = {'OK': '✅', 'FIXED': '🛠️', 'WARN': '⚠️', 'ERROR': '❌'}[status]
        print(f'{icon} [{status}] {title}' + (f' — {detail}' if detail else ''))

    @property
    def errors(self):
        return sum(1 for r in self.rows if r[0] == 'ERROR')

    def markdown(self):
        lines = ['## Validación del proyecto', '', '| Estado | Comprobación | Detalle |', '|---|---|---|']
        for s, t, d in self.rows:
            lines.append(f'| {s} | {t} | {d.replace("|", "/")} |')
        lines.append('')
        lines.append(f'Errores sin reparar: **{self.errors}**')
        return '\n'.join(lines) + '\n'


def read(p: Path) -> str:
    return p.read_text(encoding='utf-8', errors='replace')


def write(p: Path, s: str):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(s, encoding='utf-8')


def restore(root: Path, rel: str, rep: Report, why: str) -> bool:
    src = root / 'tools' / 'templates' / rel
    dst = root / rel
    if not src.exists():
        return False
    if dst.exists():
        shutil.copy2(dst, str(dst) + '.bak')
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    rep.add('FIXED', f'Restaurado {rel}', why)
    return True


# ---------------------------------------------------------------- archivos obligatorios

def check_required(root: Path, rep: Report, fix: bool):
    missing = []
    for rel in REQUIRED_SOURCES:
        if not (root / rel).exists():
            missing.append(rel)
    if missing:
        for m in missing:
            rep.add('ERROR', f'Falta {m}', 'Archivo de código obligatorio: vuelve a subir el ZIP completo del proyecto.')
    else:
        rep.add('OK', 'Archivos Dart obligatorios', f'{len(REQUIRED_SOURCES)} presentes')
    for rel in RESTORABLE:
        if not (root / rel).exists():
            if fix and restore(root, rel, rep, 'faltaba en el ZIP'):
                continue
            rep.add('ERROR', f'Falta {rel}', 'No hay plantilla de respaldo.')
    if not (root / 'pubspec.yaml').exists():
        rep.add('ERROR', 'Falta pubspec.yaml')
    if not (root / '.github' / 'workflows' / 'build.yml').exists():
        rep.add('WARN', 'No está .github/workflows/build.yml', 'Debe estar confirmado (commit) en el repositorio para que GitHub lo ejecute.')


# ---------------------------------------------------------------- pubspec

def dart_files(root: Path):
    return sorted((root / 'lib').rglob('*.dart')) if (root / 'lib').exists() else []


def imported_packages(root: Path):
    pk = set()
    rx = re.compile(r'''^\s*(?:import|export)\s+['"]package:([A-Za-z0-9_]+)/''', re.M)
    for f in dart_files(root):
        pk.update(rx.findall(read(f)))
    return pk


def deps_block(lines):
    """Devuelve (índice de la línea 'dependencies:', nombres declarados)."""
    start = None
    for i, l in enumerate(lines):
        if re.match(r'^dependencies:\s*$', l):
            start = i
            break
    if start is None:
        return None, set()
    names = set()
    for l in lines[start + 1:]:
        if l.strip() and not l.startswith((' ', '\t', '#')):
            break
        m = re.match(r'^  ([A-Za-z0-9_]+):', l)
        if m:
            names.add(m.group(1))
    return start, names


def check_pubspec(root: Path, rep: Report, fix: bool):
    p = root / 'pubspec.yaml'
    if not p.exists():
        return
    text = read(p)
    changed = False

    if not re.search(r'(?m)^name:\s*\S+', text):
        text = 'name: webscout_universal\n' + text
        changed = True
        rep.add('FIXED', 'pubspec: faltaba name', 'name: webscout_universal')
    own = re.search(r'(?m)^name:\s*(\S+)', text).group(1)

    m = re.search(r'(?m)^version:\s*(\S+)\s*$', text)
    if not m:
        text = re.sub(r'(?m)^(name:\s*\S+\s*)$', r'\1\nversion: 1.0.0+1', text, count=1)
        changed = True
        rep.add('FIXED', 'pubspec: faltaba version', 'version: 1.0.0+1')
    else:
        v = m.group(1)
        if re.fullmatch(r'\d+\.\d+\.\d+\+\d+', v):
            rep.add('OK', 'pubspec: version', f'{v} (el número tras "+" es el versionCode)')
        elif re.fullmatch(r'\d+\.\d+\.\d+', v):
            text = re.sub(r'(?m)^version:\s*' + re.escape(v) + r'\s*$', f'version: {v}+1', text, count=1)
            changed = True
            rep.add('FIXED', 'pubspec: version sin versionCode', f'{v} -> {v}+1')
        else:
            rep.add('ERROR', 'pubspec: version inválida', f'"{v}" debe ser x.y.z+n')

    if not re.search(r'(?m)^environment:', text):
        text = text.rstrip('\n') + "\n\nenvironment:\n  sdk: '>=3.4.0 <4.0.0'\n"
        changed = True
        rep.add('FIXED', 'pubspec: faltaba environment')

    lines = text.split('\n')
    start, names = deps_block(lines)
    if start is None:
        lines += ['', 'dependencies:', '  flutter:', '    sdk: flutter']
        text = '\n'.join(lines)
        lines = text.split('\n')
        start, names = deps_block(lines)
        changed = True
        rep.add('FIXED', 'pubspec: faltaba dependencies')
    inject = []
    if 'flutter' not in names:
        inject += ['  flutter:', '    sdk: flutter']
        rep.add('FIXED', 'pubspec: faltaba el SDK de flutter')
    needed = imported_packages(root) - SDK_PKGS - {own}
    for pkg in sorted(needed - names):
        ver = KNOWN.get(pkg)
        if ver:
            inject.append(f'  {pkg}: {ver}')
            rep.add('FIXED', f'Dependencia inyectada: {pkg}', f'el código la importa y faltaba en pubspec ({ver})')
        else:
            inject.append(f'  {pkg}: any')
            rep.add('WARN', f'Dependencia inyectada sin versión conocida: {pkg}', 'se usó "any"; si no existe en pub.dev el build fallará')
    if not needed - names:
        rep.add('OK', 'pubspec: dependencias vs imports', f'{len(needed)} paquetes de terceros declarados')
    if inject:
        lines[start + 1:start + 1] = inject
        text = '\n'.join(lines)
        changed = True

    if not re.search(r'(?m)^flutter:\s*$', text):
        text = text.rstrip('\n') + '\n\nflutter:\n  uses-material-design: true\n'
        changed = True
        rep.add('FIXED', 'pubspec: faltaba sección flutter')
    elif 'uses-material-design' not in text:
        text = re.sub(r'(?m)^flutter:\s*$', 'flutter:\n  uses-material-design: true', text, count=1)
        changed = True
        rep.add('FIXED', 'pubspec: uses-material-design')

    if changed:
        if fix:
            shutil.copy2(p, str(p) + '.bak')
            write(p, text if text.endswith('\n') else text + '\n')
        else:
            rep.add('WARN', 'pubspec: hay correcciones pendientes (ejecuta con --fix)')


# ---------------------------------------------------------------- manifest

def check_manifest(root: Path, rep: Report, fix: bool):
    p = root / 'android/app/src/main/AndroidManifest.xml'
    if not p.exists():
        rep.add('ERROR', 'Falta AndroidManifest.xml')
        return
    s = read(p)
    changed = False
    for perm in PERMISSIONS:
        if f'android.permission.{perm}' not in s:
            m = re.search(r'<manifest[^>]*>', s)
            if not m:
                rep.add('ERROR', 'AndroidManifest.xml sin etiqueta <manifest>')
                return
            line = f'\n    <uses-permission android:name="android.permission.{perm}" />'
            s = s[:m.end()] + line + s[m.end():]
            changed = True
            rep.add('FIXED', f'Permiso inyectado: {perm}')
    if '<queries>' not in s:
        block = '\n    <queries>\n' + ''.join(QUERIES.values()) + '    </queries>\n'
        s = s.replace('</manifest>', block + '</manifest>')
        changed = True
        rep.add('FIXED', 'Inyectado <queries> (voz y TTS)')
    else:
        for key, frag in QUERIES.items():
            if key not in s:
                s = s.replace('</queries>', frag + '    </queries>')
                changed = True
                rep.add('FIXED', f'Inyectado query: {key}')
    if 'android.intent.action.SEND' not in s and '</activity>' in s:
        send = ('            <intent-filter>\n                <action android:name="android.intent.action.SEND" />\n'
                '                <category android:name="android.intent.category.DEFAULT" />\n'
                '                <data android:mimeType="text/plain" />\n            </intent-filter>\n')
        s = s.replace('</activity>', send + '        </activity>', 1)
        changed = True
        rep.add('FIXED', 'Inyectado intent-filter de "Compartir" (SEND text/plain)')
    if 'flutterEmbedding' not in s:
        s = s.replace('</application>', '        <meta-data android:name="flutterEmbedding" android:value="2" />\n    </application>')
        changed = True
        rep.add('FIXED', 'Inyectado flutterEmbedding=2')
    if 'android:exported' not in s:
        rep.add('ERROR', 'La activity no declara android:exported', 'Obligatorio con targetSdk 31+.')
    if changed:
        if fix:
            shutil.copy2(p, str(p) + '.bak')
            write(p, s)
    else:
        rep.add('OK', 'AndroidManifest.xml', 'permisos y queries presentes')


# ---------------------------------------------------------------- gradle + paquete

def check_gradle(root: Path, rep: Report, fix: bool):
    g = root / 'android/app/build.gradle.kts'
    markers = [APP_ID, 'hasReleaseSigning', 'signingConfigs', 'flutter {']
    ok = g.exists() and all(m in read(g) for m in markers)
    if not ok:
        if fix and restore(root, 'android/app/build.gradle.kts', rep, 'faltaba o no tenía la firma release fija'):
            pass
        else:
            rep.add('ERROR', 'build.gradle.kts sin firma release fija')
    else:
        rep.add('OK', 'build.gradle.kts', f'applicationId {APP_ID} + firma release')
    groovy = root / 'android/app/build.gradle'
    if groovy.exists() and (root / 'android/app/build.gradle.kts').exists():
        if fix:
            shutil.move(str(groovy), str(groovy) + '.bak')
            rep.add('FIXED', 'Eliminado android/app/build.gradle duplicado', 'convive con build.gradle.kts y causa ambigüedad')
        else:
            rep.add('WARN', 'Existen build.gradle y build.gradle.kts a la vez')


def prune_empty(d: Path, stop: Path):
    while d != stop and d.exists() and d.is_dir() and not any(d.iterdir()):
        d.rmdir()
        d = d.parent


def check_package(root: Path, rep: Report, fix: bool):
    g = root / 'android/app/build.gradle.kts'
    if not g.exists():
        return
    gs = read(g)
    ns = re.search(r'namespace\s*=\s*"([^"]+)"', gs)
    aid = re.search(r'applicationId\s*=\s*"([^"]+)"', gs)
    if not ns or not aid:
        rep.add('ERROR', 'Gradle sin namespace o applicationId')
        return
    ns, aid = ns.group(1), aid.group(1)
    if aid != APP_ID:
        rep.add('WARN', 'applicationId distinto del fijo', f'{aid} != {APP_ID}: no podrá actualizar la app ya instalada')
    kroot = root / 'android/app/src/main/kotlin'
    acts = sorted(kroot.rglob('MainActivity.kt')) if kroot.exists() else []
    if not acts:
        rep.add('ERROR', 'Falta MainActivity.kt', 'Contiene el puente nativo (descargas, SAF); no se puede regenerar.')
        return
    good = None
    for a in acts:
        pk = re.search(r'(?m)^package\s+([\w.]+)', read(a))
        if pk and pk.group(1) == ns and a.parent == kroot.joinpath(*ns.split('.')):
            good = a
    if good is None:
        a = acts[0]
        src = read(a)
        src = re.sub(r'(?m)^package\s+[\w.]+', f'package {ns}', src, count=1)
        dst = kroot.joinpath(*ns.split('.')) / 'MainActivity.kt'
        if fix:
            write(dst, src)
            if a != dst:
                a.unlink()
                prune_empty(a.parent, kroot)
            rep.add('FIXED', 'MainActivity.kt alineada con el namespace', f'package {ns}')
            good = dst
        else:
            rep.add('WARN', 'MainActivity.kt no coincide con el namespace')
    else:
        rep.add('OK', 'Paquete', f'namespace = applicationId = MainActivity = {ns}')
    for a in acts:
        if good is not None and a != good and a.exists() and fix:
            a.unlink()
            prune_empty(a.parent, kroot)
            rep.add('FIXED', 'Eliminada MainActivity duplicada', str(a.relative_to(root)))
    if good is not None and 'webscout/native' not in read(good):
        rep.add('ERROR', 'MainActivity.kt no contiene el puente nativo', 'Falta el canal "webscout/native" (es la plantilla genérica de Flutter).')


# ---------------------------------------------------------------- Dart

def strip_dart(s: str) -> str:
    s = re.sub(r"r'''.*?'''|'''.*?'''|r'[^'\n]*'|'(?:\\.|[^'\\\n])*'|\"(?:\\.|[^\"\\\n])*\"", '""', s, flags=re.S)
    s = re.sub(r'/\*.*?\*/', '', s, flags=re.S)
    return re.sub(r'//[^\n]*', '', s)


def check_dart(root: Path, rep: Report):
    files = dart_files(root)
    if not files:
        rep.add('ERROR', 'No hay archivos Dart en lib/')
        return
    bad = 0
    rx = re.compile(r'''^\s*(?:import|export)\s+['"](?!package:|dart:)([^'"]+)['"]''', re.M)
    for f in files:
        s = read(f)
        t = strip_dart(s)
        for a, b in ('()', '{}', '[]'):
            if t.count(a) != t.count(b):
                rep.add('ERROR', f'{f.relative_to(root)}: {a}{b} desbalanceados', f'{t.count(a)} vs {t.count(b)}')
                bad += 1
                break
        for rel in rx.findall(s):
            if not (f.parent / rel).resolve().exists():
                rep.add('ERROR', f'{f.relative_to(root)}: import relativo inexistente', rel)
                bad += 1
    main = root / 'lib/main.dart'
    if main.exists() and not re.search(r'\bvoid\s+main\s*\(', read(main)):
        rep.add('ERROR', 'lib/main.dart sin función main()')
        bad += 1
    if bad == 0:
        rep.add('OK', 'Dart: sintaxis básica e imports', f'{len(files)} archivos')


# ---------------------------------------------------------------- modos auxiliares

def relax(root: Path, rep: Report):
    p = root / 'pubspec.yaml'
    lines = read(p).split('\n')
    start, _ = deps_block(lines)
    if start is None:
        rep.add('ERROR', 'Sin bloque dependencies')
        return
    n = 0
    for i in range(start + 1, len(lines)):
        l = lines[i]
        if l.strip() and not l.startswith((' ', '\t', '#')):
            break
        m = re.match(r'^(  [A-Za-z0-9_]+):\s*([\^<>=~\d][^#\n]*?)\s*(#.*)?$', l)
        if m and m.group(1).strip() != 'flutter':
            lines[i] = f'{m.group(1)}: any' + (f'  {m.group(3)}' if m.group(3) else '')
            n += 1
    shutil.copy2(p, str(p) + '.bak')
    write(p, '\n'.join(lines))
    rep.add('FIXED', 'Restricciones de versión relajadas', f'{n} dependencias -> any (para que pub get resuelva)')


def post(root: Path, rep: Report):
    cfg = root / '.dart_tool' / 'package_config.json'
    if not cfg.exists():
        rep.add('ERROR', 'No existe .dart_tool/package_config.json', 'flutter pub get no se ejecutó')
        return
    have = {p['name'] for p in json.load(open(cfg, encoding='utf-8'))['packages']}
    own = re.search(r'(?m)^name:\s*(\S+)', read(root / 'pubspec.yaml')).group(1)
    missing = sorted(imported_packages(root) - SDK_PKGS - {own} - have)
    if not missing:
        rep.add('OK', 'Paquetes resueltos', f'{len(have)} en package_config')
        return
    for pkg in missing:
        r = subprocess.run(['flutter', 'pub', 'add', pkg], capture_output=True, text=True)
        if r.returncode == 0:
            rep.add('FIXED', f'flutter pub add {pkg}', 'inyectado antes de compilar')
        else:
            rep.add('ERROR', f'No se pudo agregar {pkg}', (r.stderr or r.stdout)[-200:].replace('\n', ' '))


def gradle_fallback(root: Path, rep: Report):
    g = root / 'android/app/build.gradle.kts'
    s = read(g)
    s2 = re.sub(r'(?m)^import org\.jetbrains\.kotlin\.gradle\.dsl\.JvmTarget\s*\n', '', s)
    s2 = re.sub(r'(?s)\nkotlin \{\s*compilerOptions \{.*?\}\s*\}\n', '\n', s2)
    if s2 != s:
        shutil.copy2(g, str(g) + '.bak')
        write(g, s2)
        rep.add('FIXED', 'Gradle: eliminado el bloque kotlin { compilerOptions }', 'respaldo para toolchains que no lo aceptan')
    else:
        rep.add('WARN', 'Gradle: nada que simplificar')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default='.')
    ap.add_argument('--fix', action='store_true')
    ap.add_argument('--relax', action='store_true')
    ap.add_argument('--post', action='store_true')
    ap.add_argument('--gradle-fallback', action='store_true')
    ap.add_argument('--report', default='')
    a = ap.parse_args()
    root = Path(a.root).resolve()
    rep = Report()

    if a.relax:
        relax(root, rep)
    elif a.post:
        post(root, rep)
    elif a.gradle_fallback:
        gradle_fallback(root, rep)
    else:
        check_required(root, rep, a.fix)
        check_pubspec(root, rep, a.fix)
        check_manifest(root, rep, a.fix)
        check_gradle(root, rep, a.fix)
        check_package(root, rep, a.fix)
        check_dart(root, rep)

    md = rep.markdown()
    out = root / 'build' / 'validation-report.md'
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, 'a', encoding='utf-8') as fh:
        fh.write(md + '\n')
    if a.report:
        try:
            with open(a.report, 'a', encoding='utf-8') as fh:
                fh.write(md + '\n')
        except OSError:
            pass
    sys.exit(1 if rep.errors else 0)


if __name__ == '__main__':
    main()
