package mx.cifracaja.app.crypto;

import static org.junit.Assert.*;

import java.util.Arrays;
import org.junit.Test;

public class PinHasherTest {
    @Test public void weakPinsAreDetected() {
        for (String p : new String[]{"0000", "1111", "1234", "4321", "123456", "98765432"})
            assertTrue(p, PinHasher.isWeak(p.toCharArray()));
        for (String p : new String[]{"1357", "2580", "482915", "13572468"})
            assertFalse(p, PinHasher.isWeak(p.toCharArray()));
    }

    @Test public void deriveIsDeterministicAndSaltDependent() throws Exception {
        byte[] s1 = PinHasher.newSalt(), s2 = PinHasher.newSalt();
        byte[] a = PinHasher.derive("482915".toCharArray(), s1, 1000);
        assertArrayEquals(a, PinHasher.derive("482915".toCharArray(), s1, 1000));
        assertFalse(Arrays.equals(a, PinHasher.derive("482915".toCharArray(), s2, 1000)));
        assertFalse(Arrays.equals(a, PinHasher.derive("482916".toCharArray(), s1, 1000)));
    }
}
