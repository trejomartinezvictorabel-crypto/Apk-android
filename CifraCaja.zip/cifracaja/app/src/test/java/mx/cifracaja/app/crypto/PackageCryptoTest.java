package mx.cifracaja.app.crypto;

import static org.junit.Assert.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Arrays;
import java.util.Random;
import org.junit.Test;

public class PackageCryptoTest {
    private static final char[] PW = "clave-super-secreta-123".toCharArray();

    private static byte[] enc(byte[] data, byte mode) throws Exception {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        PackageMeta m = new PackageMeta(mode, "foto.jpg", "jpg", data.length, 0);
        PackageCrypto.encrypt(PW.clone(), m, new ByteArrayInputStream(data), o, null);
        return o.toByteArray();
    }

    private static byte[] dec(byte[] pkg, char[] pw) throws Exception {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        PackageCrypto.decrypt(pw, new ByteArrayInputStream(pkg), o, false, null);
        return o.toByteArray();
    }

    private static void assertCode(byte[] pkg, char[] pw, String code) throws Exception {
        try { dec(pkg, pw); fail("debia fallar con " + code); }
        catch (CryptoException e) { assertEquals(code, e.code); }
    }

    @Test public void roundTripSizes() throws Exception {
        for (int n : new int[]{0, 1, 65535, 65536, 65537, 150000}) {
            byte[] d = new byte[n]; new Random(n).nextBytes(d);
            assertArrayEquals(d, dec(enc(d, PackageMeta.MODE_FILE), PW.clone()));
        }
    }

    @Test public void wrongKeyRejected() throws Exception {
        assertCode(enc(new byte[10], PackageMeta.MODE_TEXT), "otra-clave-distinta".toCharArray(),
                CryptoException.KEY_OR_HEADER);
    }

    @Test public void everyByteFlipRejected() throws Exception {
        byte[] p = enc("hola mundo".getBytes(), PackageMeta.MODE_TEXT);
        for (int i = 0; i < p.length; i++) {
            byte[] t = p.clone(); t[i] ^= 1;
            try { dec(t, PW.clone()); fail("byte " + i + " aceptado"); }
            catch (CryptoException expected) { }
        }
    }

    @Test public void truncationAndTrailingRejected() throws Exception {
        byte[] p = enc(new byte[100000], PackageMeta.MODE_FILE);
        try { dec(Arrays.copyOf(p, p.length - 1), PW.clone()); fail(); } catch (CryptoException e) { }
        try { dec(Arrays.copyOf(p, p.length - 200), PW.clone()); fail(); } catch (CryptoException e) { }
        byte[] extra = Arrays.copyOf(p, p.length + 1);
        assertCode(extra, PW.clone(), CryptoException.TRUNC);
    }

    @Test public void foreignDataRejected() throws Exception {
        assertCode("texto cualquiera que no es de la app".getBytes(), PW.clone(), CryptoException.FORMAT);
    }

    @Test public void uniqueSaltAndNonce() throws Exception {
        byte[] a = enc(new byte[5], PackageMeta.MODE_TEXT), b = enc(new byte[5], PackageMeta.MODE_TEXT);
        assertFalse(Arrays.equals(a, b));
    }

    @Test public void fingerprintStable() throws Exception {
        String f1 = KeyFingerprint.of(PW.clone());
        assertEquals(f1, KeyFingerprint.of(PW.clone()));
        assertNotEquals(f1, KeyFingerprint.of("otra-clave-distinta".toCharArray()));
        assertTrue(f1.matches("([0-9A-F]{4}-){3}[0-9A-F]{4}"));
    }

    @Test public void pbkdf2KnownVector() throws Exception {
        // RFC 7914 5.2: P="passwd", S="salt", c=1, dkLen=64 (primeros bytes 55 ac 04 6e)
        byte[] k = Pbkdf2.derive("passwd".getBytes(), "salt".getBytes(), 1, 64);
        assertEquals(0x55, k[0] & 0xFF); assertEquals(0xac, k[1] & 0xFF);
        assertEquals(0x04, k[2] & 0xFF); assertEquals(0x6e, k[3] & 0xFF);
    }

    private static byte[] encMeta(PackageMeta m, byte[] data) throws Exception {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        PackageCrypto.encrypt(PW.clone(), m, new ByteArrayInputStream(data), o, null);
        return o.toByteArray();
    }

    @Test public void metaFieldsRoundTrip() throws Exception {
        long exp = System.currentTimeMillis() + 3_600_000L;
        byte[] p = encMeta(new PackageMeta(PackageMeta.MODE_FILE, "a.pdf", "pdf", 5, exp, true), new byte[5]);
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        PackageMeta m = PackageCrypto.decrypt(PW.clone(), new ByteArrayInputStream(p), o, false, null);
        assertEquals(exp, m.expiresAt);
        assertTrue(m.singleUse);
        assertEquals(16, m.packageId.length);
        assertEquals("a.pdf", m.name);
    }

    @Test public void packageIdUniquePerPackage() throws Exception {
        PackageMeta m = new PackageMeta(PackageMeta.MODE_TEXT, "", "", 1, 0, true);
        byte[] a = encMeta(m, new byte[1]), b = encMeta(m, new byte[1]);
        PackageMeta ma = PackageCrypto.decrypt(PW.clone(), new ByteArrayInputStream(a), new ByteArrayOutputStream(), false, null);
        PackageMeta mb = PackageCrypto.decrypt(PW.clone(), new ByteArrayInputStream(b), new ByteArrayOutputStream(), false, null);
        assertNotEquals(ma.idHex(), mb.idHex());
    }

    @Test public void expiredRejectedBeforeAnyOutput() throws Exception {
        byte[] p = encMeta(new PackageMeta(PackageMeta.MODE_TEXT, "", "", 3, System.currentTimeMillis() - 1000), new byte[3]);
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        try {
            PackageCrypto.decrypt(PW.clone(), new ByteArrayInputStream(p), o, false, null);
            fail();
        } catch (CryptoException e) { assertEquals(CryptoException.EXPIRED, e.code); }
        assertEquals(0, o.size());
    }

    @Test public void policyRunsBeforeDataAndAfterSuccessOnly() throws Exception {
        byte[] p = encMeta(new PackageMeta(PackageMeta.MODE_TEXT, "", "", 3, 0, true), new byte[3]);
        final int[] calls = {0, 0};
        PackageCrypto.Policy pol = new PackageCrypto.Policy() {
            public void beforeData(PackageMeta m) throws CryptoException { calls[0]++; throw new CryptoException(CryptoException.USED); }
            public void afterSuccess(PackageMeta m) { calls[1]++; }
        };
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        try { PackageCrypto.decrypt(PW.clone(), new ByteArrayInputStream(p), o, pol, null); fail(); }
        catch (CryptoException e) { assertEquals(CryptoException.USED, e.code); }
        assertEquals(1, calls[0]); assertEquals(0, calls[1]); assertEquals(0, o.size());
        // truncado: afterSuccess nunca debe ejecutarse
        final int[] after = {0};
        PackageCrypto.Policy ok = new PackageCrypto.Policy() {
            public void beforeData(PackageMeta m) { }
            public void afterSuccess(PackageMeta m) { after[0]++; }
        };
        try { PackageCrypto.decrypt(PW.clone(), new ByteArrayInputStream(Arrays.copyOf(p, p.length - 1)), new ByteArrayOutputStream(), ok, null); fail(); }
        catch (CryptoException e) { }
        assertEquals(0, after[0]);
        PackageCrypto.decrypt(PW.clone(), new ByteArrayInputStream(p), new ByteArrayOutputStream(), ok, null);
        assertEquals(1, after[0]);
    }
}
