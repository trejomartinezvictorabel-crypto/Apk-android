package mx.cifracaja.app.crypto;

import static org.junit.Assert.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.util.Arrays;
import java.util.Random;
import javax.crypto.Cipher;
import org.junit.Test;

public class HybridSignatureTest {
    private static final KeyPair ALICE = gen(), BOB = gen();

    private static KeyPair gen() {
        try {
            KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
            g.initialize(2048);
            return g.generateKeyPair();
        } catch (Exception e) { throw new RuntimeException(e); }
    }

    private static byte[] id(PublicKey k) throws Exception {
        return Arrays.copyOf(MessageDigest.getInstance("SHA-256").digest(k.getEncoded()), 8);
    }

    private static PackageCrypto.KeyWrapper wrapperFor(final PublicKey k) {
        return new PackageCrypto.KeyWrapper() {
            public byte[] recipientId() { try { return id(k); } catch (Exception e) { throw new RuntimeException(e); } }
            public byte[] wrap(byte[] secret) throws Exception {
                Cipher c = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
                c.init(Cipher.ENCRYPT_MODE, k);
                return c.doFinal(secret);
            }
        };
    }

    private static PackageCrypto.KeyUnwrapper unwrapperFor(final KeyPair kp) {
        return new PackageCrypto.KeyUnwrapper() {
            public boolean isRecipient(byte[] rid) { try { return Arrays.equals(rid, id(kp.getPublic())); } catch (Exception e) { return false; } }
            public byte[] unwrap(byte[] w) throws Exception {
                Cipher c = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
                c.init(Cipher.DECRYPT_MODE, kp.getPrivate());
                return c.doFinal(w);
            }
        };
    }

    private static PackageCrypto.Signer signerFor(final KeyPair kp) {
        return new PackageCrypto.Signer() {
            public byte[] signerId() { try { return id(kp.getPublic()); } catch (Exception e) { throw new RuntimeException(e); } }
            public byte[] sign(byte[] m) throws Exception {
                Signature s = Signature.getInstance("SHA256withRSA");
                s.initSign(kp.getPrivate());
                s.update(m);
                return s.sign();
            }
        };
    }

    private static PackageCrypto.SigVerifier verifierKnowing(final KeyPair... known) {
        return new PackageCrypto.SigVerifier() {
            public PackageCrypto.SigStatus verify(byte[] sid, byte[] msg, byte[] sig) throws CryptoException {
                try {
                    for (KeyPair kp : known) {
                        if (!Arrays.equals(sid, id(kp.getPublic()))) continue;
                        Signature s = Signature.getInstance("SHA256withRSA");
                        s.initVerify(kp.getPublic());
                        s.update(msg);
                        if (!s.verify(sig)) throw new CryptoException(CryptoException.SIG);
                        return PackageCrypto.SigStatus.VALID;
                    }
                } catch (CryptoException e) { throw e; } catch (Exception e) { throw new CryptoException(CryptoException.SIG); }
                return PackageCrypto.SigStatus.UNKNOWN_SIGNER;
            }
        };
    }

    private static final PackageCrypto.Policy NOOP = new PackageCrypto.Policy() {
        public void beforeData(PackageMeta m) { }
        public void afterSuccess(PackageMeta m) { }
    };

    private static byte[] enc(byte[] data, PackageCrypto.Options o) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PackageCrypto.encrypt(o, new PackageMeta(PackageMeta.MODE_FILE, "f.bin", "bin", data.length, 0),
                new ByteArrayInputStream(data), out, null);
        return out.toByteArray();
    }

    private static PackageCrypto.Result dec(byte[] pkg, PackageCrypto.Credentials c, ByteArrayOutputStream out) throws Exception {
        return PackageCrypto.decryptEx(c, new ByteArrayInputStream(pkg), out, NOOP, null);
    }

    private static PackageCrypto.Credentials creds(KeyPair me, PackageCrypto.SigVerifier v) {
        PackageCrypto.Credentials c = new PackageCrypto.Credentials();
        c.unwrapper = unwrapperFor(me);
        c.verifier = v;
        return c;
    }

    @Test public void hybridRoundTripOnlyRecipientCanOpen() throws Exception {
        byte[] data = new byte[150000]; new Random(5).nextBytes(data);
        PackageCrypto.Options o = new PackageCrypto.Options();
        o.wrapper = wrapperFor(BOB.getPublic());
        byte[] p = enc(data, o);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PackageCrypto.Result r = dec(p, creds(BOB, null), out);
        assertArrayEquals(data, out.toByteArray());
        assertEquals(PackageCrypto.SigStatus.NONE, r.sig);
        try { dec(p, creds(ALICE, null), new ByteArrayOutputStream()); fail(); }
        catch (CryptoException e) { assertEquals(CryptoException.RECIPIENT, e.code); }
    }

    @Test public void signedPackageVerifiesAndTamperIsRejected() throws Exception {
        byte[] data = "hola".getBytes();
        PackageCrypto.Options o = new PackageCrypto.Options();
        o.wrapper = wrapperFor(BOB.getPublic());
        o.signer = signerFor(ALICE);
        byte[] p = enc(data, o);
        PackageCrypto.Result r = dec(p, creds(BOB, verifierKnowing(ALICE)), new ByteArrayOutputStream());
        assertEquals(PackageCrypto.SigStatus.VALID, r.sig);
        assertArrayEquals(id(ALICE.getPublic()), r.signerId);
        // desconocido: se abre pero se marca como no verificado
        assertEquals(PackageCrypto.SigStatus.UNKNOWN_SIGNER,
                dec(p, creds(BOB, verifierKnowing()), new ByteArrayOutputStream()).sig);
        // cualquier byte alterado (salvo el id del firmante, que solo lo vuelve "desconocido") se rechaza
        int trailer = p.length - (8 + 2 + 256);
        for (int i = 0; i < p.length; i++) {
            if (i >= trailer && i < trailer + 8) continue;
            byte[] t = p.clone(); t[i] ^= 1;
            try { dec(t, creds(BOB, verifierKnowing(ALICE)), new ByteArrayOutputStream()); fail("byte " + i); }
            catch (CryptoException expected) { }
        }
    }

    @Test public void signatureCannotBeStripped() throws Exception {
        PackageCrypto.Options o = new PackageCrypto.Options();
        o.passphrase = "clave-super-secreta-123".toCharArray();
        o.signer = signerFor(ALICE);
        byte[] p = enc("x".getBytes(), o);
        byte[] cut = Arrays.copyOf(p, p.length - (8 + 2 + 256));
        PackageCrypto.Credentials c = new PackageCrypto.Credentials();
        c.passphrase = "clave-super-secreta-123".toCharArray();
        try { dec(cut, c, new ByteArrayOutputStream()); fail(); }
        catch (CryptoException e) { assertEquals(CryptoException.TRUNC, e.code); }
    }

    @Test public void passphraseModeCanAlsoBeSigned() throws Exception {
        PackageCrypto.Options o = new PackageCrypto.Options();
        o.passphrase = "clave-super-secreta-123".toCharArray();
        o.signer = signerFor(ALICE);
        byte[] p = enc("x".getBytes(), o);
        PackageCrypto.Credentials c = new PackageCrypto.Credentials();
        c.passphrase = "clave-super-secreta-123".toCharArray();
        c.verifier = verifierKnowing(ALICE);
        assertEquals(PackageCrypto.SigStatus.VALID, dec(p, c, new ByteArrayOutputStream()).sig);
    }

    @Test public void missingPassphraseAsksForKey() throws Exception {
        PackageCrypto.Options o = new PackageCrypto.Options();
        o.passphrase = "clave-super-secreta-123".toCharArray();
        byte[] p = enc("x".getBytes(), o);
        try { dec(p, new PackageCrypto.Credentials(), new ByteArrayOutputStream()); fail(); }
        catch (CryptoException e) { assertEquals(CryptoException.NEED_KEY, e.code); }
    }
}
