package mx.cifracaja.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.UriPermission;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.text.format.Formatter;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Exportacion voluntaria a Descargas o microSD y borrado de lo exportado. */
public class ExportActivity extends BaseActivity {
    private static final int REQ_TREE = 3001;
    private static final int REQ_PERM = 3002;
    private static final String TAG = "CJA";
    private static final String[] DIRS = {"enc", "capture", "dec"};

    private static final class SpaceException extends Exception {}

    private LinearLayout privateBox, exportedBox;
    private TextView statusView, destView;
    private ProgressBar progress;
    private File pendingFile;
    private boolean busy;
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());

    // ------------------------------------------------------------------ UI

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE);
        int pad = dp(16);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = text(R.string.export_title, 22);
        root.addView(title);
        Button change = new Button(this);
        change.setText(R.string.btn_change_folder);
        change.setAllCaps(false);
        change.setOnClickListener(v -> {
            status(getString(R.string.pick_card_hint));
            pendingFile = null;
            launchTreePicker();
        });
        root.addView(change);
        destView = new TextView(this);
        root.addView(destView);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setIndeterminate(true);
        progress.setVisibility(View.GONE);
        root.addView(progress);
        statusView = new TextView(this);
        statusView.setPadding(0, dp(8), 0, dp(8));
        root.addView(statusView);

        root.addView(text(R.string.export_private_section, 17));
        privateBox = new LinearLayout(this);
        privateBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(privateBox);

        root.addView(text(R.string.export_exported_section, 17));
        exportedBox = new LinearLayout(this);
        exportedBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(exportedBox);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
        refresh();
    }

    @Override
    protected void onDestroy() {
        exec.shutdown();
        super.onDestroy();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(int res, int size) {
        TextView t = new TextView(this);
        t.setText(res);
        t.setTextSize(size);
        t.setPadding(0, dp(12), 0, dp(4));
        return t;
    }

    private Button btn(int res, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(res);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private void status(String s) {
        statusView.setText(s);
    }

    private void setBusy(boolean b) {
        busy = b;
        progress.setVisibility(b ? View.VISIBLE : View.GONE);
    }

    private void confirm(String msg, Runnable ok) {
        new AlertDialog.Builder(this)
                .setMessage(msg)
                .setPositiveButton(R.string.btn_yes, (d, w) -> ok.run())
                .setNegativeButton(R.string.btn_no, null)
                .show();
    }

    private String folderLabel(String dir) {
        switch (dir) {
            case "enc": return getString(R.string.folder_enc);
            case "capture": return getString(R.string.folder_capture);
            default: return getString(R.string.folder_dec);
        }
    }

    private String destLabel(String kind) {
        return ExportStore.KIND_SAF.equals(kind)
                ? getString(R.string.dest_folder) : getString(R.string.dest_downloads);
    }

    private boolean toDownloads() {
        return !"card".equals(ExportStore.getDest(this));
    }

    private void refresh() {
        destView.setText(getString(R.string.export_dest_current,
                getString(toDownloads() ? R.string.dest_downloads : R.string.dest_folder)));
        privateBox.removeAllViews();
        int count = 0;
        for (String dir : DIRS) {
            File[] list = VaultStorage.dir(this, dir).listFiles();
            if (list == null) continue;
            for (File f : list) {
                if (!f.isFile() || f.getName().startsWith(".")) continue;
                privateBox.addView(privateRow(f, dir));
                count++;
            }
        }
        if (count == 0) privateBox.addView(plain(getString(R.string.export_none_private)));

        exportedBox.removeAllViews();
        List<ExportStore.Entry> log = ExportStore.load(this);
        if (log.isEmpty()) exportedBox.addView(plain(getString(R.string.export_none_exported)));
        for (ExportStore.Entry e : log) exportedBox.addView(exportedRow(e));
    }

    private TextView plain(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    private View privateRow(File f, String dir) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(0, dp(8), 0, dp(8));
        r.addView(plain(getString(R.string.row_info, f.getName(),
                Formatter.formatShortFileSize(this, f.length()), folderLabel(dir))));
        LinearLayout bs = new LinearLayout(this);
        bs.setOrientation(LinearLayout.HORIZONTAL);
        bs.setGravity(Gravity.START);
        final boolean toDl = toDownloads();
        Button dl = btn(R.string.btn_export_file, v -> confirm(
                getString(R.string.confirm_export,
                        getString(toDl ? R.string.dest_downloads : R.string.dest_folder)),
                () -> startExport(f, toDl)));
        Button del = btn(R.string.btn_delete, v -> confirm(
                getString(R.string.confirm_delete_private), () -> {
                    //noinspection ResultOfMethodCallIgnored
                    f.delete();
                    refresh();
                }));
        for (Button x : new Button[]{dl, del}) {
            bs.addView(x, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        }
        r.addView(bs);
        return r;
    }

    private View exportedRow(ExportStore.Entry e) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(0, dp(8), 0, dp(8));
        r.addView(plain(getString(R.string.exported_info, e.name, destLabel(e.kind),
                DateFormat.getDateTimeInstance().format(new Date(e.time)))));
        r.addView(btn(R.string.btn_delete_exported, v -> confirm(
                getString(R.string.confirm_delete_exported, destLabel(e.kind)),
                () -> deleteExported(e))));
        return r;
    }

    // ------------------------------------------------------------------ exportar

    private void startExport(File f, boolean downloads) {
        if (busy) return;
        if (downloads) {
            if (Build.VERSION.SDK_INT < 29
                    && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                pendingFile = f;
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_PERM);
                return;
            }
            runExport(f, true, null);
        } else {
            Uri tree = savedTree();
            if (tree == null) {
                pendingFile = f;
                status(getString(R.string.pick_card_hint));
                launchTreePicker();
                return;
            }
            runExport(f, false, tree);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        File f = pendingFile;
        pendingFile = null;
        if (code == REQ_PERM) {
            if (f != null && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
                runExport(f, true, null);
            } else {
                status(getString(R.string.err_perm_storage));
            }
        }
    }

    private void launchTreePicker() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(i, REQ_TREE);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_TREE) return;
        File f = pendingFile;
        pendingFile = null;
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri tree = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(tree,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        } catch (SecurityException e) {
            Log.w(TAG, "E_TREE");
        }
        ExportStore.setTree(this, tree.toString());
        if (f != null) runExport(f, false, tree);
        else status(getString(R.string.folder_saved));
    }

    private Uri savedTree() {
        String s = ExportStore.getTree(this);
        if (s == null) return null;
        Uri u = Uri.parse(s);
        for (UriPermission p : getContentResolver().getPersistedUriPermissions()) {
            if (p.getUri().equals(u) && p.isWritePermission()) return u;
        }
        return null;
    }

    private void runExport(File src, boolean downloads, Uri tree) {
        setBusy(true);
        status("…");
        exec.execute(() -> {
            String msg;
            try {
                ExportStore.Entry e = downloads ? exportDownloads(src) : exportTree(src, tree);
                ExportStore.add(this, e);
                msg = getString(R.string.exp_ok, destLabel(e.kind), e.name);
            } catch (SpaceException e) {
                msg = getString(R.string.err_space_dest);
            } catch (Exception e) {
                Log.w(TAG, "E_EXPORT");
                msg = getString(R.string.exp_err);
            }
            final String m = msg;
            ui.post(() -> {
                setBusy(false);
                status(m);
                refresh();
            });
        });
    }

    private static String mimeOf(String name) {
        int dot = name.lastIndexOf('.');
        if (dot >= 0) {
            String m = MimeTypeMap.getSingleton()
                    .getMimeTypeFromExtension(name.substring(dot + 1).toLowerCase());
            if (m != null) return m;
        }
        return "application/octet-stream";
    }

    private static void copy(File src, OutputStream os) throws IOException {
        try (InputStream in = new FileInputStream(src)) {
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
            os.flush();
        }
    }

    @SuppressWarnings("deprecation")
    private ExportStore.Entry exportDownloads(File src) throws Exception {
        File pub = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        if (pub.exists() && !VaultStorage.hasSpace(pub, src.length() + 1024L * 1024)) {
            throw new SpaceException();
        }
        String name = src.getName();
        ContentResolver cr = getContentResolver();
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mimeOf(name));
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/CifraCaja");
            cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri u = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (u == null) throw new IOException();
            boolean ok = false;
            try {
                try (OutputStream os = cr.openOutputStream(u)) {
                    if (os == null) throw new IOException();
                    copy(src, os);
                }
                ContentValues done = new ContentValues();
                done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                cr.update(u, done, null, null);
                ok = true;
            } finally {
                if (!ok) cr.delete(u, null, null);
            }
            return new ExportStore.Entry(name, u.toString(), ExportStore.KIND_MEDIASTORE, System.currentTimeMillis());
        }
        File dir = new File(pub, "CifraCaja");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        File dst = VaultStorage.unique(dir, name);
        boolean ok = false;
        try {
            try (OutputStream os = new java.io.FileOutputStream(dst)) {
                copy(src, os);
            }
            ok = true;
        } finally {
            if (!ok) //noinspection ResultOfMethodCallIgnored
                dst.delete();
        }
        return new ExportStore.Entry(dst.getName(), Uri.fromFile(dst).toString(),
                ExportStore.KIND_FILE, System.currentTimeMillis());
    }

    private ExportStore.Entry exportTree(File src, Uri tree) throws Exception {
        ContentResolver cr = getContentResolver();
        Uri parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree));
        Uri dst = DocumentsContract.createDocument(cr, parent, mimeOf(src.getName()), src.getName());
        if (dst == null) throw new IOException();
        boolean ok = false;
        try {
            try (OutputStream os = cr.openOutputStream(dst)) {
                if (os == null) throw new IOException();
                copy(src, os);
            }
            ok = true;
        } finally {
            if (!ok) {
                try {
                    DocumentsContract.deleteDocument(cr, dst);
                } catch (Exception ignored) {
                    // sin accion: el usuario puede borrar el parcial desde Archivos
                }
            }
        }
        return new ExportStore.Entry(src.getName(), dst.toString(), ExportStore.KIND_SAF, System.currentTimeMillis());
    }

    // ------------------------------------------------------------------ borrar exportados

    private void deleteExported(ExportStore.Entry e) {
        if (busy) return;
        setBusy(true);
        exec.execute(() -> {
            String msg;
            try {
                boolean gone = deleteEntry(e);
                ExportStore.remove(this, e.uri);
                msg = getString(gone ? R.string.del_ok : R.string.del_gone);
            } catch (Exception ex) {
                Log.w(TAG, "E_DELETE");
                msg = getString(R.string.del_fail);
            }
            final String m = msg;
            ui.post(() -> {
                setBusy(false);
                status(m);
                refresh();
            });
        });
    }

    /** true = se borro ahora; false = ya no existia. Lanza excepcion si no se pudo borrar. */
    private boolean deleteEntry(ExportStore.Entry e) throws Exception {
        ContentResolver cr = getContentResolver();
        Uri u = Uri.parse(e.uri);
        switch (e.kind) {
            case ExportStore.KIND_MEDIASTORE:
                return cr.delete(u, null, null) > 0;
            case ExportStore.KIND_FILE: {
                File f = new File(u.getPath());
                if (!f.exists()) return false;
                if (!f.delete()) throw new IOException();
                return true;
            }
            default:
                try {
                    if (!DocumentsContract.deleteDocument(cr, u)) throw new IOException();
                    return true;
                } catch (FileNotFoundException nf) {
                    return false;
                }
        }
    }
}
