package mx.cifracaja.app;

import android.content.Context;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.MGF1ParameterSpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.OAEPParameterSpec;
import javax.crypto.spec.PSource;
import mx.cifracaja.app.crypto.CryptoException;
import mx.cifracaja.app.crypto.PackageCrypto;

/** Envoltura de llaves (RSA-OAEP) y firmas (RSA SHA-256) con la llave privada del Keystore. */
final class AsymCrypto {
    private AsymCrypto() {}

    private static final String OAEP = "RSA/ECB/OAEPWithSHA-256AndMGF1Padding";

    static byte[] idOf(byte[] der) throws GeneralSecurityException {
        return Arrays.copyOf(MessageDigest.getInstance("SHA-256").digest(der), 8);
    }

    static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x & 0xFF));
        return sb.toString();
    }

    /** XXXX-XXXX-XXXX-XXXX a partir del identificador de 8 bytes. */
    static String fingerprintOfId(byte[] id) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < id.length; i++) {
            if (i > 0 && i % 2 == 0) sb.append('-');
            sb.append(String.format("%02X", id[i] & 0xFF));
        }
        return sb.toString();
    }

    static String fingerprintOf(byte[] der) throws GeneralSecurityException {
        return fingerprintOfId(idOf(der));
    }

    /** Reconstruye la llave publica con el proveedor por defecto (evita objetos atados al Keystore). */
    static PublicKey parsePublic(byte[] der) throws GeneralSecurityException {
        return KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(der));
    }

    static PackageCrypto.KeyWrapper wrapperFor(byte[] der) throws GeneralSecurityException {
        final PublicKey pk = parsePublic(der);
        final byte[] id = idOf(der);
        return new PackageCrypto.KeyWrapper() {
            @Override public byte[] recipientId() { return id; }
            @Override public byte[] wrap(byte[] secret) throws Exception {
                Cipher c = Cipher.getInstance(OAEP);
                c.init(Cipher.ENCRYPT_MODE, pk);
                return c.doFinal(secret);
            }
        };
    }

    static PackageCrypto.KeyUnwrapper unwrapper() throws Exception {
        final byte[] ownId = idOf(AsymKeys.publicDer());
        return new PackageCrypto.KeyUnwrapper() {
            @Override public boolean isRecipient(byte[] rid) { return Arrays.equals(rid, ownId); }
            @Override public byte[] unwrap(byte[] wrapped) throws Exception {
                PrivateKey pk = AsymKeys.privateKey(); // nunca sale del Keystore
                Cipher c = Cipher.getInstance(OAEP);
                c.init(Cipher.DECRYPT_MODE, pk, new OAEPParameterSpec("SHA-256", "MGF1",
                        MGF1ParameterSpec.SHA1, PSource.PSpecified.DEFAULT));
                return c.doFinal(wrapped);
            }
        };
    }

    static PackageCrypto.Signer signer() throws Exception {
        final byte[] ownId = idOf(AsymKeys.publicDer());
        return new PackageCrypto.Signer() {
            @Override public byte[] signerId() { return ownId; }
            @Override public byte[] sign(byte[] message) throws Exception {
                Signature s = Signature.getInstance("SHA256withRSA");
                s.initSign(AsymKeys.privateKey());
                s.update(message);
                return s.sign();
            }
        };
    }

    /** Verifica con tu propia llave publica y con las de tus contactos. */
    static PackageCrypto.SigVerifier verifier(final Context ctx) {
        return new PackageCrypto.SigVerifier() {
            @Override
            public PackageCrypto.SigStatus verify(byte[] signerId, byte[] message, byte[] signature)
                    throws CryptoException {
                try {
                    List<byte[]> keys = new ArrayList<>();
                    if (AsymKeys.exists()) keys.add(AsymKeys.publicDer());
                    for (Contacts.Contact c : Contacts.list(ctx)) keys.add(c.der);
                    for (byte[] der : keys) {
                        if (!Arrays.equals(signerId, idOf(der))) continue;
                        Signature s = Signature.getInstance("SHA256withRSA");
                        s.initVerify(parsePublic(der));
                        s.update(message);
                        if (!s.verify(signature)) throw new CryptoException(CryptoException.SIG);
                        return PackageCrypto.SigStatus.VALID;
                    }
                } catch (CryptoException e) {
                    throw e;
                } catch (Exception e) {
                    throw new CryptoException(CryptoException.SIG, e);
                }
                return PackageCrypto.SigStatus.UNKNOWN_SIGNER;
            }
        };
    }
}
