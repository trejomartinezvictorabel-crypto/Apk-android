package mx.cifracaja.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.SystemClock;
import java.security.MessageDigest;
import mx.cifracaja.app.crypto.PinHasher;
import mx.cifracaja.app.crypto.Wipe;

/**
 * Bloqueo con PIN. El PIN nunca se guarda: solo un verificador = HMAC con clave del Keystore sobre
 * PBKDF2(PIN, sal). Sin el Keystore de este equipo, el verificador no se puede atacar por fuerza
 * bruta fuera del telefono. Los intentos fallidos aplican esperas crecientes.
 */
final class PinStore {
    private PinStore() {}

    enum Result { OK, WRONG, WAIT }

    static final long[] TIMEOUTS = {15_000L, 30_000L, 60_000L, 300_000L, 900_000L};
    private static final int DEFAULT_TIMEOUT_INDEX = 2; // 1 minuto
    private static final int ITER = 100_000;
    private static final long[] WAITS = {30_000L, 60_000L, 300_000L, 900_000L, 3_600_000L};
    static final int ATTEMPTS_PER_ROUND = 5;

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("pin_lock", Context.MODE_PRIVATE);
    }

    static boolean isEnabled(Context c) {
        SharedPreferences p = prefs(c);
        return p.getBoolean("on", false) && p.contains("v");
    }

    static int length(Context c) {
        return prefs(c).getInt("len", 0);
    }

    static int timeoutIndex(Context c) {
        int i = prefs(c).getInt("ti", DEFAULT_TIMEOUT_INDEX);
        return i < 0 || i >= TIMEOUTS.length ? DEFAULT_TIMEOUT_INDEX : i;
    }

    static long timeoutMs(Context c) {
        return TIMEOUTS[timeoutIndex(c)];
    }

    static void setTimeoutIndex(Context c, int i) {
        prefs(c).edit().putInt("ti", i).apply();
    }

    private static String verifierOf(byte[] derived) {
        String mac = StateMac.sign(derived);
        return mac != null ? "k:" + mac : "p:" + AsymCrypto.hex(derived);
    }

    /** Guarda (o reemplaza) el PIN y activa el bloqueo. Lento (PBKDF2): llamar fuera del hilo principal. */
    static void setPin(Context c, char[] pin) throws Exception {
        byte[] salt = PinHasher.newSalt();
        byte[] derived = PinHasher.derive(pin, salt, ITER);
        try {
            prefs(c).edit()
                    .putString("salt", AsymCrypto.hex(salt))
                    .putString("v", verifierOf(derived))
                    .putInt("len", pin.length)
                    .putBoolean("on", true)
                    .putInt("fails", 0)
                    .putLong("delay", 0)
                    .apply();
        } finally {
            Wipe.bytes(derived);
        }
    }

    static void disable(Context c) {
        int ti = timeoutIndex(c);
        prefs(c).edit().clear().putInt("ti", ti).apply();
    }

    /** Milisegundos que faltan de espera por intentos fallidos (0 si no hay espera). */
    static long remainingWaitMs(Context c) {
        SharedPreferences p = prefs(c);
        long delay = p.getLong("delay", 0);
        if (delay <= 0) return 0;
        long lastFail = p.getLong("lastfail", 0);
        long now = SystemClock.elapsedRealtime();
        if (now < lastFail) return delay; // el telefono se reinicio: la espera comienza de nuevo
        return Math.max(0, delay - (now - lastFail));
    }

    static int attemptsLeftInRound(Context c) {
        return ATTEMPTS_PER_ROUND - (prefs(c).getInt("fails", 0) % ATTEMPTS_PER_ROUND);
    }

    /** Verifica el PIN (lento): llamar fuera del hilo principal. */
    static synchronized Result verify(Context c, char[] pin) {
        if (remainingWaitMs(c) > 0) return Result.WAIT;
        SharedPreferences p = prefs(c);
        boolean ok = false;
        byte[] derived = null;
        try {
            byte[] salt = hexToBytes(p.getString("salt", ""));
            derived = PinHasher.derive(pin, salt, ITER);
            ok = MessageDigest.isEqual(verifierOf(derived).getBytes(), p.getString("v", "").getBytes());
        } catch (Exception e) {
            ok = false;
        } finally {
            Wipe.bytes(derived);
        }
        if (ok) {
            p.edit().putInt("fails", 0).putLong("delay", 0).apply();
            return Result.OK;
        }
        int fails = p.getInt("fails", 0) + 1;
        long delay = 0;
        if (fails % ATTEMPTS_PER_ROUND == 0) {
            delay = WAITS[Math.min(fails / ATTEMPTS_PER_ROUND - 1, WAITS.length - 1)];
        }
        p.edit().putInt("fails", fails).putLong("delay", delay)
                .putLong("lastfail", SystemClock.elapsedRealtime()).apply();
        return Result.WRONG;
    }

    private static byte[] hexToBytes(String h) {
        byte[] b = new byte[h.length() / 2];
        for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(h.substring(2 * i, 2 * i + 2), 16);
        return b;
    }
}
