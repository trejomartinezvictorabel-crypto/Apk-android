package mx.cifracaja.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** Registro local de lo exportado por la app (para poder borrarlo despues). Sin secretos. */
final class ExportStore {
    private ExportStore() {}

    static final String KIND_MEDIASTORE = "MS";
    static final String KIND_FILE = "FILE";
    static final String KIND_SAF = "SAF";

    static final class Entry {
        final String name;
        final String uri;
        final String kind;
        final long time;

        Entry(String name, String uri, String kind, long time) {
            this.name = name;
            this.uri = uri;
            this.kind = kind;
            this.time = time;
        }
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("export_log", Context.MODE_PRIVATE);
    }

    static synchronized List<Entry> load(Context c) {
        List<Entry> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs(c).getString("entries", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new Entry(o.getString("n"), o.getString("u"), o.getString("k"), o.getLong("t")));
            }
        } catch (JSONException ignored) {
            // registro danado: se trata como vacio
        }
        return out;
    }

    private static void save(Context c, List<Entry> list) {
        JSONArray a = new JSONArray();
        try {
            for (Entry e : list) {
                JSONObject o = new JSONObject();
                o.put("n", e.name);
                o.put("u", e.uri);
                o.put("k", e.kind);
                o.put("t", e.time);
                a.put(o);
            }
        } catch (JSONException ignored) {
            return;
        }
        prefs(c).edit().putString("entries", a.toString()).apply();
    }

    static synchronized void add(Context c, Entry e) {
        List<Entry> l = load(c);
        l.add(e);
        save(c, l);
    }

    static synchronized void remove(Context c, String uri) {
        List<Entry> l = load(c);
        for (int i = l.size() - 1; i >= 0; i--) if (l.get(i).uri.equals(uri)) l.remove(i);
        save(c, l);
    }

    static String getDest(Context c) {
        return prefs(c).getString("dest", "downloads");
    }

    static void setDest(Context c, String dest) {
        prefs(c).edit().putString("dest", dest).apply();
    }

    static String getTree(Context c) {
        return prefs(c).getString("tree", null);
    }

    static void setTree(Context c, String uri) {
        prefs(c).edit().putString("tree", uri).apply();
    }
}
