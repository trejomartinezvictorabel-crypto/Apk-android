package mx.cifracaja.app;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.StatFs;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.IOException;

/** Almacenamiento privado de la app (no visible en galeria, sin respaldo). */
final class VaultStorage {
    private VaultStorage() {}

    static final class FileInfo {
        final String name;
        final long size;   // -1 si se desconoce
        final String type;

        FileInfo(String name, long size, String type) {
            this.name = name;
            this.size = size;
            this.type = type;
        }
    }

    static File dir(Context c, String sub) {
        File root = new File(c.getFilesDir(), "vault");
        File d = new File(root, sub);
        //noinspection ResultOfMethodCallIgnored
        d.mkdirs();
        File nomedia = new File(root, ".nomedia");
        if (!nomedia.exists()) {
            try {
                //noinspection ResultOfMethodCallIgnored
                nomedia.createNewFile();
            } catch (IOException ignored) {
                // no critico: el directorio interno ya no es escaneado por la galeria
            }
        }
        return d;
    }

    static boolean hasSpace(File dir, long needed) {
        try {
            return new StatFs(dir.getAbsolutePath()).getAvailableBytes() > needed;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    static FileInfo query(ContentResolver cr, Uri uri) {
        String name = null;
        long size = -1;
        try (Cursor cur = cr.query(uri, null, null, null, null)) {
            if (cur != null && cur.moveToFirst()) {
                int n = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                int s = cur.getColumnIndex(OpenableColumns.SIZE);
                if (n >= 0 && !cur.isNull(n)) name = cur.getString(n);
                if (s >= 0 && !cur.isNull(s)) size = cur.getLong(s);
            }
        } catch (RuntimeException ignored) {
            // se usan valores por defecto
        }
        return new FileInfo(safeName(name), size, cr.getType(uri));
    }

    /** Nombre seguro: sin rutas, sin caracteres raros, sin punto inicial, maximo 100. */
    static String safeName(String raw) {
        if (raw == null) return "archivo";
        String n = raw;
        int i = Math.max(n.lastIndexOf('/'), n.lastIndexOf('\\'));
        if (i >= 0) n = n.substring(i + 1);
        n = n.replaceAll("[^\\p{L}\\p{N} ._()\\-]", "_");
        while (n.startsWith(".")) n = n.substring(1);
        if (n.length() > 100) n = n.substring(n.length() - 100);
        n = n.trim();
        return n.isEmpty() ? "archivo" : n;
    }

    static File unique(File dir, String name) {
        File f = new File(dir, name);
        if (!f.exists()) return f;
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name;
        String ext = dot > 0 ? name.substring(dot) : "";
        int k = 1;
        while (f.exists()) f = new File(dir, base + " (" + (k++) + ")" + ext);
        return f;
    }

    /** Borra descifrados y temporales (los paquetes ya cifrados se conservan). */
    static void wipeTemp(Context c) {
        deleteContents(dir(c, "dec"));
        deleteContents(dir(c, "tmp"));
        deleteContents(dir(c, "capture"));
        deleteContents(dir(c, "inbox"));
        deleteContents(c.getCacheDir());
    }

    private static void deleteContents(File d) {
        File[] list = d == null ? null : d.listFiles();
        if (list == null) return;
        for (File f : list) {
            if (f.isDirectory()) deleteContents(f);
            //noinspection ResultOfMethodCallIgnored
            f.delete();
        }
    }
}
