package mx.cifracaja.app.crypto;

/** Error criptografico. Solo lleva un codigo tecnico, nunca datos sensibles. */
public final class CryptoException extends Exception {
    public static final String FORMAT = "E_FORMAT";     // no es un paquete de esta app
    public static final String KEY_OR_HEADER = "E_KEY"; // clave incorrecta o cabecera alterada
    public static final String AUTH = "E_AUTH";         // un bloque fue alterado
    public static final String TRUNC = "E_TRUNC";       // paquete truncado o con datos extra
    public static final String EXPIRED = "E_EXPIRED";   // paquete caducado
    public static final String CANCEL = "E_CANCEL";     // cancelado por el usuario
    public static final String IO = "E_IO";             // error de lectura/escritura
    public static final String PARAM = "E_PARAM";       // parametros invalidos
    public static final String USED = "E_USED";         // paquete de uso unico ya consumido
    public static final String CLOCK = "E_CLOCK";       // reloj del sistema retrocedido
    public static final String STATE = "E_STATE";       // registro local alterado o ilegible
    public static final String SIG = "E_SIG";           // firma digital invalida
    public static final String RECIPIENT = "E_RECIPIENT"; // paquete cifrado para otra llave
    public static final String NEED_KEY = "E_NEEDKEY";  // falta la clave secreta

    public final String code;

    public CryptoException(String code) {
        super(code);
        this.code = code;
    }

    public CryptoException(String code, Throwable cause) {
        super(code, cause);
        this.code = code;
    }
}
