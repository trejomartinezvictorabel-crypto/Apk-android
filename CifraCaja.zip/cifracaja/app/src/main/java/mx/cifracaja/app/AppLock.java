package mx.cifracaja.app;

import android.content.Context;
import android.os.SystemClock;

/**
 * Estado del bloqueo en memoria del proceso: si el sistema cierra la app, al volver pide el PIN.
 * Mide la inactividad con elapsedRealtime (no depende del reloj del sistema).
 */
final class AppLock {
    private AppLock() {}

    private static boolean unlocked;
    private static long lastActive;

    static synchronized boolean needsUnlock(Context c) {
        if (!PinStore.isEnabled(c)) return false;
        if (!unlocked) return true;
        if (SystemClock.elapsedRealtime() - lastActive >= PinStore.timeoutMs(c)) {
            unlocked = false;
            return true;
        }
        return false;
    }

    /** Milisegundos que faltan para bloquear, o -1 si el bloqueo no esta activo. */
    static synchronized long remainingMs(Context c) {
        if (!PinStore.isEnabled(c) || !unlocked) return -1;
        return Math.max(0, PinStore.timeoutMs(c) - (SystemClock.elapsedRealtime() - lastActive));
    }

    static synchronized void touch() {
        lastActive = SystemClock.elapsedRealtime();
    }

    static synchronized void unlock() {
        unlocked = true;
        touch();
    }

    static synchronized void lockNow() {
        unlocked = false;
    }
}
