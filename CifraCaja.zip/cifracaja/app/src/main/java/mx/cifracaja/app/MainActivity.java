package mx.cifracaja.app;

import android.Manifest;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.widget.AdapterView;
import android.widget.CheckBox;
import java.util.ArrayList;
import java.util.Calendar;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.media.MediaRecorder;
import android.provider.MediaStore;
import android.widget.ImageView;
import androidx.core.content.FileProvider;
import java.io.IOException;
import java.util.List;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.InputType;
import android.text.format.Formatter;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import mx.cifracaja.app.crypto.CryptoException;
import mx.cifracaja.app.crypto.KeyFingerprint;
import mx.cifracaja.app.crypto.PackageCrypto;
import mx.cifracaja.app.crypto.PackageMeta;
import mx.cifracaja.app.crypto.Wipe;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Pantalla principal: cifrar/descifrar texto y archivos, huella, cancelar y modo panico. */
public class MainActivity extends BaseActivity {
    private static final int REQ_PICK = 1001;
    private static final int REQ_PHOTO = 1002;
    private static final int REQ_VIDEO = 1003;
    private static final int REQ_PERM_AUDIO = 2001;
    private static final int REQ_PERM_DICTATE = 2002;
    private static final String PREFIX = "CJA1:";
    private static final long AUTO_CLEAR_MS = 60_000L;
    // sin vencimiento, 15 min, 1 h, 24 h, 7 dias, personalizado (-1)
    private static final int[] EXPIRY_MINUTES = {0, 15, 60, 1440, 10080, -1};
    private static final String TAG = "CJA";

    private interface Job { String run(char[] key) throws Exception; }

    private static final class SpaceException extends Exception {}

    private EditText keyField, msgField;
    private TextView fpView, resultView, fileInfoView, statusView;
    private Spinner expirySpinner;
    private CheckBox cbSingleUse, cbSign;
    private LinearLayout asymBox;
    private Spinner modeSpinner, contactSpinner;
    private List<Contacts.Contact> contactList = new ArrayList<>();

    /** Eleccion de cifrado: vencimiento, uso unico, contacto destinatario (o null) y firma. */
    private static final class Enc {
        final long exp;
        final boolean once;
        final String contactId;
        final boolean sign;

        Enc(long exp, boolean once, String contactId, boolean sign) {
            this.exp = exp;
            this.once = once;
            this.contactId = contactId;
            this.sign = sign;
        }

        boolean hybrid() {
            return contactId != null;
        }
    }
    private TextView customExpiryView;
    private long customExpiry;      // epoch UTC en ms elegido por el usuario
    private int lastExpiryPos;
    private String appliedLang;
    private ProgressBar progress;
    private Button btnFp, btnCopy, btnShare, btnPick, btnCancel, btnProtect, btnOpen, btnMore;
    private LinearLayout advancedBox;
    private CheckBox cbShow;
    private boolean lastInputFile;   // lo ultimo que eligio el usuario: archivo (true) o texto (false)
    private int shareKind;           // 0 nada, 1 texto protegido, 2 archivo protegido
    private File shareFile;
    private Button btnDictate, btnModels;
    private final VoskDictation dictation = new VoskDictation();
    private boolean dictating;
    private Button btnPhoto, btnVideo, btnAudio, btnExport, btnPrivacy;
    private File pickedFile;       // captura propia (se borra tras cifrarla)
    private File pendingCapture;
    private File recordingFile;
    private MediaRecorder recorder;

    private Uri pickedUri;
    private VaultStorage.FileInfo pickedInfo;
    private boolean busy;
    private long stoppedAt;

    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final AtomicBoolean cancelFlag = new AtomicBoolean(false);

    // ------------------------------------------------------------------ ciclo de vida

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE);
        appliedLang = LocaleHelper.saved(this);
        buildUi();
        setBusy(false);
    }

    @Override
    protected void onStop() {
        super.onStop();
        stoppedAt = SystemClock.elapsedRealtime();
        if (recorder != null) stopRecording(true);
        stopDictation(true);
        dictation.release(); // libera microfono, SpeechService y modelo de la RAM
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (stoppedAt > 0 && !busy
                && SystemClock.elapsedRealtime() - stoppedAt > AUTO_CLEAR_MS) {
            clearSensitiveViews();
            status(getString(R.string.auto_cleared));
        }
        stoppedAt = 0;
        // registra la hora observada (si el reloj es coherente) para la deteccion de retroceso
        exec.execute(() -> {
            try {
                LocalState.observeClock(getApplicationContext());
            } catch (CryptoException e) {
                Log.w(TAG, e.code);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!LocaleHelper.saved(this).equals(appliedLang)) recreate(); // idioma cambiado en Configuracion
        refreshAsymUi();
    }

    @Override
    protected void onDestroy() {
        cancelFlag.set(true);
        stopRecording(false);
        stopDictation(false);
        dictation.release();
        exec.shutdownNow();
        super.onDestroy();
    }

    // ------------------------------------------------------------------ interfaz

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView label(int res, boolean bold) {
        TextView t = new TextView(this);
        t.setText(res);
        t.setTextSize(bold ? 17 : 14);
        if (bold) t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
        t.setPadding(0, dp(bold ? 16 : 6), 0, dp(4));
        return t;
    }

    private Button button(int res, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(res);
        b.setAllCaps(false);
        b.setMinHeight(dp(56));
        b.setOnClickListener(l);
        return b;
    }

    private Button bigButton(int res, int color, View.OnClickListener l) {
        Button b = button(res, l);
        b.setTextSize(20);
        b.setTypeface(b.getTypeface(), android.graphics.Typeface.BOLD);
        b.setMinHeight(dp(76));
        b.setTextColor(0xFFFFFFFF);
        b.setBackgroundColor(color);
        return b;
    }

    private LinearLayout row(Button... bs) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        for (Button b : bs) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(dp(3), dp(3), dp(3), dp(3));
            r.addView(b, lp);
        }
        return r;
    }

    private LinearLayout card(int titleRes) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackgroundColor(0xFF161616);
        c.setPadding(dp(14), dp(12), dp(14), dp(14));
        TextView t = new TextView(this);
        t.setText(titleRes);
        t.setTextSize(20);
        t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
        t.setPadding(0, 0, 0, dp(8));
        c.addView(t);
        return c;
    }

    private void addBlock(LinearLayout root, View v) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(14);
        root.addView(v, lp);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(14), dp(14), dp(24));

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_launcher_foreground);
        head.addView(logo, new LinearLayout.LayoutParams(dp(72), dp(72)));
        TextView title = label(R.string.title, true);
        title.setTextSize(26);
        head.addView(title);
        root.addView(head);
        root.addView(label(R.string.home_tagline, false));
        root.addView(button(R.string.btn_help,
                v -> startActivity(TutorialActivity.intent(this, TutorialActivity.APP))));

        // 1. Contrasena
        LinearLayout c1 = card(R.string.card_pass);
        keyField = new EditText(this);
        keyField.setHint(R.string.hint_key);
        keyField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        keyField.setImeOptions(EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING
                | EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        c1.addView(keyField);
        cbShow = new CheckBox(this);
        cbShow.setText(R.string.cb_show_pass);
        cbShow.setOnCheckedChangeListener((cb, on) -> {
            int sel = keyField.getSelectionStart();
            keyField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                    | (on ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : InputType.TYPE_TEXT_VARIATION_PASSWORD));
            if (sel >= 0) keyField.setSelection(Math.min(sel, keyField.length()));
        });
        c1.addView(cbShow);
        c1.addView(button(R.string.btn_suggest, v -> suggestPassword()));
        c1.addView(label(R.string.pass_note, false));
        addBlock(root, c1);

        // 2. Que proteger
        LinearLayout c2 = card(R.string.card_what);
        msgField = new EditText(this);
        msgField.setHint(R.string.hint_msg_simple);
        msgField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        msgField.setImeOptions(EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING);
        msgField.setMinLines(4);
        msgField.setGravity(Gravity.TOP | Gravity.START);
        msgField.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence t, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence t, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable e) {
                if (e.length() > 0) lastInputFile = false; // el usuario esta escribiendo un mensaje
            }
        });
        c2.addView(msgField);
        btnDictate = button(R.string.btn_dictate, v -> toggleDictation());
        c2.addView(btnDictate);
        fileInfoView = new TextView(this);
        fileInfoView.setText(R.string.file_none);
        fileInfoView.setPadding(0, dp(8), 0, dp(4));
        c2.addView(fileInfoView);
        btnPick = button(R.string.btn_pick_file, v -> pickFile());
        btnPhoto = button(R.string.btn_capture_photo,
                v -> launchCamera(MediaStore.ACTION_IMAGE_CAPTURE, REQ_PHOTO, "foto", ".jpg"));
        btnVideo = button(R.string.btn_capture_video,
                v -> launchCamera(MediaStore.ACTION_VIDEO_CAPTURE, REQ_VIDEO, "video", ".mp4"));
        btnAudio = button(R.string.btn_audio_start, v -> toggleAudio());
        c2.addView(row(btnPick, btnPhoto));
        c2.addView(row(btnVideo, btnAudio));
        addBlock(root, c2);

        // 3. Proteger / Abrir
        LinearLayout c3 = card(R.string.card_go);
        btnProtect = bigButton(R.string.btn_protect, 0xFF1B8A3A, v -> protectClicked());
        btnOpen = bigButton(R.string.btn_open, 0xFF1F5FBF, v -> openClicked());
        c3.addView(row(btnProtect, btnOpen));
        c3.addView(label(R.string.go_hint, false));
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setIndeterminate(true);
        progress.setVisibility(View.GONE);
        c3.addView(progress);
        btnCancel = button(R.string.btn_cancel, v -> cancelFlag.set(true));
        c3.addView(btnCancel);
        statusView = new TextView(this);
        statusView.setTextSize(18);
        statusView.setPadding(0, dp(10), 0, dp(10));
        statusView.setTextIsSelectable(true);
        c3.addView(statusView);
        resultView = new TextView(this);
        resultView.setTextIsSelectable(true);
        resultView.setPadding(dp(8), dp(8), dp(8), dp(8));
        c3.addView(resultView);
        btnCopy = button(R.string.btn_copy, v -> copyResult());
        btnShare = button(R.string.btn_share, v -> shareResult());
        btnShare.setVisibility(View.GONE);
        c3.addView(row(btnCopy, btnShare));
        addBlock(root, c3);

        // Mas opciones (todo lo avanzado, oculto por defecto)
        btnMore = button(R.string.btn_more, v -> toggleAdvanced());
        addBlock(root, btnMore);
        advancedBox = new LinearLayout(this);
        advancedBox.setOrientation(LinearLayout.VERTICAL);
        advancedBox.setVisibility(View.GONE);
        advancedBox.addView(label(R.string.expiry_label, false));
        expirySpinner = new Spinner(this);
        expirySpinner.setAdapter(ArrayAdapter.createFromResource(this, R.array.expiry_options,
                android.R.layout.simple_spinner_dropdown_item));
        expirySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View v, int pos, long id) {
                boolean custom = EXPIRY_MINUTES[pos] < 0;
                customExpiryView.setVisibility(custom ? View.VISIBLE : View.GONE);
                if (custom && lastExpiryPos != pos) pickCustomExpiry();
                lastExpiryPos = pos;
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
        advancedBox.addView(expirySpinner);
        customExpiryView = new TextView(this);
        customExpiryView.setText(R.string.custom_expiry_none);
        customExpiryView.setVisibility(View.GONE);
        customExpiryView.setOnClickListener(v -> pickCustomExpiry());
        advancedBox.addView(customExpiryView);
        cbSingleUse = new CheckBox(this);
        cbSingleUse.setText(R.string.cb_single_use);
        advancedBox.addView(cbSingleUse);

        asymBox = new LinearLayout(this);
        asymBox.setOrientation(LinearLayout.VERTICAL);
        asymBox.addView(label(R.string.label_mode, false));
        modeSpinner = new Spinner(this);
        modeSpinner.setAdapter(ArrayAdapter.createFromResource(this, R.array.enc_modes,
                android.R.layout.simple_spinner_dropdown_item));
        modeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View v, int pos, long id) {
                contactSpinner.setVisibility(pos == 1 ? View.VISIBLE : View.GONE);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
        asymBox.addView(modeSpinner);
        contactSpinner = new Spinner(this);
        contactSpinner.setVisibility(View.GONE);
        asymBox.addView(contactSpinner);
        cbSign = new CheckBox(this);
        cbSign.setText(R.string.cb_sign);
        asymBox.addView(cbSign);
        asymBox.setVisibility(View.GONE);
        advancedBox.addView(asymBox);

        btnFp = button(R.string.btn_fingerprint, v -> showFingerprint());
        advancedBox.addView(btnFp);
        fpView = new TextView(this);
        fpView.setTextIsSelectable(true);
        advancedBox.addView(fpView);
        btnModels = button(R.string.btn_models, v -> startActivity(new Intent(this, ModelsActivity.class)));
        advancedBox.addView(btnModels);
        root.addView(advancedBox);

        btnExport = button(R.string.btn_export, v -> startActivity(new Intent(this, ExportActivity.class)));
        btnPrivacy = button(R.string.btn_settings, v -> startActivity(new Intent(this, SettingsActivity.class)));
        addBlock(root, row(btnExport, btnPrivacy));

        Button panic = button(R.string.btn_panic, v -> panic());
        panic.setTextColor(0xFFFF6B6B); // rojo claro: buen contraste sobre negro
        addBlock(root, panic);
        TextView made = label(R.string.footer_made, false);
        made.setGravity(Gravity.CENTER);
        root.addView(made);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
    }

    private void toggleAdvanced() {
        boolean show = advancedBox.getVisibility() != View.VISIBLE;
        advancedBox.setVisibility(show ? View.VISIBLE : View.GONE);
        btnMore.setText(show ? R.string.btn_less : R.string.btn_more);
    }

    private void setBusy(boolean b) {
        busy = b;
        progress.setVisibility(b ? View.VISIBLE : View.GONE);
        boolean idle = !b;
        btnFp.setEnabled(idle);
        btnProtect.setEnabled(idle);
        btnOpen.setEnabled(idle);
        btnPick.setEnabled(idle);
        btnCancel.setEnabled(b);
        btnPhoto.setEnabled(idle);
        btnVideo.setEnabled(idle);
        btnAudio.setEnabled(idle);
        btnExport.setEnabled(idle);
        if (b) status(getString(R.string.working));
    }

    private void status(String s) {
        statusView.setText(s);
    }

    private void showResult(String s) {
        ui.post(() -> resultView.setText(s));
    }

    // ------------------------------------------------------------------ acciones de UI

    private char[] key() {
        Editable e = keyField.getText();
        char[] c = new char[e.length()];
        e.getChars(0, c.length, c, 0);
        return c;
    }

    /** PROTEGER: elige solo entre archivo y texto segun lo ultimo que hizo el usuario. */
    private void protectClicked() {
        boolean noText = msgField.getText().toString().trim().isEmpty();
        if (pickedUri != null && (lastInputFile || noText)) {
            encryptFileClicked();
        } else if (!noText) {
            encryptTextClicked();
        } else {
            status(getString(R.string.err_nothing));
        }
    }

    /** ABRIR: si hay un texto protegido pegado lo abre; si no, abre el archivo elegido. */
    private void openClicked() {
        String t = msgField.getText().toString().replaceAll("\\s", "");
        if (t.startsWith(PREFIX)) {
            decryptTextClicked();
        } else if (pickedUri != null) {
            decryptFileClicked();
        } else {
            status(getString(R.string.err_nothing_open));
        }
    }

    private void suggestPassword() {
        final String cons = "bdfgklmnprstvz";
        final String vow = "aeiou";
        java.security.SecureRandom r = new java.security.SecureRandom();
        StringBuilder sb = new StringBuilder();
        for (int w = 0; w < 4; w++) {          // 4 palabras pronunciables: unos 64 bits de azar
            if (w > 0) sb.append('-');
            for (int i = 0; i < 5; i++) {
                String set = (i % 2 == 0) ? cons : vow;
                sb.append(set.charAt(r.nextInt(set.length())));
            }
        }
        cbShow.setChecked(true);
        keyField.setText(sb.toString());
        status(getString(R.string.pass_suggested, sb.toString()));
    }

    private void setShare(int kind, File f) {
        shareKind = kind;
        shareFile = f;
        btnShare.setVisibility(kind == 0 ? View.GONE : View.VISIBLE);
    }

    private void shareResult() {
        Intent i = new Intent(Intent.ACTION_SEND);
        if (shareKind == 1) {
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, resultView.getText().toString());
        } else if (shareKind == 2 && shareFile != null && shareFile.exists()) {
            Uri u = FileProvider.getUriForFile(this, getPackageName() + ".files", shareFile);
            i.setType("application/octet-stream");
            i.putExtra(Intent.EXTRA_STREAM, u);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } else {
            return;
        }
        startActivity(Intent.createChooser(i, getString(R.string.btn_share)));
    }

    private void showFingerprint() {
        runJob(k -> {
            String fp = KeyFingerprint.of(k);
            ui.post(() -> fpView.setText(getString(R.string.fingerprint_value, fp)));
            return "";
        });
    }

    private void encryptTextClicked() {
        String text = msgField.getText().toString();
        if (text.isEmpty()) { status(getString(R.string.err_no_text)); return; }
        final long exp = resolveExpiry();
        if (exp < 0) return;
        final Enc enc = buildEnc(exp, cbSingleUse.isChecked());
        if (enc == null) return;
        runJob(k -> doEncryptText(k, text, enc), !enc.hybrid());
    }

    private void decryptTextClicked() {
        String text = msgField.getText().toString();
        if (text.isEmpty()) { status(getString(R.string.err_no_text)); return; }
        runJob(k -> doDecryptText(k, text), false);
    }

    private void encryptFileClicked() {
        if (pickedUri == null) { status(getString(R.string.err_no_file)); return; }
        final Uri uri = pickedUri;
        final VaultStorage.FileInfo info = pickedInfo;
        final File src = pickedFile;
        final long exp = resolveExpiry();
        if (exp < 0) return;
        final Enc enc = buildEnc(exp, cbSingleUse.isChecked());
        if (enc == null) return;
        runJob(k -> doEncryptFile(k, uri, info, enc, src), !enc.hybrid());
    }

    private void decryptFileClicked() {
        if (pickedUri == null) { status(getString(R.string.err_no_file)); return; }
        final Uri uri = pickedUri;
        final VaultStorage.FileInfo info = pickedInfo;
        runJob(k -> doDecryptFile(k, uri, info), false);
    }

    private void copyResult() {
        CharSequence t = resultView.getText();
        if (t == null || t.length() == 0) return;
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("", t));
            Toast.makeText(this, R.string.copied, Toast.LENGTH_SHORT).show();
        }
    }

    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_PICK);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK && resultCode == RESULT_OK && data != null && data.getData() != null) {
            pickedFile = null;
            pickedUri = data.getData();
            pickedInfo = VaultStorage.query(getContentResolver(), pickedUri);
            showPicked();
        } else if (requestCode == REQ_PHOTO || requestCode == REQ_VIDEO) {
            File f = pendingCapture;
            pendingCapture = null;
            if (f == null) return;
            if (resultCode == RESULT_OK && f.exists() && f.length() > 0) selectCaptured(f);
            else //noinspection ResultOfMethodCallIgnored
                f.delete();
        }
    }

    private void showPicked() {
        String size = pickedInfo.size >= 0
                ? Formatter.formatShortFileSize(this, pickedInfo.size)
                : getString(R.string.file_unknown);
        String type = pickedInfo.type != null ? pickedInfo.type : getString(R.string.file_unknown);
        fileInfoView.setText(getString(R.string.file_info, pickedInfo.name, size, type));
        lastInputFile = true;
        setBusy(busy);
    }

    // ------------------------------------------------------------------ captura

    private File newCaptureFile(String prefix, String ext) {
        return new File(VaultStorage.dir(this, "capture"), prefix + "-" + System.currentTimeMillis() + ext);
    }

    private void selectCaptured(File f) {
        String n = f.getName();
        String mime = n.endsWith(".jpg") ? "image/jpeg" : n.endsWith(".mp4") ? "video/mp4" : "audio/mp4";
        pickedFile = f;
        pickedUri = FileProvider.getUriForFile(this, getPackageName() + ".files", f);
        pickedInfo = new VaultStorage.FileInfo(n, f.length(), mime);
        showPicked();
        status(getString(R.string.captured_ok, n));
    }

    private void launchCamera(String action, int req, String prefix, String ext) {
        File f = newCaptureFile(prefix, ext);
        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".files", f);
        Intent i = new Intent(action);
        i.putExtra(MediaStore.EXTRA_OUTPUT, uri);
        i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        i.setClipData(ClipData.newRawUri("", uri));
        List<ResolveInfo> apps = getPackageManager().queryIntentActivities(i, PackageManager.MATCH_DEFAULT_ONLY);
        for (ResolveInfo ri : apps) {
            grantUriPermission(ri.activityInfo.packageName, uri,
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        }
        pendingCapture = f;
        try {
            startActivityForResult(i, req);
        } catch (ActivityNotFoundException e) {
            pendingCapture = null;
            status(getString(R.string.err_no_camera));
        }
    }

    private void toggleAudio() {
        if (dictating) {
            status(getString(R.string.err_mic_busy));
            return;
        }
        if (recorder != null) {
            stopRecording(true);
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_PERM_AUDIO);
            return;
        }
        startRecording();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        boolean granted = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
        if (code == REQ_PERM_AUDIO) {
            if (granted) startRecording();
            else status(getString(R.string.err_audio_perm));
        } else if (code == REQ_PERM_DICTATE) {
            File model = VoskModelManager.active(this);
            if (granted && model != null) startDictation(model);
            else status(getString(R.string.err_dict_perm));
        }
    }

    @SuppressWarnings("deprecation")
    private void startRecording() {
        File f = newCaptureFile("audio", ".m4a");
        MediaRecorder r = Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(this) : new MediaRecorder();
        try {
            r.setAudioSource(MediaRecorder.AudioSource.MIC);
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            r.setAudioSamplingRate(32000);
            r.setAudioEncodingBitRate(64000);
            r.setOutputFile(f.getAbsolutePath());
            r.prepare();
            r.start();
            recorder = r;
            recordingFile = f;
            btnAudio.setText(R.string.btn_audio_stop);
            status(getString(R.string.recording));
        } catch (IOException | RuntimeException e) {
            Log.w(TAG, "E_AUDIO");
            r.release();
            //noinspection ResultOfMethodCallIgnored
            f.delete();
            status(getString(R.string.err_audio));
        }
    }

    /** Detiene y libera el microfono. keep=false descarta la grabacion. */
    private void stopRecording(boolean keep) {
        if (recorder == null) return;
        MediaRecorder r = recorder;
        File f = recordingFile;
        recorder = null;
        recordingFile = null;
        boolean ok = true;
        try {
            r.stop();
        } catch (RuntimeException e) {
            ok = false; // grabacion demasiado corta o interrumpida
        }
        r.release();
        btnAudio.setText(R.string.btn_audio_start);
        if (keep && ok && f != null && f.length() > 0) selectCaptured(f);
        else if (f != null) //noinspection ResultOfMethodCallIgnored
            f.delete();
    }

    // ------------------------------------------------------------------ dictado offline

    private void toggleDictation() {
        if (dictating) {
            stopDictation(true);
            status("");
            return;
        }
        if (recorder != null) {
            status(getString(R.string.err_mic_busy));
            return;
        }
        File model = VoskModelManager.active(this);
        if (model == null) {
            status(getString(R.string.err_no_model));
            startActivity(new Intent(this, ModelsActivity.class));
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_PERM_DICTATE);
            return;
        }
        startDictation(model);
    }

    private void startDictation(File model) {
        dictating = true;
        btnDictate.setText(R.string.btn_dictate_stop);
        status(getString(R.string.dict_loading));
        dictation.start(model, new VoskDictation.Callback() {
            @Override public void onReady() {
                status(getString(R.string.dict_listening));
            }
            @Override public void onPartial(String t) {
                if (!t.isEmpty()) status(getString(R.string.dict_partial, t));
            }
            @Override public void onFinal(String t) {
                insertDictated(t);
            }
            @Override public void onError(String code) {
                stopDictation(false);
                Log.w(TAG, code);
                status(getString("E_MEM".equals(code) ? R.string.err_dict_mem : R.string.err_dict));
            }
        });
    }

    private void stopDictation(boolean keepText) {
        if (!dictating) return;
        dictating = false;
        dictation.stop(keepText);
        btnDictate.setText(R.string.btn_dictate);
    }

    private void insertDictated(String t) {
        if (t == null || t.trim().isEmpty()) return;
        Editable e = msgField.getText();
        int a = msgField.getSelectionStart();
        int b = msgField.getSelectionEnd();
        if (a < 0 || b < 0) { a = e.length(); b = a; }
        int start = Math.min(a, b), end = Math.max(a, b);
        String ins = (start > 0 && !Character.isWhitespace(e.charAt(start - 1)) ? " " : "")
                + t.trim() + " ";
        e.replace(start, end, ins);
    }

    // ------------------------------------------------------------------ modo panico

    private void clearSensitiveViews() {
        keyField.setText("");
        msgField.setText("");
        resultView.setText("");
        statusView.setText("");
        cbShow.setChecked(false);
        lastInputFile = false;
        setShare(0, null);
        fpView.setText("");
        fileInfoView.setText(R.string.file_none);
        pickedUri = null;
        pickedInfo = null;
        pickedFile = null;
        setBusy(busy);
    }

    private void panic() {
        cancelFlag.set(true);
        stopRecording(false);
        stopDictation(false);
        clearSensitiveViews();
        VaultStorage.wipeTemp(this);
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                if (Build.VERSION.SDK_INT >= 28) cm.clearPrimaryClip();
                else cm.setPrimaryClip(ClipData.newPlainText("", ""));
            }
        } catch (RuntimeException e) {
            Log.w(TAG, "E_CLIP");
        }
        status(getString(R.string.panic_done));
        if (PinStore.isEnabled(this)) { // tras el panico, la app pide el PIN de inmediato
            AppLock.lockNow();
            enforceLock();
        }
    }

    // ------------------------------------------------------------------ ejecucion

    private void runJob(Job job) {
        runJob(job, true);
    }

    private void runJob(Job job, boolean requireKey) {
        if (busy) { status(getString(R.string.err_busy)); return; }
        setShare(0, null);
        final char[] k = key();
        if (requireKey && k.length < PackageCrypto.MIN_PASSPHRASE) {
            Wipe.chars(k);
            status(getString(R.string.err_key_short));
            return;
        }
        cancelFlag.set(false);
        setBusy(true);
        exec.execute(() -> {
            String msg;
            try {
                msg = job.run(k);
            } catch (CryptoException e) {
                Log.w(TAG, e.code);
                msg = errorMessage(e.code);
            } catch (SpaceException e) {
                Log.w(TAG, "E_SPACE");
                msg = getString(R.string.err_space);
            } catch (Exception e) {
                Log.w(TAG, CryptoException.IO);
                msg = errorMessage(CryptoException.IO);
            } finally {
                Wipe.chars(k);
            }
            final String m = msg;
            ui.post(() -> {
                setBusy(false);
                status(m);
            });
        });
    }

    private String errorMessage(String code) {
        switch (code) {
            case CryptoException.FORMAT: return getString(R.string.err_E_FORMAT);
            case CryptoException.KEY_OR_HEADER: return getString(R.string.err_E_KEY);
            case CryptoException.AUTH: return getString(R.string.err_E_AUTH);
            case CryptoException.TRUNC: return getString(R.string.err_E_TRUNC);
            case CryptoException.EXPIRED: return getString(R.string.err_E_EXPIRED);
            case CryptoException.CANCEL: return getString(R.string.err_E_CANCEL);
            case CryptoException.SIG: return getString(R.string.err_E_SIG);
            case CryptoException.RECIPIENT: return getString(R.string.err_E_RECIPIENT);
            case CryptoException.NEED_KEY: return getString(R.string.err_key_short);
            case CryptoException.USED: return getString(R.string.err_E_USED);
            case CryptoException.CLOCK: return getString(R.string.err_E_CLOCK);
            case CryptoException.STATE: return getString(R.string.err_E_STATE);
            case CryptoException.PARAM: return getString(R.string.err_E_PARAM);
            default: return getString(R.string.err_E_IO);
        }
    }

    /** Devuelve 0 (sin vencimiento), la marca UTC de expiracion, o -1 si la eleccion no es valida. */
    private long resolveExpiry() {
        int min = EXPIRY_MINUTES[expirySpinner.getSelectedItemPosition()];
        long now = System.currentTimeMillis();
        if (min == 0) return 0;
        if (min > 0) return now + min * 60_000L;
        if (customExpiry == 0) { status(getString(R.string.err_custom_missing)); return -1; }
        if (customExpiry < now + 60_000L) { status(getString(R.string.err_custom_past)); return -1; }
        return customExpiry;
    }

    private void pickCustomExpiry() {
        final Calendar c = Calendar.getInstance();
        c.add(Calendar.HOUR_OF_DAY, 1);
        new DatePickerDialog(this, (view, y, m, d) -> {
            Calendar sel = Calendar.getInstance();
            sel.set(y, m, d, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), 0);
            new TimePickerDialog(this, (tv, h, mi) -> {
                sel.set(Calendar.HOUR_OF_DAY, h);
                sel.set(Calendar.MINUTE, mi);
                sel.set(Calendar.SECOND, 0);
                customExpiry = sel.getTimeInMillis(); // epoch UTC
                customExpiryView.setText(getString(R.string.custom_expiry_set,
                        DateFormat.getDateTimeInstance().format(new Date(customExpiry))));
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE),
                    android.text.format.DateFormat.is24HourFormat(this)).show();
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    @Override
    protected boolean keepAlive() {
        return busy || dictating || recorder != null;
    }

    @Override
    protected void onLockTriggered() {
        stopDictation(false);
        clearSensitiveViews(); // al bloquear no queda clave, texto ni resultado en pantalla
    }

    private void refreshAsymUi() {
        boolean on = AsymKeys.enabled(this) && AsymKeys.exists();
        asymBox.setVisibility(on ? View.VISIBLE : View.GONE);
        if (!on) {
            modeSpinner.setSelection(0);
            cbSign.setChecked(false);
            return;
        }
        contactList = Contacts.list(this);
        String[] names = new String[contactList.size()];
        for (int i = 0; i < names.length; i++) {
            names[i] = contactList.get(i).name + " (" + contactList.get(i).fingerprint() + ")";
        }
        contactSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names));
        contactSpinner.setVisibility(modeSpinner.getSelectedItemPosition() == 1 ? View.VISIBLE : View.GONE);
    }

    private Enc buildEnc(long exp, boolean once) {
        boolean asym = AsymKeys.enabled(this) && AsymKeys.exists();
        String contactId = null;
        boolean sign = false;
        if (asym) {
            sign = cbSign.isChecked();
            if (modeSpinner.getSelectedItemPosition() == 1) {
                int pos = contactSpinner.getSelectedItemPosition();
                if (contactList.isEmpty() || pos < 0 || pos >= contactList.size()) {
                    status(getString(R.string.err_no_contacts));
                    return null;
                }
                contactId = contactList.get(pos).idHex;
            }
        }
        return new Enc(exp, once, contactId, sign);
    }

    private PackageCrypto.Options options(char[] k, Enc enc) throws Exception {
        PackageCrypto.Options o = new PackageCrypto.Options();
        if (enc.contactId != null) {
            Contacts.Contact c = Contacts.byIdHex(this, enc.contactId);
            if (c == null) throw new CryptoException(CryptoException.PARAM);
            o.wrapper = AsymCrypto.wrapperFor(c.der);
        } else {
            o.passphrase = k;
        }
        if (enc.sign) o.signer = AsymCrypto.signer();
        return o;
    }

    private PackageCrypto.Credentials creds(char[] k) throws Exception {
        PackageCrypto.Credentials c = new PackageCrypto.Credentials();
        c.passphrase = k;
        if (AsymKeys.enabled(this) && AsymKeys.exists()) {
            c.unwrapper = AsymCrypto.unwrapper();
            c.verifier = AsymCrypto.verifier(this);
        }
        return c;
    }

    private String encNote(Enc enc) {
        String s = policyNote(enc.exp, enc.once);
        if (enc.contactId != null) {
            Contacts.Contact c = Contacts.byIdHex(this, enc.contactId);
            if (c != null) s += "\n" + getString(R.string.policy_for_contact, c.name);
        }
        if (enc.sign) s += "\n" + getString(R.string.policy_signed);
        return s;
    }

    private String sigNote(PackageCrypto.Result r) {
        if (r == null || r.sig == PackageCrypto.SigStatus.NONE) return "";
        if (r.sig == PackageCrypto.SigStatus.VALID) {
            Contacts.Contact c = Contacts.byId(this, r.signerId);
            return "\n" + getString(R.string.sig_valid, c != null ? c.name : getString(R.string.sig_self));
        }
        return "\n" + getString(R.string.sig_unknown, AsymCrypto.fingerprintOfId(r.signerId));
    }

    private String policyNote(long exp, boolean once) {
        StringBuilder sb = new StringBuilder();
        if (exp > 0) {
            sb.append("\n").append(getString(R.string.expires_on,
                    DateFormat.getDateTimeInstance().format(new Date(exp))));
        }
        if (once) sb.append("\n").append(getString(R.string.policy_single_use));
        return sb.toString();
    }

    private String doEncryptText(char[] k, String text, Enc enc) throws Exception {
        byte[] data = text.getBytes(StandardCharsets.UTF_8);
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        try {
            PackageMeta meta = new PackageMeta(PackageMeta.MODE_TEXT, "", "", data.length, enc.exp, enc.once);
            PackageCrypto.encrypt(options(k, enc), meta, new ByteArrayInputStream(data), o, cancelFlag::get);
        } finally {
            Wipe.bytes(data);
        }
        byte[] pkg = o.toByteArray();
        showResult(PREFIX + Base64.encodeToString(pkg, Base64.NO_WRAP));
        ui.post(() -> setShare(1, null));
        return getString(R.string.ok_text_encrypted) + encNote(enc);
    }

    private String doDecryptText(char[] k, String text) throws Exception {
        String in = text.replaceAll("\\s", "");
        if (!in.startsWith(PREFIX)) throw new CryptoException(CryptoException.FORMAT);
        byte[] raw;
        try {
            raw = Base64.decode(in.substring(PREFIX.length()), Base64.NO_WRAP);
        } catch (IllegalArgumentException e) {
            throw new CryptoException(CryptoException.FORMAT);
        }
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        PackageCrypto.Result res = PackageCrypto.decryptEx(creds(k), new ByteArrayInputStream(raw), o,
                PackagePolicies.forDevice(this), cancelFlag::get);
        PackageMeta m = res.meta;
        if (m.mode != PackageMeta.MODE_TEXT) throw new CryptoException(CryptoException.FORMAT);
        byte[] pb = o.toByteArray();
        showResult(new String(pb, StandardCharsets.UTF_8));
        Wipe.bytes(pb);
        String msg = getString(R.string.ok_text_decrypted);
        if (m.expiresAt > 0) {
            msg += "\n" + getString(R.string.expires_on,
                    DateFormat.getDateTimeInstance().format(new Date(m.expiresAt)));
        }
        if (m.singleUse) msg += "\n" + getString(R.string.ok_single_consumed);
        return msg + sigNote(res);
    }

    private static long neededBytes(long size) {
        return size < 0 ? 64L * 1024 * 1024 : size + size / 100 + 1024L * 1024;
    }

    private String doEncryptFile(char[] k, Uri uri, VaultStorage.FileInfo info, Enc enc,
                                 File src) throws Exception {
        File dir = VaultStorage.dir(this, "enc");
        if (!VaultStorage.hasSpace(dir, neededBytes(info.size))) throw new SpaceException();
        File out = VaultStorage.unique(dir, info.name + ".bvl");
        String ext = info.name.contains(".") ? info.name.substring(info.name.lastIndexOf('.') + 1) : "";
        PackageMeta meta = new PackageMeta(PackageMeta.MODE_FILE, info.name, ext, info.size, enc.exp, enc.once);
        boolean ok = false;
        try {
            InputStream raw = getContentResolver().openInputStream(uri);
            if (raw == null) throw new CryptoException(CryptoException.IO);
            try (InputStream in = new BufferedInputStream(raw);
                 OutputStream os = new BufferedOutputStream(new FileOutputStream(out))) {
                PackageCrypto.encrypt(options(k, enc), meta, in, os, cancelFlag::get);
            }
            ok = true;
        } finally {
            if (!ok) //noinspection ResultOfMethodCallIgnored
                out.delete();
        }
        final File outFile = out;
        ui.post(() -> {
            resultView.setText("");
            setShare(2, outFile);
        });
        String msg = getString(R.string.ok_file_encrypted, out.getName()) + encNote(enc);
        if (src != null && src.delete()) {
            msg += "\n" + getString(R.string.ok_capture_deleted);
            ui.post(() -> {
                if (src.equals(pickedFile)) {
                    pickedFile = null;
                    pickedUri = null;
                    pickedInfo = null;
                    fileInfoView.setText(R.string.file_none);
                    setBusy(busy);
                }
            });
        }
        return msg;
    }

    private String doDecryptFile(char[] k, Uri uri, VaultStorage.FileInfo info) throws Exception {
        File dir = VaultStorage.dir(this, "dec");
        if (!VaultStorage.hasSpace(dir, neededBytes(info.size))) throw new SpaceException();
        File tmp = new File(dir, ".part-" + System.nanoTime());
        boolean ok = false;
        File fin = null;
        PackageCrypto.Result res = null;
        try {
            PackageMeta m;
            InputStream raw = getContentResolver().openInputStream(uri);
            if (raw == null) throw new CryptoException(CryptoException.IO);
            try (InputStream in = new BufferedInputStream(raw);
                 OutputStream os = new BufferedOutputStream(new FileOutputStream(tmp))) {
                res = PackageCrypto.decryptEx(creds(k), in, os, PackagePolicies.forDevice(this), cancelFlag::get);
                m = res.meta;
            }
            if (m.mode != PackageMeta.MODE_FILE) throw new CryptoException(CryptoException.FORMAT);
            fin = VaultStorage.unique(dir, VaultStorage.safeName(m.name));
            if (!tmp.renameTo(fin)) throw new CryptoException(CryptoException.IO);
            ok = true;
        } finally {
            if (!ok) {
                //noinspection ResultOfMethodCallIgnored
                tmp.delete();
            }
        }
        String msgOk = getString(R.string.ok_file_decrypted, fin.getName());
        return msgOk + sigNote(res);
    }
}
