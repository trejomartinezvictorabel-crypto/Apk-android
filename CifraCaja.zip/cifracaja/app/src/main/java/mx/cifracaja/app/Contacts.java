package mx.cifracaja.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;
import java.security.PublicKey;
import java.security.interfaces.RSAPublicKey;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import mx.cifracaja.app.crypto.CryptoException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** Contactos: nombre + llave publica RSA importada. Solo se guardan en este telefono. */
final class Contacts {
    private Contacts() {}

    static final String DUPLICATE = "E_DUP";

    static final class Contact {
        final String name;
        final byte[] der;
        final String idHex;

        Contact(String name, byte[] der, String idHex) {
            this.name = name;
            this.der = der;
            this.idHex = idHex;
        }

        String fingerprint() {
            try {
                return AsymCrypto.fingerprintOf(der);
            } catch (Exception e) {
                return "?";
            }
        }
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("contacts", Context.MODE_PRIVATE);
    }

    static synchronized List<Contact> list(Context c) {
        List<Contact> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs(c).getString("list", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                byte[] der = Base64.decode(o.getString("k"), Base64.NO_WRAP);
                out.add(new Contact(o.getString("n"), der, AsymCrypto.hex(AsymCrypto.idOf(der))));
            }
        } catch (Exception ignored) {
            // lista danada: se trata como vacia
        }
        return out;
    }

    private static void save(Context c, List<Contact> l) {
        JSONArray a = new JSONArray();
        try {
            for (Contact k : l) {
                JSONObject o = new JSONObject();
                o.put("n", k.name);
                o.put("k", Base64.encodeToString(k.der, Base64.NO_WRAP));
                a.put(o);
            }
        } catch (JSONException e) {
            return;
        }
        prefs(c).edit().putString("list", a.toString()).apply();
    }

    /** Valida y agrega "CJAPUB1:..." (RSA de 2048 a 8192 bits). */
    static synchronized Contact add(Context c, String name, String text) throws CryptoException {
        String n = name == null ? "" : name.trim();
        if (n.isEmpty() || n.length() > 40) throw new CryptoException(CryptoException.PARAM);
        String t = text == null ? "" : text.replaceAll("\\s", "");
        if (!t.startsWith(AsymKeys.PUBLIC_PREFIX)) throw new CryptoException(CryptoException.FORMAT);
        try {
            byte[] der = Base64.decode(t.substring(AsymKeys.PUBLIC_PREFIX.length()), Base64.NO_WRAP);
            PublicKey pk = AsymCrypto.parsePublic(der);
            if (!(pk instanceof RSAPublicKey)) throw new CryptoException(CryptoException.FORMAT);
            int bits = ((RSAPublicKey) pk).getModulus().bitLength();
            if (bits < 2048 || bits > 8192) throw new CryptoException(CryptoException.FORMAT);
            byte[] canon = pk.getEncoded();
            String id = AsymCrypto.hex(AsymCrypto.idOf(canon));
            List<Contact> l = list(c);
            for (Contact k : l) if (k.idHex.equals(id)) throw new CryptoException(DUPLICATE);
            Contact nc = new Contact(n, canon, id);
            l.add(nc);
            save(c, l);
            return nc;
        } catch (CryptoException e) {
            throw e;
        } catch (Exception e) {
            throw new CryptoException(CryptoException.FORMAT, e);
        }
    }

    static synchronized void remove(Context c, String idHex) {
        List<Contact> l = list(c);
        for (int i = l.size() - 1; i >= 0; i--) if (l.get(i).idHex.equals(idHex)) l.remove(i);
        save(c, l);
    }

    static Contact byIdHex(Context c, String idHex) {
        for (Contact k : list(c)) if (k.idHex.equals(idHex)) return k;
        return null;
    }

    static Contact byId(Context c, byte[] id8) {
        return id8 == null ? null : byIdHex(c, AsymCrypto.hex(id8));
    }
}
