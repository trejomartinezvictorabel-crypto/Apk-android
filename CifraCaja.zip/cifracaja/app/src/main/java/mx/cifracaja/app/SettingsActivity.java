package mx.cifracaja.app;

import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.ProgressBar;
import android.widget.Switch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

/** Configuracion: idioma, destino de exportacion, modelos de voz, tutoriales y privacidad. */
public class SettingsActivity extends BaseActivity {
    private static final String SITE = "https://alphacephei.com/vosk/models";

    private static final int REQ_PIN_ON = 5001;
    private static final int REQ_PIN_OFF = 5002;
    private static final int REQ_PIN_CHANGE_VERIFY = 5003;
    private static final int REQ_PIN_CHANGE_SET = 5004;

    private Switch pinSwitch;
    private LinearLayout pinPanel;
    private boolean pinIgnore;
    private Switch asymSwitch;
    private ProgressBar asymProgress;
    private LinearLayout asymPanel;
    private TextView asymInfo, asymPub;
    private boolean asymIgnore;
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView section(int res) {
        TextView t = new TextView(this);
        t.setText(res);
        t.setTextSize(17);
        t.setPadding(0, dp(18), 0, dp(6));
        return t;
    }

    private Button btn(int res, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(res);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(24));

        TextView title = new TextView(this);
        title.setText(R.string.settings_title);
        title.setTextSize(22);
        root.addView(title);

        // Idioma
        root.addView(section(R.string.language_label));
        Spinner sp = new Spinner(this);
        sp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                LocaleHelper.names(this)));
        sp.setSelection(LocaleHelper.indexOf(LocaleHelper.saved(this)));
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View v, int pos, long id) {
                String code = LocaleHelper.LANGS[pos][0];
                if (!code.equals(LocaleHelper.saved(SettingsActivity.this))) {
                    LocaleHelper.save(SettingsActivity.this, code);
                    recreate();
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
        root.addView(sp);

        // Bloqueo con PIN
        root.addView(section(R.string.settings_pin));
        TextView pinDesc = new TextView(this);
        pinDesc.setText(R.string.pin_desc);
        root.addView(pinDesc);
        pinSwitch = new Switch(this);
        pinSwitch.setText(R.string.pin_switch);
        pinSwitch.setPadding(0, dp(8), 0, dp(8));
        root.addView(pinSwitch);
        pinPanel = new LinearLayout(this);
        pinPanel.setOrientation(LinearLayout.VERTICAL);
        TextView toLabel = new TextView(this);
        toLabel.setText(R.string.pin_timeout_label);
        pinPanel.addView(toLabel);
        Spinner toSpinner = new Spinner(this);
        toSpinner.setAdapter(ArrayAdapter.createFromResource(this, R.array.pin_timeouts,
                android.R.layout.simple_spinner_dropdown_item));
        toSpinner.setSelection(PinStore.timeoutIndex(this));
        toSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View v, int pos, long id) {
                if (pos != PinStore.timeoutIndex(SettingsActivity.this)) PinStore.setTimeoutIndex(SettingsActivity.this, pos);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
        pinPanel.addView(toSpinner);
        pinPanel.addView(btn(R.string.btn_change_pin, v ->
                startActivityForResult(LockActivity.intent(this, LockActivity.MODE_VERIFY), REQ_PIN_CHANGE_VERIFY)));
        root.addView(pinPanel);
        boolean pinOn = PinStore.isEnabled(this);
        pinSwitch.setChecked(pinOn);
        pinPanel.setVisibility(pinOn ? View.VISIBLE : View.GONE);
        pinSwitch.setOnCheckedChangeListener((v, checked) -> {
            if (pinIgnore) return;
            startActivityForResult(LockActivity.intent(this,
                    checked ? LockActivity.MODE_SET : LockActivity.MODE_VERIFY),
                    checked ? REQ_PIN_ON : REQ_PIN_OFF);
        });

        // Destino de exportacion
        root.addView(section(R.string.settings_export_dest));
        RadioGroup group = new RadioGroup(this);
        RadioButton rbDl = new RadioButton(this);
        rbDl.setText(R.string.dest_opt_downloads);
        RadioButton rbCard = new RadioButton(this);
        rbCard.setText(R.string.dest_opt_card);
        group.addView(rbDl);
        group.addView(rbCard);
        root.addView(group);
        group.check("card".equals(ExportStore.getDest(this)) ? rbCard.getId() : rbDl.getId());
        group.setOnCheckedChangeListener((g, id) ->
                ExportStore.setDest(this, id == rbCard.getId() ? "card" : "downloads"));

        // Llaves asimetricas (apagado por defecto)
        root.addView(section(R.string.asym_title));
        TextView asymDesc = new TextView(this);
        asymDesc.setText(R.string.asym_desc);
        root.addView(asymDesc);
        asymSwitch = new Switch(this);
        asymSwitch.setText(R.string.asym_switch);
        asymSwitch.setPadding(0, dp(8), 0, dp(8));
        root.addView(asymSwitch);
        asymProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        asymProgress.setIndeterminate(true);
        asymProgress.setVisibility(View.GONE);
        root.addView(asymProgress);

        asymPanel = new LinearLayout(this);
        asymPanel.setOrientation(LinearLayout.VERTICAL);
        asymPanel.setVisibility(View.GONE);
        asymInfo = new TextView(this);
        asymInfo.setTextIsSelectable(true);
        asymPanel.addView(asymInfo);
        TextView pubLabel = new TextView(this);
        pubLabel.setText(R.string.asym_public_label);
        pubLabel.setPadding(0, dp(8), 0, dp(2));
        asymPanel.addView(pubLabel);
        asymPub = new TextView(this);
        asymPub.setTypeface(Typeface.MONOSPACE);
        asymPub.setTextSize(11);
        asymPub.setTextIsSelectable(true);
        asymPanel.addView(asymPub);
        Button copy = btn(R.string.btn_copy_public, v -> copyPublic());
        Button share = btn(R.string.btn_share_public, v -> sharePublic());
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(copy, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(share, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        asymPanel.addView(row);
        TextView warn = new TextView(this);
        warn.setText(R.string.asym_warning);
        warn.setPadding(0, dp(8), 0, 0);
        asymPanel.addView(warn);
        asymPanel.addView(btn(R.string.btn_contacts, v -> startActivity(new Intent(this, ContactsActivity.class))));
        root.addView(asymPanel);

        boolean asymOn = AsymKeys.enabled(this);
        if (asymOn && !AsymKeys.exists()) {
            AsymKeys.setEnabled(this, false);
            asymOn = false;
            Toast.makeText(this, R.string.asym_lost, Toast.LENGTH_LONG).show();
        }
        asymSwitch.setChecked(asymOn);
        if (asymOn) showAsym();
        asymSwitch.setOnCheckedChangeListener((v, checked) -> {
            if (asymIgnore) return;
            if (checked) enableAsym();
            else confirmDisableAsym();
        });

        // Voz
        root.addView(section(R.string.settings_voice));
        root.addView(btn(R.string.btn_models, v -> startActivity(new Intent(this, ModelsActivity.class))));
        root.addView(btn(R.string.btn_open_site, v -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(SITE)));
            } catch (ActivityNotFoundException e) {
                Toast.makeText(this, R.string.no_browser, Toast.LENGTH_SHORT).show();
            }
        }));

        // Ayuda y privacidad
        root.addView(section(R.string.settings_help));
        root.addView(btn(R.string.btn_tutorial_app,
                v -> startActivity(TutorialActivity.intent(this, TutorialActivity.APP))));
        root.addView(btn(R.string.btn_tutorial_models,
                v -> startActivity(TutorialActivity.intent(this, TutorialActivity.MODELS))));
        root.addView(btn(R.string.btn_privacy, v -> startActivity(new Intent(this, PrivacyActivity.class))));

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
    }

    @Override
    protected void onDestroy() {
        exec.shutdown();
        super.onDestroy();
    }

    private void setPinSwitch(boolean v) {
        pinIgnore = true;
        pinSwitch.setChecked(v);
        pinIgnore = false;
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        boolean ok = res == RESULT_OK;
        switch (req) {
            case REQ_PIN_ON:
                if (ok) {
                    pinPanel.setVisibility(View.VISIBLE);
                    Toast.makeText(this, R.string.pin_enabled, Toast.LENGTH_SHORT).show();
                } else {
                    setPinSwitch(false);
                }
                break;
            case REQ_PIN_OFF:
                if (ok) {
                    PinStore.disable(this);
                    pinPanel.setVisibility(View.GONE);
                    Toast.makeText(this, R.string.pin_disabled, Toast.LENGTH_SHORT).show();
                } else {
                    setPinSwitch(true);
                }
                break;
            case REQ_PIN_CHANGE_VERIFY:
                if (ok) startActivityForResult(LockActivity.intent(this, LockActivity.MODE_SET), REQ_PIN_CHANGE_SET);
                break;
            case REQ_PIN_CHANGE_SET:
                if (ok) Toast.makeText(this, R.string.pin_changed, Toast.LENGTH_SHORT).show();
                break;
            default:
                break;
        }
    }

    private void setSwitch(boolean v) {
        asymIgnore = true;
        asymSwitch.setChecked(v);
        asymIgnore = false;
    }

    private void enableAsym() {
        asymSwitch.setEnabled(false);
        asymProgress.setVisibility(View.VISIBLE);
        Toast.makeText(this, R.string.asym_generating, Toast.LENGTH_SHORT).show();
        exec.execute(() -> {
            boolean ok = true;
            try {
                AsymKeys.generate();
            } catch (Exception e) {
                Log.w("CJA", "E_KEYGEN");
                ok = false;
            }
            final boolean done = ok;
            ui.post(() -> {
                asymProgress.setVisibility(View.GONE);
                asymSwitch.setEnabled(true);
                if (done) {
                    AsymKeys.setEnabled(this, true);
                    showAsym();
                } else {
                    setSwitch(false);
                    Toast.makeText(this, R.string.asym_err, Toast.LENGTH_LONG).show();
                }
            });
        });
    }

    private void confirmDisableAsym() {
        new AlertDialog.Builder(this)
                .setMessage(R.string.asym_confirm_off)
                .setPositiveButton(R.string.btn_yes, (d, w) -> {
                    AsymKeys.delete();
                    AsymKeys.setEnabled(this, false);
                    asymPanel.setVisibility(View.GONE);
                    Toast.makeText(this, R.string.asym_deleted, Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(R.string.btn_no, (d, w) -> setSwitch(true))
                .setOnCancelListener(d -> setSwitch(true))
                .show();
    }

    private void showAsym() {
        try {
            asymInfo.setText(getString(R.string.asym_ready, AsymKeys.algorithmLabel(), AsymKeys.fingerprint()));
            asymPub.setText(AsymKeys.publicText());
            asymPanel.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            Log.w("CJA", "E_KEYREAD");
            asymPanel.setVisibility(View.GONE);
            Toast.makeText(this, R.string.asym_lost, Toast.LENGTH_LONG).show();
        }
    }

    private void copyPublic() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("", asymPub.getText()));
            Toast.makeText(this, R.string.public_copied, Toast.LENGTH_SHORT).show();
        }
    }

    private void sharePublic() {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, asymPub.getText().toString());
        startActivity(Intent.createChooser(i, getString(R.string.asym_share_title)));
    }
}
