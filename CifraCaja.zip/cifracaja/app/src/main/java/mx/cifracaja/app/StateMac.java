package mx.cifracaja.app;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.security.KeyStore;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.SecretKey;

/** HMAC-SHA256 con clave del Android Keystore para proteger el registro local contra edicion. */
final class StateMac {
    private StateMac() {}

    private static final String ALIAS = "cifracaja_state_hmac";

    private static SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (!ks.containsAlias(ALIAS)) {
            KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_HMAC_SHA256, "AndroidKeyStore");
            kg.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_SIGN).build());
            return kg.generateKey();
        }
        return (SecretKey) ks.getKey(ALIAS, null);
    }

    /** Devuelve el MAC en hexadecimal, o null si el Keystore no esta disponible en este equipo. */
    static String sign(byte[] data) {
        try {
            Mac m = Mac.getInstance("HmacSHA256");
            m.init(key());
            byte[] t = m.doFinal(data);
            StringBuilder sb = new StringBuilder();
            for (byte b : t) sb.append(String.format("%02x", b & 0xFF));
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }
}
