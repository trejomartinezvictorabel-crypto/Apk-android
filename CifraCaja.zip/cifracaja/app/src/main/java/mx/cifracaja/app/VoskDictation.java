package mx.cifracaja.app;

import android.os.Handler;
import android.os.Looper;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;
import org.vosk.Model;
import org.vosk.Recognizer;
import org.vosk.android.RecognitionListener;
import org.vosk.android.SpeechService;

/** Dictado 100 % offline con Vosk. Libera microfono, SpeechService y modelo al terminar. */
final class VoskDictation {
    interface Callback {
        void onReady();
        void onPartial(String text);
        void onFinal(String text);
        void onError(String code); // E_MODEL, E_MEM, E_VOSK
    }

    private static final float RATE = 16000f;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService loader = Executors.newSingleThreadExecutor();
    private Model model;
    private File loadedDir;
    private SpeechService service;
    private Recognizer recognizer;
    private volatile boolean deliver;
    private volatile int generation;

    /** Carga el modelo en segundo plano y empieza a escuchar. Llamar desde el hilo principal. */
    void start(File modelDir, Callback cb) {
        final int gen = ++generation;
        deliver = true;
        loader.execute(() -> {
            Model m;
            try {
                synchronized (VoskDictation.this) {
                    if (model == null || !modelDir.equals(loadedDir)) {
                        closeModel();
                        model = new Model(modelDir.getAbsolutePath());
                        loadedDir = modelDir;
                    }
                    m = model;
                }
            } catch (OutOfMemoryError e) {
                synchronized (VoskDictation.this) { closeModel(); }
                main.post(() -> { if (gen == generation) cb.onError("E_MEM"); });
                return;
            } catch (IOException | RuntimeException e) {
                main.post(() -> { if (gen == generation) cb.onError("E_MODEL"); });
                return;
            }
            main.post(() -> {
                if (gen != generation) return; // cancelado mientras cargaba
                try {
                    recognizer = new Recognizer(m, RATE);
                    service = new SpeechService(recognizer, RATE);
                    if (!service.startListening(listener(cb))) {
                        stop(false);
                        cb.onError("E_VOSK");
                        return;
                    }
                    cb.onReady();
                } catch (IOException | RuntimeException e) {
                    stop(false);
                    cb.onError("E_VOSK");
                }
            });
        });
    }

    private RecognitionListener listener(Callback cb) {
        return new RecognitionListener() {
            @Override public void onPartialResult(String h) {
                if (deliver) cb.onPartial(field(h, "partial"));
            }
            @Override public void onResult(String h) {
                if (deliver) cb.onFinal(field(h, "text"));
            }
            @Override public void onFinalResult(String h) {
                if (deliver) cb.onFinal(field(h, "text"));
            }
            @Override public void onError(Exception e) {
                if (deliver) cb.onError("E_VOSK");
            }
            @Override public void onTimeout() { }
        };
    }

    private static String field(String json, String key) {
        try {
            return new JSONObject(json).optString(key, "");
        } catch (Exception e) {
            return "";
        }
    }

    /** Detiene la escucha y libera el microfono. deliver=false descarta el texto pendiente. */
    void stop(boolean deliverPending) {
        generation++;
        deliver = deliverPending;
        SpeechService s = service;
        Recognizer r = recognizer;
        service = null;
        recognizer = null;
        if (s != null) {
            try { s.stop(); } catch (RuntimeException ignored) { }
            try { s.shutdown(); } catch (RuntimeException ignored) { }
        }
        if (r != null) {
            try { r.close(); } catch (Exception ignored) { }
        }
    }

    /** Libera tambien el modelo de la RAM. */
    void release() {
        stop(false);
        synchronized (this) { closeModel(); }
    }

    private void closeModel() {
        if (model != null) {
            try { model.close(); } catch (Exception ignored) { }
            model = null;
            loadedDir = null;
        }
    }
}
