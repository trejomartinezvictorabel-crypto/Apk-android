package mx.cifracaja.app;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import mx.cifracaja.app.crypto.PinHasher;
import mx.cifracaja.app.crypto.Wipe;

/** Pantalla del PIN: fondo negro, letras blancas medianas-grandes y teclado propio. */
public class LockActivity extends BaseActivity {
    static final String EXTRA_MODE = "mode";
    static final int MODE_UNLOCK = 0;   // desbloquear la app
    static final int MODE_SET = 1;      // crear o cambiar el PIN (pide repetirlo)
    static final int MODE_VERIFY = 2;   // confirmar el PIN actual (cambiar o desactivar)
    private static final int MIN_LEN = 4;
    private static final int MAX_LEN = 8;

    static Intent unlockIntent(Context c) {
        return intent(c, MODE_UNLOCK).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NO_ANIMATION);
    }

    static Intent intent(Context c, int mode) {
        return new Intent(c, LockActivity.class).putExtra(EXTRA_MODE, mode);
    }

    private int mode;
    private final char[] pin = new char[MAX_LEN];
    private int n;
    private char[] first;
    private TextView title, status, dots;
    private final java.util.List<Button> keys = new java.util.ArrayList<>();
    private boolean working, waiting;
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            long rem = PinStore.remainingWaitMs(LockActivity.this);
            if (rem <= 0) {
                waiting = false;
                setKeysEnabled(true);
                status.setText("");
                return;
            }
            status.setText(getString(R.string.lock_wait, (rem + 999) / 1000));
            ui.postDelayed(this, 1000);
        }
    };

    @Override
    protected boolean requiresUnlock() {
        return false;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView tv(int sp, int topDp) {
        TextView t = new TextView(this);
        t.setTextColor(Color.WHITE);
        t.setTextSize(sp);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(topDp), 0, dp(6));
        return t;
    }

    private Button key(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(28);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(0xFF1E1E1E);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        keys.add(b);
        return b;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        mode = getIntent().getIntExtra(EXTRA_MODE, MODE_UNLOCK);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(20), dp(28), dp(20), dp(20));

        title = tv(26, 8);
        status = tv(18, 0);
        status.setMinHeight(dp(48));
        dots = tv(24, 8);
        dots.setTypeface(Typeface.MONOSPACE);
        root.addView(title);
        root.addView(status);
        root.addView(dots);

        String[][] rows = {{"1", "2", "3"}, {"4", "5", "6"}, {"7", "8", "9"}};
        for (String[] r : rows) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (final String d : r) addKey(row, key(d, v -> onDigit(d.charAt(0))));
            root.addView(row);
        }
        LinearLayout last = new LinearLayout(this);
        last.setOrientation(LinearLayout.HORIZONTAL);
        addKey(last, key("←", v -> onDel()));
        addKey(last, key("0", v -> onDigit('0')));
        addKey(last, key("OK", v -> submit()));
        root.addView(last);
        setContentView(root);

        setTitleForStep();
        render();
        if (mode != MODE_SET && PinStore.remainingWaitMs(this) > 0) startWait();
    }

    private void addKey(LinearLayout row, Button b) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(78), 1f);
        lp.setMargins(dp(5), dp(5), dp(5), dp(5));
        row.addView(b, lp);
    }

    private void setKeysEnabled(boolean on) {
        for (Button k : keys) k.setEnabled(on);
    }

    private void setTitleForStep() {
        if (mode == MODE_SET) {
            title.setText(first == null ? R.string.lock_set_title : R.string.lock_repeat);
            if (first == null) status.setText(R.string.lock_set_hint);
        } else if (mode == MODE_VERIFY) {
            title.setText(R.string.lock_verify_title);
        } else {
            title.setText(R.string.lock_unlock_title);
        }
    }

    private void render() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) sb.append("● ");
        if (mode != MODE_SET) {
            for (int i = n; i < PinStore.length(this); i++) sb.append("○ ");
        }
        dots.setText(sb.toString().trim());
    }

    private void clearPin() {
        Arrays.fill(pin, '\0');
        n = 0;
        render();
    }

    private void onDigit(char d) {
        if (working || waiting || n >= MAX_LEN) return;
        pin[n++] = d;
        render();
        if (mode != MODE_SET && n == PinStore.length(this)) submit();
    }

    private void onDel() {
        if (working || waiting || n == 0) return;
        pin[--n] = '\0';
        render();
    }

    private void submit() {
        if (working || waiting) return;
        if (mode == MODE_SET) {
            submitSet();
            return;
        }
        if (n == 0) return;
        final char[] cur = Arrays.copyOf(pin, n);
        clearPin();
        working = true;
        setKeysEnabled(false);
        status.setText(R.string.lock_checking);
        exec.execute(() -> {
            PinStore.Result r;
            try {
                r = PinStore.verify(this, cur);
            } finally {
                Wipe.chars(cur);
            }
            final PinStore.Result res = r;
            ui.post(() -> onVerified(res));
        });
    }

    private void onVerified(PinStore.Result r) {
        working = false;
        if (r == PinStore.Result.OK) {
            if (mode == MODE_UNLOCK) AppLock.unlock();
            setResult(RESULT_OK);
            finish();
            overridePendingTransition(0, 0);
            return;
        }
        setKeysEnabled(true);
        if (r == PinStore.Result.WRONG) {
            status.setText(getString(R.string.lock_wrong, PinStore.attemptsLeftInRound(this)));
        }
        if (PinStore.remainingWaitMs(this) > 0) startWait();
    }

    private void startWait() {
        waiting = true;
        setKeysEnabled(false);
        ui.removeCallbacks(tick);
        tick.run();
    }

    private void submitSet() {
        if (n < MIN_LEN) {
            status.setText(R.string.lock_set_hint);
            return;
        }
        final char[] cur = Arrays.copyOf(pin, n);
        clearPin();
        if (first == null) {
            if (PinHasher.isWeak(cur)) {
                Wipe.chars(cur);
                status.setText(R.string.lock_simple);
                return;
            }
            first = cur;
            status.setText("");
            setTitleForStep();
            return;
        }
        if (!Arrays.equals(first, cur)) {
            Wipe.chars(first);
            Wipe.chars(cur);
            first = null;
            setTitleForStep();
            status.setText(R.string.lock_mismatch);
            return;
        }
        Wipe.chars(first);
        first = null;
        working = true;
        setKeysEnabled(false);
        status.setText(R.string.lock_checking);
        exec.execute(() -> {
            boolean ok = true;
            try {
                PinStore.setPin(this, cur);
            } catch (Exception e) {
                ok = false;
            } finally {
                Wipe.chars(cur);
            }
            final boolean done = ok;
            ui.post(() -> {
                working = false;
                if (done) {
                    AppLock.unlock();
                    setResult(RESULT_OK);
                    finish();
                } else {
                    setKeysEnabled(true);
                    status.setText(R.string.lock_error);
                    setTitleForStep();
                }
            });
        });
    }

    @Override
    public void onBackPressed() {
        if (mode == MODE_UNLOCK) {
            moveTaskToBack(true); // no se puede saltar el PIN
        } else {
            setResult(RESULT_CANCELED);
            finish();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        Arrays.fill(pin, '\0');
        n = 0;
        Wipe.chars(first);
        first = null;
        setTitleForStep();
    }

    @Override
    protected void onDestroy() {
        ui.removeCallbacks(tick);
        exec.shutdownNow();
        super.onDestroy();
    }
}
