package mx.cifracaja.app;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import mx.cifracaja.app.crypto.CryptoException;

/** Contactos: importar sus llaves publicas, ver su huella y eliminarlos. */
public class ContactsActivity extends BaseActivity {
    private EditText nameField, keyField;
    private TextView statusView;
    private LinearLayout listBox;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String s, int size) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setPadding(0, dp(8), 0, dp(4));
        return t;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(24));
        root.addView(text(getString(R.string.contacts_title), 22));
        root.addView(text(getString(R.string.contacts_help), 14));

        nameField = new EditText(this);
        nameField.setHint(R.string.contacts_name_hint);
        nameField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        root.addView(nameField);
        keyField = new EditText(this);
        keyField.setHint(R.string.contacts_key_hint);
        keyField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        keyField.setMinLines(3);
        root.addView(keyField);
        Button add = new Button(this);
        add.setText(R.string.btn_add_contact);
        add.setAllCaps(false);
        add.setOnClickListener(v -> addContact());
        root.addView(add);
        statusView = text("", 14);
        statusView.setTextIsSelectable(true);
        root.addView(statusView);
        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(listBox);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
        refresh();
    }

    private void addContact() {
        try {
            Contacts.Contact c = Contacts.add(this, nameField.getText().toString(), keyField.getText().toString());
            nameField.setText("");
            keyField.setText("");
            statusView.setText(getString(R.string.contacts_added, c.name, c.fingerprint()));
            refresh();
        } catch (CryptoException e) {
            int msg;
            if (Contacts.DUPLICATE.equals(e.code)) msg = R.string.contacts_dup;
            else if (CryptoException.PARAM.equals(e.code)) msg = R.string.contacts_name_missing;
            else msg = R.string.contacts_invalid;
            statusView.setText(msg);
        }
    }

    private void refresh() {
        listBox.removeAllViews();
        java.util.List<Contacts.Contact> all = Contacts.list(this);
        if (all.isEmpty()) listBox.addView(text(getString(R.string.contacts_none), 14));
        for (Contacts.Contact c : all) {
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.VERTICAL);
            r.addView(text(getString(R.string.contacts_row, c.name, c.fingerprint()), 15));
            Button del = new Button(this);
            del.setText(R.string.btn_delete);
            del.setAllCaps(false);
            del.setOnClickListener((View v) -> new AlertDialog.Builder(this)
                    .setMessage(R.string.confirm_delete_contact)
                    .setPositiveButton(R.string.btn_yes, (d, w) -> {
                        Contacts.remove(this, c.idHex);
                        refresh();
                    })
                    .setNegativeButton(R.string.btn_no, null)
                    .show());
            r.addView(del);
            listBox.addView(r);
        }
    }
}
