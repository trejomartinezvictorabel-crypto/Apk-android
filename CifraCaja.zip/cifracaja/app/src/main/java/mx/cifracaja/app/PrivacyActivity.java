package mx.cifracaja.app;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Politica de privacidad completa, visible sin conexion. */
public class PrivacyActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int pad = (int) (16 * getResources().getDisplayMetrics().density + 0.5f);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        TextView title = new TextView(this);
        title.setText(R.string.privacy_title);
        title.setTextSize(22);
        root.addView(title);
        TextView body = new TextView(this);
        body.setText(R.string.privacy_text);
        body.setTextSize(15);
        body.setPadding(0, pad, 0, pad);
        body.setTextIsSelectable(true);
        root.addView(body);
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
    }
}
