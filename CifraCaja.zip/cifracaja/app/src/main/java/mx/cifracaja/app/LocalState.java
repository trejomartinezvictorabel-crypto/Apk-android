package mx.cifracaja.app;

import android.content.Context;
import android.os.SystemClock;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import mx.cifracaja.app.crypto.CryptoException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Registro local privado y protegido contra edicion (HMAC con clave del Keystore):
 *  - ultima hora observada (deteccion de reloj retrocedido), y
 *  - identificadores de paquetes de uso unico ya consumidos.
 * Todo vive en el almacenamiento privado de la app, sin respaldos y sin salir del telefono.
 * Limite honesto: borrar los datos de la app o un equipo con root pueden reiniciarlo.
 */
final class LocalState {
    private LocalState() {}

    static final long TOLERANCE_MS = 2 * 60_000L; // ajustes normales de hora por red
    static final int MAX_USED = 5000;
    private static final long DAY = 86_400_000L;

    private static final class Used {
        final String id;
        final long consumedAt;
        final long expiresAt;

        Used(String id, long consumedAt, long expiresAt) {
            this.id = id;
            this.consumedAt = consumedAt;
            this.expiresAt = expiresAt;
        }
    }

    private static final class Snapshot {
        long max, last, el;
        final List<Used> used = new ArrayList<>();
    }

    private static File file(Context c) {
        File d = new File(c.getFilesDir(), "state");
        //noinspection ResultOfMethodCallIgnored
        d.mkdirs();
        return new File(d, "cifracaja.state");
    }

    private static Snapshot load(Context c) throws CryptoException {
        File f = file(c);
        Snapshot s = new Snapshot();
        if (!f.exists()) return s;
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
            String mac = r.readLine();
            String json = r.readLine();
            if (mac == null || json == null) throw new CryptoException(CryptoException.STATE);
            String expect = StateMac.sign(json.getBytes(StandardCharsets.UTF_8));
            boolean ok = expect != null
                    ? MessageDigest.isEqual(expect.getBytes(StandardCharsets.UTF_8), mac.getBytes(StandardCharsets.UTF_8))
                    : "-".equals(mac); // sin Keystore en este equipo: registro sin MAC
            if (!ok) throw new CryptoException(CryptoException.STATE);
            JSONObject o = new JSONObject(json);
            s.max = o.getLong("max");
            s.last = o.getLong("last");
            s.el = o.getLong("el");
            JSONArray a = o.getJSONArray("used");
            for (int i = 0; i < a.length(); i++) {
                JSONArray e = a.getJSONArray(i);
                s.used.add(new Used(e.getString(0), e.getLong(1), e.getLong(2)));
            }
            return s;
        } catch (CryptoException e) {
            throw e;
        } catch (IOException | JSONException | RuntimeException e) {
            throw new CryptoException(CryptoException.STATE, e);
        }
    }

    private static void purge(Snapshot s) {
        // Los paquetes ya vencidos no pueden abrirse (la comprobacion de reloj lo impide), asi que su
        // registro sobra un dia despues del vencimiento. Se usa la hora maxima observada, nunca la actual.
        for (int i = s.used.size() - 1; i >= 0; i--) {
            Used u = s.used.get(i);
            if (u.expiresAt > 0 && u.expiresAt + DAY < s.max) s.used.remove(i);
        }
        while (s.used.size() > MAX_USED) s.used.remove(0); // los mas antiguos primero
    }

    private static void save(Context c, Snapshot s) throws CryptoException {
        try {
            purge(s);
            JSONObject o = new JSONObject();
            o.put("v", 1);
            o.put("max", s.max);
            o.put("last", s.last);
            o.put("el", s.el);
            JSONArray a = new JSONArray();
            for (Used u : s.used) {
                JSONArray e = new JSONArray();
                e.put(u.id);
                e.put(u.consumedAt);
                e.put(u.expiresAt);
                a.put(e);
            }
            o.put("used", a);
            String json = o.toString();
            String mac = StateMac.sign(json.getBytes(StandardCharsets.UTF_8));
            File f = file(c);
            File tmp = new File(f.getParentFile(), "cifracaja.state.tmp");
            try (FileOutputStream os = new FileOutputStream(tmp)) {
                os.write(((mac == null ? "-" : mac) + "\n" + json + "\n").getBytes(StandardCharsets.UTF_8));
                os.getFD().sync();
            }
            if (!tmp.renameTo(f)) throw new IOException();
        } catch (IOException | JSONException e) {
            throw new CryptoException(CryptoException.STATE, e);
        }
    }

    /**
     * Registra la hora observada si es coherente. Devuelve false si el reloj parece retrocedido
     * (en ese caso NO se actualiza el registro, para que atrasar la hora no lo "reinicie").
     */
    static synchronized boolean observeClock(Context c) throws CryptoException {
        long now = System.currentTimeMillis();
        long el = SystemClock.elapsedRealtime();
        Snapshot s = load(c);
        boolean ok = true;
        if (s.max > 0) {
            if (now + TOLERANCE_MS < s.max) ok = false; // por debajo de la hora maxima ya vista
            else if (s.last > 0 && el >= s.el && now + TOLERANCE_MS < s.last + (el - s.el)) {
                ok = false; // mismo arranque: el tiempo real transcurrido no cuadra con el reloj
            }
        }
        if (ok) {
            s.max = Math.max(s.max, now);
            s.last = now;
            s.el = el;
            save(c, s);
        }
        return ok;
    }

    static synchronized boolean isUsed(Context c, String id) throws CryptoException {
        for (Used u : load(c).used) if (u.id.equals(id)) return true;
        return false;
    }

    static synchronized void markUsed(Context c, String id, long expiresAt) throws CryptoException {
        Snapshot s = load(c);
        for (Used u : s.used) if (u.id.equals(id)) return;
        s.used.add(new Used(id, System.currentTimeMillis(), expiresAt));
        save(c, s);
    }
}
