package mx.cifracaja.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.interfaces.RSAPublicKey;
import javax.security.auth.x500.X500Principal;

/**
 * Par de llaves asimetricas opcional (apagado por defecto). La llave privada se genera DENTRO del
 * Android Keystore: no se puede exportar ni leer, ni siquiera por la propia app, y ninguna otra app
 * puede usarla. Solo la llave publica sale, y unicamente cuando el usuario decide compartirla.
 */
final class AsymKeys {
    private AsymKeys() {}

    static final String ALIAS = "cifracaja_asym_v2";
    private static final String OLD_ALIAS = "cifracaja_asym_v1";
    static final String PUBLIC_PREFIX = "CJAPUB1:";

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
    }

    /** Interruptor de Configuracion. Falso por defecto. */
    static boolean enabled(Context c) {
        return prefs(c).getBoolean("asym_enabled", false);
    }

    static void setEnabled(Context c, boolean on) {
        prefs(c).edit().putBoolean("asym_enabled", on).apply();
    }

    private static KeyStore keystore() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        return ks;
    }

    static boolean exists() {
        try {
            return keystore().containsAlias(ALIAS);
        } catch (Exception e) {
            return false;
        }
    }

    /** Crea el par (RSA-3072; si el equipo no lo soporta, RSA-2048). Puede tardar unos segundos. */
    static void generate() throws Exception {
        delete();
        Exception last = null;
        for (int bits : new int[]{3072, 2048}) {
            try {
                KeyPairGenerator kpg = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA, "AndroidKeyStore");
                kpg.initialize(new KeyGenParameterSpec.Builder(ALIAS,
                        KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT
                                | KeyProperties.PURPOSE_SIGN | KeyProperties.PURPOSE_VERIFY)
                        .setKeySize(bits)
                        .setDigests(KeyProperties.DIGEST_SHA256, KeyProperties.DIGEST_SHA512)
                        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_RSA_OAEP)
                        .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1, KeyProperties.SIGNATURE_PADDING_RSA_PSS)
                        .setCertificateSubject(new X500Principal("CN=CifraCaja"))
                        .build());
                kpg.generateKeyPair();
                return;
            } catch (Exception e) {
                last = e;
                delete();
            }
        }
        throw last != null ? last : new IllegalStateException();
    }

    /** Elimina el par de forma permanente (la llave privada no se puede recuperar). */
    static void delete() {
        try {
            KeyStore ks = keystore();
            if (ks.containsAlias(ALIAS)) ks.deleteEntry(ALIAS);
            if (ks.containsAlias(OLD_ALIAS)) ks.deleteEntry(OLD_ALIAS);
        } catch (Exception ignored) {
            // sin accion: si no existe, no hay nada que borrar
        }
    }

    private static PublicKey publicKey() throws Exception {
        return keystore().getCertificate(ALIAS).getPublicKey();
    }

    /** Llave publica en formato X.509 DER. */
    static byte[] publicDer() throws Exception {
        return publicKey().getEncoded();
    }

    /** Llave privada: solo una referencia al Keystore; sus bytes no se pueden leer. */
    static java.security.PrivateKey privateKey() throws Exception {
        return (java.security.PrivateKey) keystore().getKey(ALIAS, null);
    }

    /** Llave publica en texto compartible (X.509 DER en Base64 con prefijo propio). */
    static String publicText() throws Exception {
        return PUBLIC_PREFIX + Base64.encodeToString(publicKey().getEncoded(), Base64.NO_WRAP);
    }

    /** Huella corta de la llave publica XXXX-XXXX-XXXX-XXXX para verificarla con el contacto. */
    static String fingerprint() throws Exception {
        return AsymCrypto.fingerprintOf(publicDer());
    }

    static String algorithmLabel() throws Exception {
        PublicKey pk = publicKey();
        if (pk instanceof RSAPublicKey) return "RSA-" + ((RSAPublicKey) pk).getModulus().bitLength();
        return pk.getAlgorithm();
    }
}
