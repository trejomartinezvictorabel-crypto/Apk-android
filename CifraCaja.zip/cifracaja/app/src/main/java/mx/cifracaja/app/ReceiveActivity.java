package mx.cifracaja.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Recibe archivos o textos enviados con "Compartir" desde cualquier app (galeria, WhatsApp, correo...)
 * o al tocar un paquete protegido. Copia el archivo a la zona privada (en bloques de 64 KB) y abre
 * la pantalla principal con el archivo ya elegido. Nada sale del telefono.
 */
public class ReceiveActivity extends BaseActivity {
    static final String EXTRA_INBOX = "inbox";
    static final String EXTRA_TEXT = "text";

    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected boolean requiresUnlock() {
        return false; // el PIN lo pide la pantalla principal antes de mostrar nada
    }

    @SuppressWarnings("deprecation")
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        TextView tv = new TextView(this);
        tv.setText(R.string.receiving);
        tv.setTextSize(22);
        tv.setGravity(Gravity.CENTER);
        setContentView(tv);

        Intent in = getIntent();
        String action = in.getAction();
        Uri uri = null;
        String text = null;
        if (Intent.ACTION_SEND.equals(action)) {
            uri = in.getParcelableExtra(Intent.EXTRA_STREAM);
            CharSequence cs = in.getCharSequenceExtra(Intent.EXTRA_TEXT);
            if (cs != null) text = cs.toString();
        } else if (Intent.ACTION_VIEW.equals(action)) {
            uri = in.getData();
        }
        if (uri != null) {
            copyThenForward(uri);
        } else if (text != null && !text.trim().isEmpty()) {
            forward(null, text);
        } else {
            finish();
        }
    }

    private void copyThenForward(final Uri u) {
        exec.execute(() -> {
            File out = null;
            boolean ok = false;
            try {
                VaultStorage.FileInfo info = VaultStorage.query(getContentResolver(), u);
                File dir = VaultStorage.dir(this, "inbox");
                long need = info.size < 0 ? 64L * 1024 * 1024 : info.size + 1024L * 1024;
                if (!VaultStorage.hasSpace(dir, need)) throw new IOException();
                out = VaultStorage.unique(dir, info.name);
                try (InputStream in = getContentResolver().openInputStream(u);
                     OutputStream os = new BufferedOutputStream(new FileOutputStream(out))) {
                    if (in == null) throw new IOException();
                    byte[] buf = new byte[64 * 1024];
                    int n;
                    while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                }
                ok = true;
            } catch (Exception e) {
                Log.w("CJA", "E_RECEIVE");
            } finally {
                if (!ok && out != null) //noinspection ResultOfMethodCallIgnored
                    out.delete();
            }
            final File f = ok ? out : null;
            ui.post(() -> {
                if (f == null) {
                    Toast.makeText(this, R.string.err_receive, Toast.LENGTH_LONG).show();
                    finish();
                } else {
                    forward(f.getName(), null);
                }
            });
        });
    }

    private void forward(String inboxName, String text) {
        Intent i = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (inboxName != null) i.putExtra(EXTRA_INBOX, inboxName);
        if (text != null) i.putExtra(EXTRA_TEXT, text);
        startActivity(i);
        finish();
    }

    @Override
    protected void onDestroy() {
        exec.shutdown();
        super.onDestroy();
    }
}
