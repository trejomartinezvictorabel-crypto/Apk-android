package mx.cifracaja.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import java.util.Locale;

/**
 * Idioma de la app. Para anadir un idioma: crear res/values-XX/strings.xml (copia de values/)
 * y agregar una linea en LANGS. Los idiomas sin traduccion usan ingles como respaldo.
 */
final class LocaleHelper {
    private LocaleHelper() {}

    /** {codigo, nombre en su propio idioma}. "system" = idioma del sistema. */
    static final String[][] LANGS = {
            {"system", ""},
            {"es", "Español"},
            {"en", "English"},
    };

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
    }

    static String saved(Context c) {
        return prefs(c).getString("lang", "system");
    }

    static void save(Context c, String code) {
        prefs(c).edit().putString("lang", code).apply();
    }

    static Context wrap(Context base) {
        String l = saved(base);
        if ("system".equals(l)) return base;
        Locale loc = new Locale(l);
        Locale.setDefault(loc);
        Configuration cfg = new Configuration(base.getResources().getConfiguration());
        cfg.setLocale(loc);
        return base.createConfigurationContext(cfg);
    }

    static String[] names(Context c) {
        String[] n = new String[LANGS.length];
        for (int i = 0; i < n.length; i++) {
            n[i] = i == 0 ? c.getString(R.string.lang_system) : LANGS[i][1];
        }
        return n;
    }

    static int indexOf(String code) {
        for (int i = 0; i < LANGS.length; i++) if (LANGS[i][0].equals(code)) return i;
        return 0;
    }
}
