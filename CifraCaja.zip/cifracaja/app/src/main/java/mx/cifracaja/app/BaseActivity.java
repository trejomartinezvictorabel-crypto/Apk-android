package mx.cifracaja.app;

import android.app.Activity;
import android.content.Context;

/** Base de todas las pantallas: aplica el idioma elegido por el usuario. */
public abstract class BaseActivity extends Activity {
    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleHelper.wrap(base));
    }
}
