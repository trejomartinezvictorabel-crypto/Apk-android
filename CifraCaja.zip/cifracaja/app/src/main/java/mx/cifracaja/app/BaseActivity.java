package mx.cifracaja.app;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.View;

/** Base de todas las pantallas: idioma elegido y bloqueo con PIN por inactividad. */
public abstract class BaseActivity extends Activity {
    private final Handler idleHandler = new Handler(Looper.getMainLooper());
    private final Runnable idleCheck = new Runnable() {
        @Override public void run() {
            enforceLock();
        }
    };

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleHelper.wrap(base));
    }

    /** La pantalla del PIN devuelve false para no bloquearse a si misma. */
    protected boolean requiresUnlock() {
        return true;
    }

    /** true si hay algo en curso (grabando, dictando, cifrando) y no debe contar como inactividad. */
    protected boolean keepAlive() {
        return false;
    }

    /** Se ejecuta justo antes de bloquear: aqui se limpian clave, textos y resultados. */
    protected void onLockTriggered() { }

    @Override
    protected void onResume() {
        super.onResume();
        enforceLock();
    }

    @Override
    protected void onPause() {
        super.onPause();
        idleHandler.removeCallbacks(idleCheck);
        if (requiresUnlock()) AppLock.touch();
    }

    @Override
    public void onUserInteraction() {
        super.onUserInteraction();
        if (requiresUnlock()) AppLock.touch();
    }

    protected void enforceLock() {
        if (!requiresUnlock()) return;
        View decor = getWindow().getDecorView();
        if (keepAlive()) AppLock.touch();
        if (AppLock.needsUnlock(this)) {
            idleHandler.removeCallbacks(idleCheck);
            decor.setVisibility(View.INVISIBLE); // nada sensible queda visible detras del bloqueo
            onLockTriggered();
            startActivity(LockActivity.unlockIntent(this));
            overridePendingTransition(0, 0);
        } else {
            decor.setVisibility(View.VISIBLE);
            long rem = AppLock.remainingMs(this);
            idleHandler.removeCallbacks(idleCheck);
            if (rem >= 0) idleHandler.postDelayed(idleCheck, rem + 250);
        }
    }
}
