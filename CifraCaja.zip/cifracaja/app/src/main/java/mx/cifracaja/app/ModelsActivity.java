package mx.cifracaja.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.format.Formatter;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Instalar, elegir y borrar modelos de voz Vosk (cualquier idioma) + tutorial. */
public class ModelsActivity extends BaseActivity {
    private static final int REQ_ZIP = 4001;
    private static final String SITE = "https://alphacephei.com/vosk/models";
    private static final String SMALL_ES = "https://alphacephei.com/vosk/models/vosk-model-small-es-0.42.zip";
    private static final String TAG = "CJA";

    private interface Job { String run() throws Exception; }

    private TextView activeView, statusView;
    private ProgressBar progress;
    private Button btnBundled, btnZip, btnCancel;
    private LinearLayout listBox;
    private boolean busy;
    private final AtomicBoolean cancel = new AtomicBoolean(false);
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String s, int size) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setPadding(0, dp(8), 0, dp(4));
        return t;
    }

    private Button btn(int res, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(res);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(24));

        root.addView(text(getString(R.string.models_title), 22));
        activeView = text("", 15);
        root.addView(activeView);

        btnBundled = btn(R.string.btn_install_bundled, v -> installBundled());
        root.addView(btnBundled);
        btnZip = btn(R.string.btn_install_zip, v -> pickZip());
        root.addView(btnZip);
        root.addView(btn(R.string.btn_open_site, v -> openUrl(SITE)));
        root.addView(btn(R.string.btn_open_es, v -> openUrl(SMALL_ES)));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setIndeterminate(true);
        progress.setVisibility(View.GONE);
        root.addView(progress);
        btnCancel = btn(R.string.btn_cancel, v -> cancel.set(true));
        root.addView(btnCancel);
        statusView = text("", 15);
        statusView.setTextIsSelectable(true);
        root.addView(statusView);

        root.addView(text(getString(R.string.models_installed_section), 17));
        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(listBox);

        root.addView(text(getString(R.string.models_tutorial_title), 17));
        TextView tut = text(getString(R.string.models_tutorial), 14);
        tut.setTextIsSelectable(true);
        root.addView(tut);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
        setBusy(false);
        refresh();
    }

    @Override
    protected void onDestroy() {
        cancel.set(true);
        exec.shutdownNow();
        super.onDestroy();
    }

    private void setBusy(boolean b) {
        busy = b;
        progress.setVisibility(b ? View.VISIBLE : View.GONE);
        btnZip.setEnabled(!b);
        btnBundled.setEnabled(!b);
        btnBundled.setVisibility(VoskModelManager.bundledAvailable(this) ? View.VISIBLE : View.GONE);
        btnCancel.setEnabled(b);
    }

    private void refresh() {
        File act = VoskModelManager.active(this);
        activeView.setText(getString(R.string.models_active,
                act == null ? getString(R.string.models_none) : act.getName()));
        listBox.removeAllViews();
        for (File m : VoskModelManager.installed(this)) {
            boolean isActive = act != null && act.equals(m);
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.VERTICAL);
            r.addView(text(getString(R.string.models_row, m.getName(),
                    Formatter.formatShortFileSize(this, VoskModelManager.sizeOf(m)),
                    isActive ? getString(R.string.models_row_active) : ""), 15));
            LinearLayout bs = new LinearLayout(this);
            bs.setOrientation(LinearLayout.HORIZONTAL);
            Button use = btn(R.string.btn_use, v -> {
                VoskModelManager.setActive(this, m.getName());
                refresh();
            });
            Button del = btn(R.string.btn_delete, v -> new AlertDialog.Builder(this)
                    .setMessage(R.string.confirm_delete_model)
                    .setPositiveButton(R.string.btn_yes, (d, w) -> {
                        VoskModelManager.delete(this, m);
                        status(getString(R.string.models_deleted));
                        refresh();
                    })
                    .setNegativeButton(R.string.btn_no, null)
                    .show());
            bs.addView(use, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            bs.addView(del, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            r.addView(bs);
            listBox.addView(r);
        }
    }

    private void status(String s) {
        statusView.setText(s);
    }

    private void openUrl(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (ActivityNotFoundException e) {
            status(getString(R.string.no_browser));
        }
    }

    private void pickZip() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_ZIP);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_ZIP || res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        final VaultStorage.FileInfo info = VoskModelManager_query(uri);
        run(() -> {
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) throw new IOException();
                String name = VoskModelManager.install(this, in, info.name, info.size, cancel);
                return getString(R.string.models_ok, name);
            }
        });
    }

    private VaultStorage.FileInfo VoskModelManager_query(Uri uri) {
        return VaultStorage.query(getContentResolver(), uri);
    }

    private void installBundled() {
        run(() -> {
            long hint = -1;
            try (AssetFileDescriptor afd = getAssets().openFd(VoskModelManager.BUNDLED_ASSET)) {
                hint = afd.getLength();
            } catch (IOException ignored) {
                // sin tamano: se usa estimacion conservadora
            }
            try (InputStream in = getAssets().open(VoskModelManager.BUNDLED_ASSET)) {
                String name = VoskModelManager.install(this, in, VoskModelManager.BUNDLED_NAME, hint, cancel);
                VoskModelManager.setActive(this, name);
                return getString(R.string.models_ok, name);
            }
        });
    }

    private void run(Job job) {
        if (busy) return;
        cancel.set(false);
        setBusy(true);
        status(getString(R.string.models_installing));
        exec.execute(() -> {
            String msg;
            try {
                msg = job.run();
            } catch (VoskModelManager.ModelException e) {
                Log.w(TAG, e.code);
                switch (e.code) {
                    case VoskModelManager.SPACE: msg = getString(R.string.err_space); break;
                    case VoskModelManager.CANCEL: msg = getString(R.string.err_E_CANCEL); break;
                    default: msg = getString(R.string.models_invalid);
                }
            } catch (Exception e) {
                Log.w(TAG, "E_MODEL");
                msg = getString(R.string.models_err);
            }
            final String m = msg;
            ui.post(() -> {
                setBusy(false);
                status(m);
                refresh();
            });
        });
    }
}
