package mx.cifracaja.app.crypto;

/** Metadatos que viajan cifrados y autenticados dentro del paquete. */
public final class PackageMeta {
    public static final byte MODE_TEXT = 1;
    public static final byte MODE_FILE = 2;

    public final byte mode;
    public final String name;       // nombre original (vacio en modo texto)
    public final String extension;  // extension original
    public final long size;         // tamano en bytes del contenido
    public final long expiresAt;    // epoch UTC en ms; 0 = sin caducidad
    public final boolean singleUse; // uso unico en el dispositivo receptor
    public final byte[] packageId;  // 16 bytes aleatorios; null al cifrar (se genera), presente al descifrar

    public PackageMeta(byte mode, String name, String extension, long size, long expiresAt) {
        this(mode, name, extension, size, expiresAt, false, null);
    }

    public PackageMeta(byte mode, String name, String extension, long size, long expiresAt,
                       boolean singleUse) {
        this(mode, name, extension, size, expiresAt, singleUse, null);
    }

    public PackageMeta(byte mode, String name, String extension, long size, long expiresAt,
                       boolean singleUse, byte[] packageId) {
        this.mode = mode;
        this.name = name == null ? "" : name;
        this.extension = extension == null ? "" : extension;
        this.size = size;
        this.expiresAt = expiresAt;
        this.singleUse = singleUse;
        this.packageId = packageId;
    }

    public boolean isExpired(long nowMs) {
        return expiresAt > 0 && nowMs > expiresAt;
    }

    /** Identificador del paquete en hexadecimal (32 caracteres) o cadena vacia. */
    public String idHex() {
        if (packageId == null) return "";
        StringBuilder sb = new StringBuilder();
        for (byte b : packageId) sb.append(String.format("%02x", b & 0xFF));
        return sb.toString();
    }
}
