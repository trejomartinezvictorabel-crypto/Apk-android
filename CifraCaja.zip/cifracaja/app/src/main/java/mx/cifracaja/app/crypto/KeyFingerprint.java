package mx.cifracaja.app.crypto;

import java.security.MessageDigest;

/**
 * Huella corta derivada de la clave secreta para que dos personas confirmen que usan la
 * misma clave. Es unidireccional (PBKDF2 + SHA-256, solo 64 bits visibles): no permite
 * recuperar la clave. Con una clave debil, un atacante que vea la huella podria intentar
 * adivinarla; por eso se exige una clave larga.
 */
public final class KeyFingerprint {
    private static final byte[] DOMAIN = "CIFRACAJA-FP-v1".getBytes();
    private static final int ITER = 100_000;

    private KeyFingerprint() {}

    /** Formato XXXX-XXXX-XXXX-XXXX. */
    public static String of(char[] passphrase) throws CryptoException {
        byte[] pw = Wipe.utf8(passphrase);
        byte[] k = null;
        try {
            if (pw.length == 0) throw new CryptoException(CryptoException.PARAM);
            k = Pbkdf2.derive(pw, DOMAIN, ITER, 32);
            byte[] h = MessageDigest.getInstance("SHA-256").digest(k);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 8; i++) {
                if (i > 0 && i % 2 == 0) sb.append('-');
                sb.append(String.format("%02X", h[i] & 0xFF));
            }
            Wipe.bytes(h);
            return sb.toString();
        } catch (CryptoException e) {
            throw e;
        } catch (Exception e) {
            throw new CryptoException(CryptoException.PARAM, e);
        } finally {
            Wipe.bytes(pw, k);
        }
    }
}
