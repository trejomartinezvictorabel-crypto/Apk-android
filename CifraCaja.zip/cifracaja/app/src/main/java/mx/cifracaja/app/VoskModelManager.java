package mx.cifracaja.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Instalacion segura y gestion de modelos Vosk (cualquier idioma) en almacenamiento privado. */
final class VoskModelManager {
    private VoskModelManager() {}

    static final String BUNDLED_NAME = "vosk-model-small-es-0.42";
    static final String BUNDLED_ASSET = "models/" + BUNDLED_NAME + ".zip";

    static final String SPACE = "SPACE";
    static final String CANCEL = "CANCEL";
    static final String INVALID = "INVALID";

    private static final int MAX_ENTRIES = 50_000;
    private static final long MAX_TOTAL = 8L * 1024 * 1024 * 1024;

    static final class ModelException extends Exception {
        final String code;

        ModelException(String code) {
            super(code);
            this.code = code;
        }
    }

    static File root(Context c) {
        File r = new File(c.getFilesDir(), "models");
        //noinspection ResultOfMethodCallIgnored
        r.mkdirs();
        return r;
    }

    static boolean isModel(File d) {
        return d != null && d.isDirectory() && new File(d, "am").isDirectory()
                && new File(d, "conf").isDirectory();
    }

    static List<File> installed(Context c) {
        List<File> out = new ArrayList<>();
        File[] list = root(c).listFiles();
        if (list != null) {
            for (File f : list) if (!f.getName().startsWith(".") && isModel(f)) out.add(f);
        }
        File[] arr = out.toArray(new File[0]);
        Arrays.sort(arr, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        return new ArrayList<>(Arrays.asList(arr));
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("vosk", Context.MODE_PRIVATE);
    }

    static void setActive(Context c, String name) {
        prefs(c).edit().putString("active", name).apply();
    }

    /** Modelo en uso; si no hay uno elegido valido, el primero instalado; si no, null. */
    static File active(Context c) {
        String n = prefs(c).getString("active", null);
        if (n != null) {
            File f = new File(root(c), n);
            if (isModel(f)) return f;
        }
        List<File> all = installed(c);
        return all.isEmpty() ? null : all.get(0);
    }

    static boolean bundledAvailable(Context c) {
        try {
            String[] l = c.getAssets().list("models");
            if (l != null) for (String s : l) if (s.equals(BUNDLED_NAME + ".zip")) return true;
        } catch (IOException ignored) {
            // sin modelo incluido
        }
        return false;
    }

    static long sizeOf(File d) {
        if (d.isFile()) return d.length();
        long t = 0;
        File[] l = d.listFiles();
        if (l != null) for (File f : l) t += sizeOf(f);
        return t;
    }

    static void delete(Context c, File model) {
        if (model.getParentFile() != null && model.getParentFile().equals(root(c))) deleteRecursive(model);
    }

    static void deleteRecursive(File f) {
        if (f == null || !f.exists()) return;
        File[] l = f.listFiles();
        if (l != null) for (File x : l) deleteRecursive(x);
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }

    /**
     * Descomprime un .zip de modelo con validacion estricta de rutas (anti Zip Slip), limites
     * anti zip-bomb, verificacion de espacio y cancelacion limpia. Devuelve el nombre instalado.
     */
    static String install(Context c, InputStream raw, String suggestedName, long sizeHint,
                          AtomicBoolean cancel) throws Exception {
        File root = root(c);
        long needed = sizeHint > 0 ? sizeHint * 4 + 32L * 1024 * 1024 : 400L * 1024 * 1024;
        if (!VaultStorage.hasSpace(root, needed)) throw new ModelException(SPACE);
        File tmp = new File(root, ".tmp-" + System.nanoTime());
        if (!tmp.mkdirs()) throw new IOException();
        try {
            String tmpCanon = tmp.getCanonicalPath();
            byte[] buf = new byte[64 * 1024];
            long total = 0, sinceCheck = 0;
            int entries = 0;
            try (ZipInputStream zin = new ZipInputStream(new BufferedInputStream(raw))) {
                ZipEntry e;
                while ((e = zin.getNextEntry()) != null) {
                    if (cancel.get()) throw new ModelException(CANCEL);
                    if (++entries > MAX_ENTRIES) throw new ModelException(INVALID);
                    File out = new File(tmp, e.getName().replace('\\', '/'));
                    String canon = out.getCanonicalPath();
                    // Zip Slip: ninguna entrada puede quedar fuera del directorio temporal
                    if (!canon.equals(tmpCanon) && !canon.startsWith(tmpCanon + File.separator)) {
                        throw new ModelException(INVALID);
                    }
                    if (e.isDirectory()) {
                        //noinspection ResultOfMethodCallIgnored
                        out.mkdirs();
                        continue;
                    }
                    File parent = out.getParentFile();
                    if (parent != null) //noinspection ResultOfMethodCallIgnored
                        parent.mkdirs();
                    try (OutputStream os = new BufferedOutputStream(new FileOutputStream(out))) {
                        int n;
                        while ((n = zin.read(buf)) > 0) {
                            if (cancel.get()) throw new ModelException(CANCEL);
                            os.write(buf, 0, n);
                            total += n;
                            sinceCheck += n;
                            if (total > MAX_TOTAL) throw new ModelException(INVALID);
                            if (sinceCheck > 16L * 1024 * 1024) {
                                sinceCheck = 0;
                                if (!VaultStorage.hasSpace(root, 32L * 1024 * 1024)) {
                                    throw new ModelException(SPACE);
                                }
                            }
                        }
                    }
                }
            }
            File modelDir = null;
            String base = suggestedName;
            if (isModel(tmp)) {
                modelDir = tmp;
            } else {
                File[] kids = tmp.listFiles();
                if (kids != null) {
                    for (File k : kids) {
                        if (isModel(k)) { modelDir = k; base = k.getName(); break; }
                    }
                }
            }
            if (modelDir == null) throw new ModelException(INVALID);
            String name = VaultStorage.safeName(base);
            if (name.toLowerCase().endsWith(".zip")) name = name.substring(0, name.length() - 4);
            File dst = new File(root, name);
            int k = 1;
            while (dst.exists()) dst = new File(root, name + "-" + (k++));
            if (!modelDir.renameTo(dst)) throw new IOException();
            return dst.getName();
        } finally {
            deleteRecursive(tmp); // si ya se movio, no existe y no hace nada
        }
    }
}
