package mx.cifracaja.app.crypto;

import java.security.GeneralSecurityException;
import java.util.Arrays;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/** PBKDF2-HMAC-SHA256 propio (SecretKeyFactory solo lo ofrece desde API 26). */
final class Pbkdf2 {
    private Pbkdf2() {}

    static byte[] derive(byte[] password, byte[] salt, int iterations, int outLen)
            throws GeneralSecurityException {
        Mac mac = Mac.getInstance("HmacSHA256");
        SecretKeySpec ks = new SecretKeySpec(password, "HmacSHA256");
        mac.init(ks);
        int hLen = 32;
        int blocks = (outLen + hLen - 1) / hLen;
        byte[] out = new byte[blocks * hLen];
        byte[] u = new byte[hLen];
        byte[] t = new byte[hLen];
        for (int i = 1; i <= blocks; i++) {
            mac.update(salt);
            mac.update(new byte[]{(byte) (i >>> 24), (byte) (i >>> 16), (byte) (i >>> 8), (byte) i});
            mac.doFinal(u, 0);
            System.arraycopy(u, 0, t, 0, hLen);
            for (int j = 2; j <= iterations; j++) {
                mac.update(u);
                mac.doFinal(u, 0);
                for (int k = 0; k < hLen; k++) t[k] ^= u[k];
            }
            System.arraycopy(t, 0, out, (i - 1) * hLen, hLen);
        }
        Arrays.fill(u, (byte) 0);
        Arrays.fill(t, (byte) 0);
        return Arrays.copyOf(out, outLen);
    }
}
