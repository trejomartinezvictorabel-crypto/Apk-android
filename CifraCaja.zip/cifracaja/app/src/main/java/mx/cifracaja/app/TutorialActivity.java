package mx.cifracaja.app;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Tutoriales: uso de la app o instalacion de modelos de voz. */
public class TutorialActivity extends BaseActivity {
    static final String EXTRA = "which";
    static final String APP = "app";
    static final String MODELS = "models";

    static Intent intent(Context c, String which) {
        return new Intent(c, TutorialActivity.class).putExtra(EXTRA, which);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        boolean models = MODELS.equals(getIntent().getStringExtra(EXTRA));
        int pad = (int) (16 * getResources().getDisplayMetrics().density + 0.5f);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        TextView title = new TextView(this);
        title.setText(models ? R.string.models_tutorial_title : R.string.tutorial_app_title);
        title.setTextSize(22);
        root.addView(title);
        TextView body = new TextView(this);
        body.setText(models ? R.string.models_tutorial : R.string.tutorial_app_text);
        body.setTextSize(15);
        body.setPadding(0, pad, 0, pad);
        body.setTextIsSelectable(true);
        root.addView(body);
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
    }
}
