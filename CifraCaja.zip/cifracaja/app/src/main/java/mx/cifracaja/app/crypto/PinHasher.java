package mx.cifracaja.app.crypto;

import java.security.GeneralSecurityException;
import java.security.SecureRandom;

/** Derivacion del verificador del PIN (PBKDF2-HMAC-SHA256) y regla de PIN debil. */
public final class PinHasher {
    private PinHasher() {}

    private static final SecureRandom RNG = new SecureRandom();

    public static byte[] newSalt() {
        byte[] s = new byte[16];
        RNG.nextBytes(s);
        return s;
    }

    public static byte[] derive(char[] pin, byte[] salt, int iterations) throws CryptoException {
        byte[] pw = Wipe.utf8(pin);
        try {
            return Pbkdf2.derive(pw, salt, iterations, 32);
        } catch (GeneralSecurityException | IllegalArgumentException e) {
            throw new CryptoException(CryptoException.PARAM, e);
        } finally {
            Wipe.bytes(pw);
        }
    }

    /** true si todos los digitos son iguales o forman una secuencia ascendente/descendente. */
    public static boolean isWeak(char[] pin) {
        if (pin.length < 2) return true;
        boolean same = true, up = true, down = true;
        for (int i = 1; i < pin.length; i++) {
            int d = pin[i] - pin[i - 1];
            if (d != 0) same = false;
            if (d != 1) up = false;
            if (d != -1) down = false;
        }
        return same || up || down;
    }
}
