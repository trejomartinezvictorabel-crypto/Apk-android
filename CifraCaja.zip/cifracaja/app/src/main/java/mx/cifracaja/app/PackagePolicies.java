package mx.cifracaja.app;

import android.content.Context;
import mx.cifracaja.app.crypto.CryptoException;
import mx.cifracaja.app.crypto.PackageCrypto;
import mx.cifracaja.app.crypto.PackageMeta;

/** Politica de apertura del dispositivo: caducidad, anti-retroceso de reloj y uso unico. */
final class PackagePolicies {
    private PackagePolicies() {}

    static PackageCrypto.Policy forDevice(Context ctx) {
        final Context c = ctx.getApplicationContext();
        return new PackageCrypto.Policy() {
            @Override
            public void beforeData(PackageMeta m) throws CryptoException {
                if (m.expiresAt > 0) {
                    if (!LocalState.observeClock(c)) throw new CryptoException(CryptoException.CLOCK);
                    if (m.isExpired(System.currentTimeMillis())) throw new CryptoException(CryptoException.EXPIRED);
                }
                if (m.singleUse && LocalState.isUsed(c, m.idHex())) {
                    throw new CryptoException(CryptoException.USED);
                }
            }

            @Override
            public void afterSuccess(PackageMeta m) throws CryptoException {
                if (m.singleUse) LocalState.markUsed(c, m.idHex(), m.expiresAt);
            }
        };
    }
}
