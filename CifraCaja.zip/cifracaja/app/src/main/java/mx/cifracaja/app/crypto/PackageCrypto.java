package mx.cifracaja.app.crypto;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FilterInputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Formato de paquete CJA v3 (exclusivo de CifraCaja):
 *
 *   CABECERA : MAGIC(6) | version(1) | modo(1) | modoClave(1) | iteraciones(4) | salt(16)
 *              | prefijoNonce(8) | firmado(1)
 *              [solo modoClave=1: idDestinatario(8) | longitud(2) | llave simetrica envuelta con RSA-OAEP]
 *   CABMAC   : HMAC-SHA256(macKey, "H" || CABECERA)                                      (32)
 *   BLOQUES  : indice 0 = metadatos (nombre, extension, tamano, caducidad UTC, uso unico,
 *              identificador aleatorio de 16 bytes), 1..n = datos (hasta 64 KB cada uno)
 *              longitud(4) | ultimo(1) | AES-256-GCM(texto+tag16) | HMAC(32)
 *   FIRMA    : solo si firmado=1: idFirmante(8) | longitud(2) | firma RSA (SHA256withRSA) del
 *              mensaje "CJA-SIG-v1" || SHA-256(todos los bytes anteriores del paquete)
 *
 * modoClave 0: claves = PBKDF2-HMAC-SHA256(clave secreta, salt, iter) -> AES(32) + HMAC(32).
 * modoClave 1: un secreto aleatorio de 256 bits se envuelve con la llave publica del destinatario
 *              y las claves se derivan del secreto con HMAC-SHA256.
 * El bit "firmado", el destinatario y la llave envuelta estan dentro de la cabecera autenticada:
 * no se puede quitar la firma ni cambiar el destinatario sin invalidar el paquete.
 */
public final class PackageCrypto {
    public static final int CHUNK = 64 * 1024;
    public static final int MIN_PASSPHRASE = 8;
    public static final int DEFAULT_ITERATIONS = 150_000;

    private static final byte[] MAGIC = {'C', 'J', 'A', 0x7F, (byte) 0xB1, 0x01};
    private static final byte VERSION = 3;
    private static final int KEY_PASSPHRASE = 0;
    private static final int KEY_WRAPPED = 1;
    private static final int FIXED_HEADER = 6 + 1 + 1 + 1 + 4 + 16 + 8 + 1;
    private static final int TAG_BITS = 128;
    private static final int MAC_LEN = 32;
    private static final int MAX_ITER = 2_000_000;
    private static final int MAX_META = 4096;
    private static final int MAX_WRAP = 1024;
    private static final int MAX_SIG = 1024;
    private static final byte[] SIG_LABEL = "CJA-SIG-v1".getBytes();
    private static final SecureRandom RNG = new SecureRandom();

    private PackageCrypto() {}

    // ---------------------------------------------------------------- interfaces

    /** Politica al descifrar: antes de escribir contenido y tras verificarlo todo. */
    public interface Policy {
        void beforeData(PackageMeta meta) throws CryptoException;
        void afterSuccess(PackageMeta meta) throws CryptoException;
    }

    public interface Cancel { boolean isCancelled(); }

    /** Envuelve el secreto del paquete con la llave publica de un destinatario. */
    public interface KeyWrapper {
        byte[] recipientId();                       // 8 bytes
        byte[] wrap(byte[] secret) throws Exception;
    }

    /** Desenvuelve con la llave privada propia (que nunca sale del Keystore). */
    public interface KeyUnwrapper {
        boolean isRecipient(byte[] recipientId);
        byte[] unwrap(byte[] wrapped) throws Exception;
    }

    public interface Signer {
        byte[] signerId();                          // 8 bytes
        byte[] sign(byte[] message) throws Exception;
    }

    public enum SigStatus { NONE, VALID, UNKNOWN_SIGNER }

    public interface SigVerifier {
        /** VALID, UNKNOWN_SIGNER, o CryptoException(SIG) si el firmante es conocido y la firma no cuadra. */
        SigStatus verify(byte[] signerId, byte[] message, byte[] signature) throws CryptoException;
    }

    public static final class Options {
        public char[] passphrase;   // modo clave secreta
        public KeyWrapper wrapper;  // modo "para un contacto" (tiene prioridad)
        public Signer signer;       // opcional
    }

    public static final class Credentials {
        public char[] passphrase;
        public KeyUnwrapper unwrapper;
        public SigVerifier verifier;
    }

    public static final class Result {
        public final PackageMeta meta;
        public final SigStatus sig;
        public final byte[] signerId;   // null si no estaba firmado

        Result(PackageMeta meta, SigStatus sig, byte[] signerId) {
            this.meta = meta;
            this.sig = sig;
            this.signerId = signerId;
        }
    }

    private static final class Session {
        SecretKeySpec aes;
        Mac mac;
        byte[] noncePrefix;
        byte[] headerMac;

        void wipe() {
            Wipe.bytes(noncePrefix, headerMac);
        }
    }

    /** Calcula SHA-256 de todo lo que se escribe. */
    private static final class HashOut extends FilterOutputStream {
        final MessageDigest md;

        HashOut(OutputStream out) throws GeneralSecurityException {
            super(out);
            md = MessageDigest.getInstance("SHA-256");
        }

        @Override public void write(int b) throws IOException {
            out.write(b);
            md.update((byte) b);
        }

        @Override public void write(byte[] b, int off, int len) throws IOException {
            out.write(b, off, len);
            md.update(b, off, len);
        }
    }

    /** Calcula SHA-256 de todo lo que se lee. */
    private static final class HashIn extends FilterInputStream {
        final MessageDigest md;

        HashIn(InputStream in) throws GeneralSecurityException {
            super(in);
            md = MessageDigest.getInstance("SHA-256");
        }

        @Override public int read() throws IOException {
            int b = in.read();
            if (b >= 0) md.update((byte) b);
            return b;
        }

        @Override public int read(byte[] b, int off, int len) throws IOException {
            int n = in.read(b, off, len);
            if (n > 0) md.update(b, off, n);
            return n;
        }
    }

    private static byte[] sigMessage(byte[] digest) {
        byte[] m = new byte[SIG_LABEL.length + digest.length];
        System.arraycopy(SIG_LABEL, 0, m, 0, SIG_LABEL.length);
        System.arraycopy(digest, 0, m, SIG_LABEL.length, digest.length);
        return m;
    }

    // ------------------------------------------------------------------ cifrar

    public static void encrypt(char[] passphrase, PackageMeta meta, InputStream in,
                               OutputStream out, Cancel cancel) throws CryptoException {
        Options o = new Options();
        o.passphrase = passphrase;
        encrypt(o, meta, in, out, cancel);
    }

    public static void encrypt(Options opt, PackageMeta meta, InputStream in,
                               OutputStream out, Cancel cancel) throws CryptoException {
        if (opt == null || meta == null
                || (meta.mode != PackageMeta.MODE_TEXT && meta.mode != PackageMeta.MODE_FILE)) {
            throw new CryptoException(CryptoException.PARAM);
        }
        final boolean wrapped = opt.wrapper != null;
        if (!wrapped && (opt.passphrase == null || opt.passphrase.length < MIN_PASSPHRASE)) {
            throw new CryptoException(CryptoException.PARAM);
        }
        byte[] pw = wrapped ? null : Wipe.utf8(opt.passphrase);
        byte[] secret = null;
        byte[] salt = new byte[16];
        byte[] prefix = new byte[8];
        byte[] cur = new byte[CHUNK];
        byte[] nxt = new byte[CHUNK];
        byte[] metaBytes = null;
        Session s = new Session();
        try {
            RNG.nextBytes(salt);
            RNG.nextBytes(prefix);
            ByteArrayOutputStream hb = new ByteArrayOutputStream();
            DataOutputStream hd = new DataOutputStream(hb);
            hd.write(MAGIC);
            hd.writeByte(VERSION);
            hd.writeByte(meta.mode);
            hd.writeByte(wrapped ? KEY_WRAPPED : KEY_PASSPHRASE);
            hd.writeInt(wrapped ? 0 : DEFAULT_ITERATIONS);
            hd.write(salt);
            hd.write(prefix);
            hd.writeByte(opt.signer != null ? 1 : 0);
            if (wrapped) {
                secret = new byte[32];
                RNG.nextBytes(secret);
                byte[] w = opt.wrapper.wrap(secret);
                byte[] rid = opt.wrapper.recipientId();
                if (w == null || w.length == 0 || w.length > MAX_WRAP || rid == null || rid.length != 8) {
                    throw new CryptoException(CryptoException.PARAM);
                }
                hd.write(rid);
                hd.writeShort(w.length);
                hd.write(w);
            }
            hd.flush();
            byte[] header = hb.toByteArray();

            s.noncePrefix = prefix.clone();
            if (wrapped) initSession(s, deriveFromSecret(secret, salt), header);
            else initSession(s, Pbkdf2.derive(pw, salt, DEFAULT_ITERATIONS, 64), header);

            HashOut ho = new HashOut(out);
            ho.write(header);
            ho.write(s.headerMac);

            ByteArrayOutputStream mb = new ByteArrayOutputStream();
            DataOutputStream md = new DataOutputStream(mb);
            md.writeUTF(meta.name);
            md.writeUTF(meta.extension);
            md.writeLong(meta.size);
            md.writeLong(meta.expiresAt);
            md.writeByte(meta.singleUse ? 1 : 0);
            byte[] pid = new byte[16];
            RNG.nextBytes(pid);
            md.write(pid);
            md.flush();
            metaBytes = mb.toByteArray();
            if (metaBytes.length > MAX_META) throw new CryptoException(CryptoException.PARAM);
            writeChunk(s, ho, 0, false, metaBytes, metaBytes.length);

            int idx = 1;
            int curLen = readFull(in, cur);
            while (true) {
                check(cancel);
                int nxtLen = curLen == CHUNK ? readFull(in, nxt) : 0;
                boolean last = nxtLen == 0;
                writeChunk(s, ho, idx++, last, cur, curLen);
                if (last) break;
                byte[] tmp = cur; cur = nxt; nxt = tmp;
                curLen = nxtLen;
            }
            if (opt.signer != null) {
                byte[] digest = ho.md.digest();
                byte[] sig = opt.signer.sign(sigMessage(digest));
                byte[] sid = opt.signer.signerId();
                if (sig == null || sig.length == 0 || sig.length > MAX_SIG || sid == null || sid.length != 8) {
                    throw new CryptoException(CryptoException.PARAM);
                }
                out.write(sid);
                out.write(new byte[]{(byte) (sig.length >>> 8), (byte) sig.length});
                out.write(sig);
            }
            out.flush();
        } catch (CryptoException e) {
            throw e;
        } catch (IOException e) {
            throw new CryptoException(CryptoException.IO, e);
        } catch (Exception e) {
            throw new CryptoException(CryptoException.PARAM, e);
        } finally {
            Wipe.bytes(pw, secret, salt, prefix, cur, nxt, metaBytes);
            s.wipe();
        }
    }

    // --------------------------------------------------------------- descifrar

    /** Compatibilidad: descifra con clave secreta; rechaza vencidos salvo allowExpired. */
    public static PackageMeta decrypt(char[] passphrase, InputStream in, OutputStream out,
                                      boolean allowExpired, Cancel cancel) throws CryptoException {
        final boolean allow = allowExpired;
        return decrypt(passphrase, in, out, new Policy() {
            @Override public void beforeData(PackageMeta m) throws CryptoException {
                if (!allow && m.isExpired(System.currentTimeMillis())) {
                    throw new CryptoException(CryptoException.EXPIRED);
                }
            }
            @Override public void afterSuccess(PackageMeta m) { }
        }, cancel);
    }

    public static PackageMeta decrypt(char[] passphrase, InputStream in, OutputStream out,
                                      Policy policy, Cancel cancel) throws CryptoException {
        Credentials c = new Credentials();
        c.passphrase = passphrase;
        return decryptEx(c, in, out, policy, cancel).meta;
    }

    /**
     * Descifra con clave secreta o con la llave privada propia segun el paquete, aplica la politica
     * y verifica la firma si existe. Cada bloque se autentica antes de escribirse; si ocurre
     * cualquier excepcion el llamador DEBE borrar la salida parcial.
     */
    public static Result decryptEx(Credentials cred, InputStream in, OutputStream out,
                                   Policy policy, Cancel cancel) throws CryptoException {
        if (cred == null) throw new CryptoException(CryptoException.PARAM);
        byte[] pw = null;
        byte[] secret = null;
        Session s = new Session();
        byte[] plain = null;
        try {
            HashIn hin = new HashIn(in);
            DataInputStream din = new DataInputStream(hin);
            byte[] fixed = new byte[FIXED_HEADER];
            readExact(din, fixed, CryptoException.FORMAT);
            if (!Arrays.equals(Arrays.copyOf(fixed, MAGIC.length), MAGIC) || fixed[MAGIC.length] != VERSION) {
                throw new CryptoException(CryptoException.FORMAT);
            }
            byte mode = fixed[MAGIC.length + 1];
            int keyMode = fixed[MAGIC.length + 2];
            if (mode != PackageMeta.MODE_TEXT && mode != PackageMeta.MODE_FILE) {
                throw new CryptoException(CryptoException.FORMAT);
            }
            if (keyMode != KEY_PASSPHRASE && keyMode != KEY_WRAPPED) throw new CryptoException(CryptoException.FORMAT);
            int off = MAGIC.length + 3;
            int iter = ((fixed[off] & 0xFF) << 24) | ((fixed[off + 1] & 0xFF) << 16)
                    | ((fixed[off + 2] & 0xFF) << 8) | (fixed[off + 3] & 0xFF);
            byte[] salt = Arrays.copyOfRange(fixed, off + 4, off + 20);
            s.noncePrefix = Arrays.copyOfRange(fixed, off + 20, off + 28);
            int signedFlag = fixed[off + 28];
            if (signedFlag != 0 && signedFlag != 1) throw new CryptoException(CryptoException.FORMAT);

            ByteArrayOutputStream hb = new ByteArrayOutputStream();
            hb.write(fixed);
            byte[] rid = null;
            byte[] wrappedKey = null;
            if (keyMode == KEY_WRAPPED) {
                rid = new byte[8];
                readExact(din, rid, CryptoException.FORMAT);
                int wl = din.readUnsignedShort();
                if (wl < 1 || wl > MAX_WRAP) throw new CryptoException(CryptoException.FORMAT);
                wrappedKey = new byte[wl];
                readExact(din, wrappedKey, CryptoException.FORMAT);
                hb.write(rid);
                hb.write(new byte[]{(byte) (wl >>> 8), (byte) wl});
                hb.write(wrappedKey);
            } else if (iter < 10_000 || iter > MAX_ITER) {
                throw new CryptoException(CryptoException.FORMAT);
            }
            byte[] header = hb.toByteArray();
            byte[] storedMac = new byte[MAC_LEN];
            readExact(din, storedMac, CryptoException.FORMAT);

            if (keyMode == KEY_PASSPHRASE) {
                if (cred.passphrase == null || cred.passphrase.length == 0) {
                    throw new CryptoException(CryptoException.NEED_KEY);
                }
                pw = Wipe.utf8(cred.passphrase);
                initSession(s, Pbkdf2.derive(pw, salt, iter, 64), header);
            } else {
                if (cred.unwrapper == null || !cred.unwrapper.isRecipient(rid)) {
                    throw new CryptoException(CryptoException.RECIPIENT);
                }
                try {
                    secret = cred.unwrapper.unwrap(wrappedKey);
                } catch (Exception e) {
                    throw new CryptoException(CryptoException.KEY_OR_HEADER, e);
                }
                if (secret == null || secret.length != 32) throw new CryptoException(CryptoException.KEY_OR_HEADER);
                initSession(s, deriveFromSecret(secret, salt), header);
            }
            if (!MessageDigest.isEqual(storedMac, s.headerMac)) {
                throw new CryptoException(CryptoException.KEY_OR_HEADER);
            }

            PackageMeta meta = null;
            int idx = 0;
            while (true) {
                check(cancel);
                int len = din.readInt();
                if (len < 16 || len > CHUNK + 16) throw new CryptoException(CryptoException.FORMAT);
                boolean last = readFlag(din);
                byte[] ct = new byte[len];
                readExact(din, ct, CryptoException.TRUNC);
                byte[] tag = new byte[MAC_LEN];
                readExact(din, tag, CryptoException.TRUNC);

                byte[] calc = chunkMac(s, idx, last, ct);
                if (!MessageDigest.isEqual(calc, tag)) throw new CryptoException(CryptoException.AUTH);

                Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
                c.init(Cipher.DECRYPT_MODE, s.aes, new GCMParameterSpec(TAG_BITS, nonce(s, idx)));
                c.updateAAD(aad(s, idx, last));
                Wipe.bytes(plain);
                plain = c.doFinal(ct);

                if (idx == 0) {
                    if (last) throw new CryptoException(CryptoException.FORMAT);
                    DataInputStream md = new DataInputStream(new ByteArrayInputStream(plain));
                    String mName = md.readUTF();
                    String mExt = md.readUTF();
                    long mSize = md.readLong();
                    long mExp = md.readLong();
                    int flags = md.readUnsignedByte();
                    byte[] pid = new byte[16];
                    md.readFully(pid);
                    if ((flags & ~1) != 0 || mSize < 0 || mExp < 0) throw new CryptoException(CryptoException.FORMAT);
                    meta = new PackageMeta(mode, mName, mExt, mSize, mExp, (flags & 1) != 0, pid);
                    policy.beforeData(meta); // caducidad / reloj / uso unico: antes de mostrar nada
                } else {
                    out.write(plain);
                }
                idx++;
                if (last) break;
            }

            SigStatus status = SigStatus.NONE;
            byte[] signerId = null;
            if (signedFlag == 1) {
                byte[] digest = hin.md.digest(); // hasta el ultimo bloque, sin la firma
                signerId = new byte[8];
                readExact(din, signerId, CryptoException.TRUNC);
                int sl = din.readUnsignedShort();
                if (sl < 1 || sl > MAX_SIG) throw new CryptoException(CryptoException.FORMAT);
                byte[] sig = new byte[sl];
                readExact(din, sig, CryptoException.TRUNC);
                status = cred.verifier != null
                        ? cred.verifier.verify(signerId, sigMessage(digest), sig)
                        : SigStatus.UNKNOWN_SIGNER;
            }
            if (din.read() != -1) throw new CryptoException(CryptoException.TRUNC);
            out.flush();
            policy.afterSuccess(meta);
            return new Result(meta, status, signerId);
        } catch (CryptoException e) {
            throw e;
        } catch (java.io.EOFException e) {
            throw new CryptoException(CryptoException.TRUNC, e);
        } catch (IOException e) {
            throw new CryptoException(CryptoException.IO, e);
        } catch (GeneralSecurityException e) {
            throw new CryptoException(CryptoException.AUTH, e);
        } finally {
            Wipe.bytes(pw, secret, plain);
            s.wipe();
        }
    }

    // --------------------------------------------------------------- internos

    private static byte[] deriveFromSecret(byte[] secret, byte[] salt) throws GeneralSecurityException {
        Mac m = Mac.getInstance("HmacSHA256");
        m.init(new SecretKeySpec(secret, "HmacSHA256"));
        m.update(salt);
        m.update("cja-enc".getBytes());
        byte[] a = m.doFinal();
        m.update(salt);
        m.update("cja-mac".getBytes());
        byte[] b = m.doFinal();
        byte[] out = new byte[64];
        System.arraycopy(a, 0, out, 0, 32);
        System.arraycopy(b, 0, out, 32, 32);
        Wipe.bytes(a, b);
        return out;
    }

    private static void initSession(Session s, byte[] keys, byte[] header) throws GeneralSecurityException {
        byte[] aesKey = Arrays.copyOfRange(keys, 0, 32);
        byte[] macKey = Arrays.copyOfRange(keys, 32, 64);
        try {
            s.aes = new SecretKeySpec(aesKey, "AES");
            s.mac = Mac.getInstance("HmacSHA256");
            s.mac.init(new SecretKeySpec(macKey, "HmacSHA256"));
            s.mac.update((byte) 'H');
            s.headerMac = s.mac.doFinal(header);
        } finally {
            Wipe.bytes(keys, aesKey, macKey);
        }
    }

    private static byte[] nonce(Session s, int idx) {
        byte[] n = new byte[12];
        System.arraycopy(s.noncePrefix, 0, n, 0, 8);
        n[8] = (byte) (idx >>> 24); n[9] = (byte) (idx >>> 16);
        n[10] = (byte) (idx >>> 8); n[11] = (byte) idx;
        return n;
    }

    private static byte[] aad(Session s, int idx, boolean last) {
        byte[] a = new byte[MAC_LEN + 5];
        System.arraycopy(s.headerMac, 0, a, 0, MAC_LEN);
        a[MAC_LEN] = (byte) (idx >>> 24); a[MAC_LEN + 1] = (byte) (idx >>> 16);
        a[MAC_LEN + 2] = (byte) (idx >>> 8); a[MAC_LEN + 3] = (byte) idx;
        a[MAC_LEN + 4] = (byte) (last ? 1 : 0);
        return a;
    }

    private static byte[] chunkMac(Session s, int idx, boolean last, byte[] ct) {
        s.mac.update(s.headerMac);
        s.mac.update(new byte[]{(byte) (idx >>> 24), (byte) (idx >>> 16), (byte) (idx >>> 8), (byte) idx,
                (byte) (last ? 1 : 0),
                (byte) (ct.length >>> 24), (byte) (ct.length >>> 16), (byte) (ct.length >>> 8), (byte) ct.length});
        s.mac.update(ct);
        return s.mac.doFinal();
    }

    private static void writeChunk(Session s, OutputStream out, int idx, boolean last,
                                   byte[] buf, int len) throws GeneralSecurityException, IOException {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, s.aes, new GCMParameterSpec(TAG_BITS, nonce(s, idx)));
        c.updateAAD(aad(s, idx, last));
        byte[] ct = c.doFinal(buf, 0, len);
        byte[] tag = chunkMac(s, idx, last, ct);
        out.write(new byte[]{(byte) (ct.length >>> 24), (byte) (ct.length >>> 16),
                (byte) (ct.length >>> 8), (byte) ct.length, (byte) (last ? 1 : 0)});
        out.write(ct);
        out.write(tag);
    }

    private static boolean readFlag(DataInputStream din) throws IOException, CryptoException {
        int f = din.readUnsignedByte();
        if (f > 1) throw new CryptoException(CryptoException.FORMAT);
        return f == 1;
    }

    private static int readFull(InputStream in, byte[] buf) throws IOException {
        int n = 0;
        while (n < buf.length) {
            int r = in.read(buf, n, buf.length - n);
            if (r < 0) break;
            n += r;
        }
        return n;
    }

    private static void readExact(DataInputStream in, byte[] buf, String code)
            throws IOException, CryptoException {
        try {
            in.readFully(buf);
        } catch (java.io.EOFException e) {
            throw new CryptoException(code);
        }
    }

    private static void check(Cancel c) throws CryptoException {
        if (c != null && c.isCancelled()) throw new CryptoException(CryptoException.CANCEL);
    }
}
