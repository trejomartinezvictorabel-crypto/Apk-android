package mx.cifracaja.app;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

/** Pantalla de bienvenida (primer uso) con selector de idioma. */
public class WelcomeActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        final SharedPreferences p = getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
        if (p.getBoolean("welcomed", false)) {
            goMain();
            return;
        }
        int pad = dp(24);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(pad, dp(48), pad, pad);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_launcher_foreground);
        root.addView(logo, new LinearLayout.LayoutParams(dp(160), dp(160)));

        TextView hello = new TextView(this);
        hello.setText(R.string.welcome_title);
        hello.setTextSize(34);
        hello.setGravity(Gravity.CENTER);
        root.addView(hello);
        TextView name = new TextView(this);
        name.setText(R.string.title);
        name.setTextSize(22);
        name.setGravity(Gravity.CENTER);
        root.addView(name);
        TextView sub = new TextView(this);
        sub.setText(R.string.welcome_sub);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(12), 0, dp(24));
        root.addView(sub);

        TextView lbl = new TextView(this);
        lbl.setText(R.string.language_label);
        root.addView(lbl);
        Spinner sp = new Spinner(this);
        sp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                LocaleHelper.names(this)));
        sp.setSelection(LocaleHelper.indexOf(LocaleHelper.saved(this)));
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View v, int pos, long id) {
                String code = LocaleHelper.LANGS[pos][0];
                if (!code.equals(LocaleHelper.saved(WelcomeActivity.this))) {
                    LocaleHelper.save(WelcomeActivity.this, code);
                    recreate();
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
        root.addView(sp);

        Button go = new Button(this);
        go.setText(R.string.btn_continue);
        go.setAllCaps(false);
        go.setOnClickListener(v -> {
            p.edit().putBoolean("welcomed", true).apply();
            goMain();
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(24);
        root.addView(go, lp);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
    }

    private void goMain() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
