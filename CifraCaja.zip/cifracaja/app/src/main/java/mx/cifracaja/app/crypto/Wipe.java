package mx.cifracaja.app.crypto;

import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/** Utilidades para limpiar de memoria datos sensibles. */
public final class Wipe {
    private Wipe() {}

    public static void bytes(byte[]... arrays) {
        for (byte[] a : arrays) if (a != null) Arrays.fill(a, (byte) 0);
    }

    public static void chars(char[] a) {
        if (a != null) Arrays.fill(a, '\0');
    }

    /** Convierte char[] a UTF-8 sin dejar copias String; el llamador debe limpiar el resultado. */
    public static byte[] utf8(char[] chars) {
        ByteBuffer bb = StandardCharsets.UTF_8.encode(CharBuffer.wrap(chars));
        byte[] out = new byte[bb.remaining()];
        bb.get(out);
        if (bb.hasArray()) Arrays.fill(bb.array(), (byte) 0);
        return out;
    }
}
